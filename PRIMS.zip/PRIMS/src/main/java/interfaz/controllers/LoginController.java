package interfaz.controllers;


import controllersJPA.AuthJpaController;
import entities.Auth;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import utils.NotificationManager;
import utils.Sesion;
import utils.TokenManager;

public class LoginController {

    @FXML private ImageView logo;
    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private Button btnIngresar;
    // Ahora el root es StackPane
    @FXML private StackPane rootLogin;

    private MainController main;
    public void setMainController(MainController m) { this.main = m; main.slideInFromLeft(rootLogin);}

    @FXML
    public void initialize() {
    }

    @FXML
    private void onLogin() {

        String user = txtUsuario.getText().trim();
        String pass = txtContrasena.getText().trim();

        if (user.isEmpty()) {
            NotificationManager.warning("Ingresa el usuario.");
            main.shake(txtUsuario);
            return;
        }

        if (pass.isEmpty()) {
            NotificationManager.warning("Ingresa el contraseña.");
            main.shake(txtContrasena);
            return;
        }

        // Obtenemos el usuario real desde la BD
        Auth auth = validarCredenciales(user, pass);
        if (auth != null) {

            // ✔ Guardar usuario real en sesión
            Sesion.iniciar(auth);

            // ✔ Renovar token si caducó (o generar uno si aplica)
            NotificationManager.success("Inicio exitoso.");
            TokenManager.refreshToken();
            playFadeOut(() -> {
                main.loadPanel("/ui/panel_search_main.fxml");
            });
            main.actualizarWishlistCount();

        } else {
            main.shake(txtUsuario);
            main.shake(txtContrasena);
            NotificationManager.warning("Credenciales no validas.");
        }
    }



    @FXML
    private void onRegister() {
        main.slideOutToLeft(rootLogin, () -> {
            main.loadPanel("/ui/panelRegister.fxml");
        });
    }



    @FXML
    private void onResetPass(){
        main.slideOutToLeft(rootLogin, () -> {main.loadPanel("/ui/panelReset.fxml");
        });
    }


    private void playFadeOut(Runnable after) {
        FadeTransition fade = new FadeTransition(Duration.millis(500), rootLogin);
        fade.setFromValue(1);
        fade.setToValue(0);
        fade.setOnFinished(e -> after.run());
        fade.play();
    }

    private Auth validarCredenciales(String username, String password) {

        AuthJpaController authJPA = new AuthJpaController();
        return authJPA.loginByUserName(username,password); // devuelve el usuario real o null
    }
}
