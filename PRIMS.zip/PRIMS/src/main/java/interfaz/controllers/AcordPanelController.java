package interfaz.controllers;

import controllersJPA.ProductosJpaController;
import controllersJPA.WishlistProductsJpaController;
import entities.Producto;
import entities.WishlistProduct;
import javafx.fxml.FXML;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import utils.Sesion;

import java.io.IOException;
import java.util.List;

public class AcordPanelController {

    @FXML
    private VBox acordPanel;

    private final WishlistProductsJpaController wishlistJPA = new WishlistProductsJpaController();

    @FXML
    public void initialize() {
        recargarLista();
    }

    /**
     * 🔄 Recarga la lista completa de productos
     */
    public void recargarLista() {

        Integer userId = Sesion.getUsuario().getId();
        System.out.println("👤 Usuario ID: " + userId);

        List<WishlistProduct> listaItems = wishlistJPA.findWishlistProductsByUserID(userId);
        System.out.println("📦 Total items en wishlist: " + (listaItems != null ? listaItems.size() : 0));

        acordPanel.getChildren().clear();

        if (listaItems == null || listaItems.isEmpty()) {
            System.out.println("ℹ️ No hay productos en la wishlist");
            Label lbl = new Label("No tienes productos guardados para analizar.");
            lbl.setStyle("-fx-font-family:'Poppins SemiBold'; -fx-text-fill:#888; -fx-font-size:14;");
            acordPanel.getChildren().add(lbl);
            return;
        }

        ProductosJpaController productoJPA = new ProductosJpaController(); // ✅ Crear una sola vez

        int contador = 0;
        for (WishlistProduct wishlistItem : listaItems) {
            contador++;
            System.out.println("\n   📋 Item " + contador + ":");

            if (wishlistItem.getIdItem() != null) {
                String itemId = wishlistItem.getIdItem().getItemId();

                // ✅ Usar findProductosWithCollections en lugar de findProductos
                Producto producto = productoJPA.findProductosWithCollections(itemId);

                if (producto != null) {
                    String nombre = producto.getName();

                    System.out.println("      - ItemId: " + itemId);
                    System.out.println("      - Nombre: " + nombre);
                    System.out.println("      - Cargando análisis...");

                    loadProductAnalysis(itemId);
                } else {
                    System.err.println("      ⚠️ Producto no encontrado: " + itemId);
                }

            } else {
                System.err.println("      ⚠️ WishlistProduct sin producto asociado");
                System.err.println("         WishlistProduct ID: " + wishlistItem.getId());
            }
        }

        System.out.println("\n========================================");
        System.out.println("✅ RECARGA COMPLETADA: " + contador + " productos");
        System.out.println("========================================\n");
    }
    private void loadProductAnalysis(String itemId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/productAnalize.fxml"));
            Node analysisPanel = loader.load();

            ProductAnalysisController controller = loader.getController();
            controller.setAcordController(this); // 🔥 Pasar referencia al padre
            controller.cargarProducto(itemId);

            acordPanel.getChildren().add(analysisPanel);

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("❌ Error al cargar productAnalize.fxml dentro del acordPanel.");
        }
    }
}