package interfaz.controllers;


import controllersJPA.AuthJpaController;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import utils.NotificationManager;

public class ResetController {

    private MainController main;
    public void setMainController(MainController m){ this.main = m; main.slideInFromRight(panelReset);}

    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private PasswordField txtContrasenaRep;
    @FXML private StackPane panelReset;
    @FXML
    private void onResetPass() {

        String user = txtUsuario.getText().trim();
        String pass = txtContrasena.getText().trim();
        String pass2 = txtContrasenaRep.getText().trim();

        if (user.isEmpty()) {
            NotificationManager.warning("Ingrese su usuario o email.");
            main.shake(txtUsuario);
            return;
        }

        // Validar contraseña mínima
        if (pass.length() < 6) {
            NotificationManager.warning("La contraseña debe tener al menos 6 caracteres.");
            main.shake(txtContrasena);
            return;
        }

        if (!pass.equals(pass2)) {
            NotificationManager.warning("Las contraseñas no coinciden.");
            main.shake(txtContrasenaRep);
            return;
        }

        // -------------------------
        // NUEVO HASH
        // -------------------------

        AuthJpaController AuthJPA = new AuthJpaController();

        boolean ok = AuthJPA.resetPassword(user, pass);

        if (ok) {
            NotificationManager.warning("Contraseña restablecida exitosamente.");
        } else {
            NotificationManager.warning("El usuario o email no existe.");
        }
        volverLogin();
    }

    private void volverLogin() {
        main.loadPanel("/ui/panelLogin.fxml");
    }
}
