package interfaz.controllers;

//
import controllersJPA.AuthJpaController;
import entities.Auth;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import utils.NotificationManager;

public class RegisterController {

    @FXML private TextField txtUsuario;
    @FXML private TextField txtEmail;
    @FXML private PasswordField txtContrasena;
    @FXML private PasswordField txtContrasenaRep;
    @FXML private Button btnRegister;
    @FXML private StackPane panelRegister;

    private MainController main;
    public void setMainController(MainController m){ this.main = m; main.slideInFromRight(panelRegister);}

    @FXML
    public void initialize() {
    }

    @FXML
    private void onRegister() throws Exception {

        String user = txtUsuario.getText().trim();
        String email = txtEmail.getText().trim();
        String pass = txtContrasena.getText().trim();
        String pass2 = txtContrasenaRep.getText().trim();

        // Validaciones
        if (user.isEmpty()) {
            NotificationManager.warning("Ingresa nombre de usuario.");
            main.shake(txtUsuario);
            return;
        }

        if (email.isEmpty()) {
            NotificationManager.warning("Ingresa tu correo electrónico.");
            main.shake(txtEmail);
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            NotificationManager.warning("Correo electrónico no valido.");

            main.shake(txtEmail);
            return;
        }

        if (pass.length() < 6) {
            main.shake(txtContrasena);
            NotificationManager.warning("La contraseña debe tener mínimo 6 caracteres.");
            return;
        }

        if (!pass.equals(pass2)) {
            main.shake(txtContrasena);
            main.shake(txtContrasenaRep);
            NotificationManager.warning("Las contraseñas no coinciden.");
            return;
        }

        AuthJpaController AuthJpa = new AuthJpaController();
        // -------------------------------------
        // VALIDAR SI USUARIO O EMAIL YA EXISTE
        // -------------------------------------

        // -------------------------------------
        // GUARDAR REGISTRO
        // -------------------------------------

        Auth nuevo = new Auth();
        nuevo.setUsername(user);
        nuevo.setEmail(email);
        nuevo.setPasswordHash(pass);

        AuthJpa.register(nuevo, pass);

//

        NotificationManager.success("Cuenta creada con éxito");
            main.slideOutToRight(panelRegister, () -> {
                main.loadPanel("/ui/panelLogin.fxml");
            });
    }

    @FXML
    private void onBack() {
        main.changeWithSlide(panelRegister, "/ui/panelLogin.fxml");
    }



}
