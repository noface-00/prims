package interfaz.controllers;

import controllersJPA.PriceHistoryJpaController;
import controllersJPA.WishlistProductsJpaController;
import entities.*;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import service.ProductAnalysisService;
import utils.NotificationManager;
import utils.Sesion;

import java.awt.*;
import java.net.URI;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ProductAnalysisController {

    @FXML private BorderPane togleAnalys;
    @FXML private VBox content;
    @FXML private Button btnGenerarReporte;
    @FXML private Button btnDeleteWish; // ✅ AGREGADO: botón de eliminar
    @FXML private ProgressIndicator progressIndicator;

    private MainController mainController;

    // Interfaz
    @FXML private ImageView productImage;
    @FXML private Text lblTitle;

    // Precio / Cupón
    @FXML private Text txtPrecioActual;
    @FXML private Text txtPromedio;
    @FXML private Text txtDiferencia;

    // Vendedor
    @FXML private Text txtVendedorNombre;
    @FXML private Text txtFeedback;
    @FXML private Text txtFeedbackScore;
    @FXML private Text txtAntiguedad;
    @FXML private Text txtTrustScore;

    // Mercado
    @FXML private Text txtPromedioMercado;
    @FXML private Text txtRango;
    @FXML private Text txtEstabilidad;

    // Estadísticas generales
    @FXML private Text txtTotalProductos;
    @FXML private Text txtPromedioVariacionGeneral;
    @FXML private Text txtTopVariacionesPositivas;
    @FXML private Text txtTopVariacionesNegativas;
    @FXML private Text txtResumenConsultasDiarias;

    // Gráfico
    @FXML private LineChart<String, Number> chartHistorial;
    @FXML private CategoryAxis xAxis;
    @FXML private NumberAxis yAxis;

    // ✅ AGREGADO: Controlador JPA
    private final WishlistProductsJpaController wishlistJPA = new WishlistProductsJpaController();

    // Servicio central
    private final ProductAnalysisService analysisService = new ProductAnalysisService();

    // Estado actual
    private Producto productoActual;
    private ProductAnalysis analisisActual;
    private AcordPanelController acordController;

    public void setMainController(MainController controller) {
        this.mainController = controller;
    }

    public void setAcordController(AcordPanelController controller) {
        this.acordController = controller;
    }

    @FXML
    public void initialize() {
        togleAnalys.setOnMouseEntered(e ->
                togleAnalys.setStyle("-fx-cursor: hand; -fx-translate-y: -3;")
        );
        togleAnalys.setOnMouseExited(e ->
                togleAnalys.setStyle("-fx-cursor: hand; -fx-effect: none; -fx-translate-y: 0;")
        );

        if (progressIndicator != null) {
            progressIndicator.setVisible(false);
        }
    }

    // ======================================================
    // CARGA PRINCIPAL DE PRODUCTO (ASYNC LIMPIO)
    // ======================================================

    public void cargarProducto(String itemId) {
        CompletableFuture
                .supplyAsync(() ->
                        analysisService.obtenerOGenerarAnalisis(itemId)
                )
                .thenAccept(analisis -> {
                    if (analisis == null) {
                        Platform.runLater(() ->
                                NotificationManager.error("No se pudo cargar el análisis")
                        );
                        return;
                    }

                    Platform.runLater(() ->
                            actualizarUIConResultado(analisis)
                    );
                })
                .exceptionally(ex -> {
                    ex.printStackTrace();
                    Platform.runLater(() ->
                            NotificationManager.error("Error cargando análisis")
                    );
                    return null;
                });
    }

    /**
     * Verifica y genera análisis de forma silenciosa
     * Solo muestra notificación si hay error
     */
    private void actualizarUIConResultado(ProductAnalysis analisis) {
        this.productoActual = analisis.getItem();
        this.analisisActual = analisis; // ✅ AGREGADO: guardar análisis
        Producto producto = analisis.getItem();
        Seller seller = producto.getIdSeller();

        // ===============================
        // 📦 DATOS DEL PRODUCTO
        // ===============================
        cargarImagenProducto(producto);
        lblTitle.setText(producto.getName());

        txtPrecioActual.setText(
                "Precio actual: $" +
                        String.format("%.2f", producto.getPriceHistory().getPrice())
        );

        txtPromedio.setText(
                " | Promedio mercado: $" +
                        String.format("%.2f", analisis.getPriceAvg())
        );

        double diferencia = producto.getPriceHistory().getPrice() - analisis.getPriceAvg();

        txtDiferencia.setText(
                diferencia >= 0
                        ? " | +" + String.format("%.2f", diferencia)
                        : " | " + String.format("%.2f", diferencia)
        );

        // ===============================
        // 🧑‍💼 DATOS DEL VENDEDOR
        // ===============================
        txtVendedorNombre.setText("\nVendedor: " + seller.getUsername());
        txtFeedback.setText("\nFeedback: " + seller.getFeedbackPorcentage() + "%");
        txtFeedbackScore.setText("\nPuntaje: " + seller.getFeedbackScore());
        txtAntiguedad.setText("\nAntigüedad: " + seller.getCreatedAt());

        // ===============================
        // 📊 ANÁLISIS DEL MERCADO
        // ===============================
        txtPromedioMercado.setText("\nPromedio mercado: $" + String.format("%.2f", analisis.getPriceAvg()));
        txtRango.setText("\nRango: $" + String.format("%.2f", analisis.getPriceMin()) + " - $" + String.format("%.2f", analisis.getPriceMax()));
        txtEstabilidad.setText("\nEstabilidad: " + (analisis.getPriceStd() < 10 ? "Alta" : "Variable"));
        txtTotalProductos.setText("\nProductos analizados: " + analisis.getSampleAnalysis());
        txtPromedioVariacionGeneral.setText("\nDesviación estándar: $" + String.format("%.2f", analisis.getPriceStd()));
        txtResumenConsultasDiarias.setText("\nFecha análisis: " + analisis.getAnalysisDate());

        // ===============================
        // 📈 HISTORIAL DE PRECIOS
        // ===============================
        cargarHistorialPrecios(producto.getItemId());
    }

    private void cargarImagenProducto(Producto producto) {
        if (producto == null) return;

        Collection<ImagesProduct> imagenes = producto.getImagesProductsCollection();

        if (imagenes == null || imagenes.isEmpty()) {
            System.out.println("⚠️ No hay imágenes disponibles para este producto");
            return;
        }

        ImagesProduct primeraImagen = imagenes.stream()
                .findFirst()
                .orElse(null);

        if (primeraImagen != null) {
            String urlImagen = primeraImagen.getUrlImg();

            if (urlImagen != null && !urlImagen.isEmpty()) {
                try {
                    Image image = new Image(urlImagen, true);
                    productImage.setImage(image);

                    image.errorProperty().addListener((obs, oldError, newError) -> {
                        if (newError) {
                            System.err.println("Error al cargar imagen: " + urlImagen);
                        }
                    });

                } catch (Exception e) {
                    System.err.println("Error al cargar imagen: " + e.getMessage());
                }
            }
        }
    }

    private void cargarHistorialPrecios(String itemId) {
        PriceHistoryJpaController priceJPA = new PriceHistoryJpaController();
        chartHistorial.getData().clear();

        List<PriceHistory> historial = priceJPA.findAllByItemId(itemId);

        XYChart.Series<String, Number> series = new XYChart.Series<>();

        for (PriceHistory p : historial) {
            series.getData().add(
                    new XYChart.Data<>(
                            p.getRecordedAt(),
                            p.getPrice()
                    )
            );
        }

        chartHistorial.getData().add(series);
    }

    // ======================================================
    // BOTONES / ACCIONES UI
    // ======================================================

    @FXML
    private void onReportGenerated() {
        // Tu código de reporte aquí
    }

    @FXML
    public void onClicked() {
        boolean isVisible = content.isVisible();
        content.setVisible(!isVisible);
        content.setManaged(!isVisible);
    }

    @FXML
    private void visitURL() {
        if (productoActual == null || productoActual.getUrlProduct() == null) {
            NotificationManager.warning("⚠️ Este producto no tiene una URL válida.");
            return;
        }

        try {
            String url = productoActual.getUrlProduct();
            Desktop.getDesktop().browse(new URI(url));
            System.out.println("🌐 Abriendo en navegador: " + url);
        } catch (Exception e) {
            NotificationManager.error("❌ No se pudo abrir el enlace.");
            System.err.println("Error abriendo URL: " + e.getMessage());
        }
    }

    @FXML
    protected void onDeletedWish() {
        System.out.println("\n========================================");
        System.out.println("🗑️ INICIANDO ELIMINACIÓN DE WISHLIST");
        System.out.println("========================================");

        // ========================================
        // VALIDACIONES INICIALES
        // ========================================
        if (productoActual == null) {
            System.err.println("❌ productoActual es NULL");
            NotificationManager.warning("⚠️ No hay producto cargado.");
            return;
        }

        System.out.println("✅ Producto actual: " + productoActual.getName());
        System.out.println("   ItemId: " + productoActual.getItemId());

        Auth usuario = Sesion.getUsuario();
        if (usuario == null) {
            System.err.println("❌ Usuario no está logueado");
            NotificationManager.warning("⚠️ Debes iniciar sesión.");
            return;
        }

        int userId = usuario.getId();
        String itemId = productoActual.getItemId();

        System.out.println("✅ Usuario ID: " + userId);
        System.out.println("✅ Item ID: " + itemId);

        try {
            // ========================================
            // BUSCAR EN WISHLIST
            // ========================================
            System.out.println("\n🔍 Buscando producto en wishlist...");

            WishlistProduct wishlistProduct =
                    wishlistJPA.findWishlistProductsByProduct(userId, itemId);

            if (wishlistProduct == null) {
                System.err.println("❌ Producto NO encontrado en wishlist");
                System.err.println("   Posibles causas:");
                System.err.println("   - Ya fue eliminado");
                System.err.println("   - ItemId no coincide");
                System.err.println("   - UserId no coincide");
                NotificationManager.info("Este producto no está en tu wishlist.");
                return;
            }

            System.out.println("✅ Producto encontrado en wishlist");
            System.out.println("   Wishlist ID: " + wishlistProduct.getId());
            System.out.println("   User ID en wishlist: " + wishlistProduct.getIdUser().getId());
            System.out.println("   Item ID en wishlist: " + wishlistProduct.getIdItem().getItemId());

            // ========================================
            // ELIMINAR DE BASE DE DATOS
            // ========================================
            System.out.println("\n🗑️ Eliminando de base de datos...");

            Integer wishlistId = wishlistProduct.getId();
            wishlistJPA.destroy(wishlistId);

            System.out.println("✅ Comando destroy() ejecutado");

            // ========================================
            // VERIFICAR ELIMINACIÓN
            // ========================================
            System.out.println("\n🔍 Verificando eliminación...");

            WishlistProduct verificacion =
                    wishlistJPA.findWishlistProductsByProduct(userId, itemId);

            if (verificacion != null) {
                System.err.println("❌❌❌ ERROR CRÍTICO: Producto AÚN existe en BD");
                System.err.println("   Wishlist ID: " + verificacion.getId());
                NotificationManager.error("Error: El producto no se eliminó correctamente.");
                return;
            }

            System.out.println("✅ Verificación exitosa: Producto eliminado de BD");

            // ========================================
            // ACTUALIZAR UI
            // ========================================
            System.out.println("\n🔄 Actualizando interfaz...");

            NotificationManager.success("✅ Producto eliminado de tu wishlist.");

            // Actualizar contador
            if (mainController != null) {
                System.out.println("   - Actualizando contador en MainController");
                mainController.actualizarWishlistCount();
            } else {
                System.err.println("   ⚠️ mainController es NULL");
            }

            // Recargar lista
            if (acordController != null) {
                System.out.println("   - Recargando lista en AcordController");
                acordController.recargarLista();
            } else {
                System.err.println("   ⚠️ acordController es NULL");
            }

            // ========================================
            // 🔥 CERRAR VENTANA
            // ========================================
            cerrarVentana();

            System.out.println("✅ Interfaz actualizada");
            System.out.println("========================================");
            System.out.println("ELIMINACIÓN COMPLETADA EXITOSAMENTE");
            System.out.println("========================================\n");

        } catch (Exception e) {
            System.err.println("\n========================================");
            System.err.println("❌❌❌ ERROR CRÍTICO EN ELIMINACIÓN");
            System.err.println("========================================");
            System.err.println("Tipo: " + e.getClass().getName());
            System.err.println("Mensaje: " + e.getMessage());
            System.err.println("Stack trace:");
            e.printStackTrace();
            System.err.println("========================================\n");

            NotificationManager.error("Error al eliminar de la wishlist: " + e.getMessage());
        }
    }

    /**
     * ✅ MÉTODO CORREGIDO: Cerrar la ventana actual
     */
    private void cerrarVentana() {
        try {
            // Intenta obtener el Stage desde cualquier componente FXML disponible
            Stage currentStage = null;

            // Intenta con el botón de eliminar
            if (btnDeleteWish != null && btnDeleteWish.getScene() != null) {
                currentStage = (Stage) btnDeleteWish.getScene().getWindow();
            }
            // Si no, intenta con el botón de generar reporte
            else if (btnGenerarReporte != null && btnGenerarReporte.getScene() != null) {
                currentStage = (Stage) btnGenerarReporte.getScene().getWindow();
            }
            // Si no, intenta con el BorderPane principal
            else if (togleAnalys != null && togleAnalys.getScene() != null) {
                currentStage = (Stage) togleAnalys.getScene().getWindow();
            }

            if (currentStage != null) {
                currentStage.close();
                System.out.println("✅ Ventana cerrada exitosamente");
            } else {
                System.err.println("⚠️ No se pudo obtener el Stage de la ventana");
            }

        } catch (Exception e) {
            System.err.println("⚠️ Error cerrando ventana: " + e.getMessage());
            e.printStackTrace();
        }
    }
}