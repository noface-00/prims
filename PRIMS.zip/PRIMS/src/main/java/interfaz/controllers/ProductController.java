package interfaz.controllers;

import controllersJPA.*;
import entities.*;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.Duration;
import utils.NotificationManager;
import utils.Sesion;
import utils.cls_browseEBAY;

import java.awt.*;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ProductController {

    @FXML private StackPane imageContainer;
    @FXML private Button btnPrev, btnNext, btnSave, btn_link_pro;
    @FXML private Label lblTitle, lblPrice, lblDescrtiption;
    @FXML private Label lblContentDet, lblContSeller, lblContentShip;
    @FXML private Label lblSign, lblSign1, lblSign11;
    @FXML private ScrollPane scrollPane;


    private final List<Image> images = new ArrayList<>();
    private int currentIndex = 0;
    private ImageView currentImageView;
    private MainController mainController;
    private Producto producto;



    @FXML
    public void initialize() {

    }
    @FXML
    private void onSave(){
        guardarProducto();
    }

    /** 🔹 Carga un producto completo desde memoria (API o galería) */
    public void loadProduct(Producto producto) {
        images.clear();
        this.producto = producto;
        // =====================
        // IMÁGENES
        // =====================
        try {
            if (producto.getImagesProductsCollection() != null && !producto.getImagesProductsCollection().isEmpty()) {
                for (ImagesProduct img : producto.getImagesProductsCollection()) {
                    try {
                        images.add(new Image(img.getUrlImg(), true));
                        System.out.println(img.getUrlImg());
                    } catch (Exception ex) {
                        System.err.println("Error cargando imagen: " + img.getUrlImg());
                    }
                }
            } else if (producto.getUrlProduct() != null && !producto.getUrlProduct().isBlank()) {
                images.add(new Image(producto.getUrlProduct(), true));
            } else {
                images.add(new Image(getClass().getResource("/recursos/imagen-rota.png").toExternalForm()));
            }
        } catch (Exception e) {
            System.err.println("Error cargando imágenes: " + e.getMessage());
        }

        // Mostrar la primera imagen
        if (!images.isEmpty()) {
            currentIndex = 0;
            currentImageView = new ImageView(images.get(currentIndex));
            currentImageView.setFitWidth(700);
            currentImageView.setFitHeight(350);
            currentImageView.setPreserveRatio(true);
            imageContainer.getChildren().setAll(currentImageView);
        }

        // =====================
        // DATOS PRINCIPALES
        // =====================
        lblTitle.setText(producto.getName());
        if (producto.getPriceHistory() != null) {
            PriceHistory ph = producto.getPriceHistory();
            lblPrice.setText(ph.getCurrency() + " " + ph.getPrice());
        } else {
            lblPrice.setText("Precio no disponible");
        }

        // =====================
        // DESCRIPCIÓN DEL PRODUCTO
        // =====================
        String descripcion = producto.getShortDescription();

        if (descripcion != null) {
            descripcion = descripcion.replaceAll("<[^>]*>", ""); // Limpia etiquetas HTML
        }

        if (descripcion == null || descripcion.isBlank()) {
            descripcion = "Sin descripción disponible.";
        } else if (descripcion.length() > 500) {
            descripcion = descripcion.substring(0, 500) + "...";
        }

        lblDescrtiption.setWrapText(true);
        lblDescrtiption.setText(descripcion);

        // =====================
        // INFORMACIÓN DETALLADA (DETALLES)
        // =====================
        TextFlow detallesFlow = new TextFlow();
        detallesFlow.setLineSpacing(4);
        javafx.scene.text.Font regular = Font.font("Poppins Light", 12);

        // Categoría
        detallesFlow.getChildren().add(new Text("• Categoría: " + producto.getIdCategory().getCategoryPath() + "\n"));

        // Condición
        detallesFlow.getChildren().add(new Text("• Condición: " + producto.getIdCondition().getConditionPath() + "\n"));

        // Disponibilidad
        String disp = (producto.getAvailable() != null && producto.getAvailable() == 1) ? "En stock" : "Agotado";
        detallesFlow.getChildren().add(new Text("• Disponibilidad: " + disp + "\n"));

        // Cupón
        String cupon = (producto.getIdCoupon() != null)
                ? producto.getIdCoupon().getCouponRedemption()
                : "Ninguno";
        detallesFlow.getChildren().add(new Text("• Cupón disponible: " + cupon + "\n"));

        // Devoluciones
        String devol = (producto.getReturns() != null && producto.getReturns() == 1)
                ? "Aceptadas"
                : "No aceptadas";
        detallesFlow.getChildren().add(new Text("• Devoluciones: " + devol + "\n"));

        // Atributos
        if (producto.getAtributtesProductsCollection() != null && !producto.getAtributtesProductsCollection().isEmpty()) {
            detallesFlow.getChildren().add(new Text("\nAtributos:\n"));
            for (AtributtesProduct attr : producto.getAtributtesProductsCollection()) {
                detallesFlow.getChildren().add(new Text("• " + attr.getAtributte() + ": " + attr.getValue() + "\n"));
            }
        }

        lblContentDet.setGraphic(detallesFlow);

        // =====================
        // INFO DEL VENDEDOR
        // =====================
        lblContSeller.setText("• Vendedor: " + producto.getIdSeller().getUsername());

        // =====================
        // DETALLES DE ENVÍO
        // =====================
        TextFlow envioFlow = new TextFlow();
        envioFlow.setLineSpacing(4);

        if (producto.getShippingProductsCollection() != null && !producto.getShippingProductsCollection().isEmpty()) {
            for (ShippingProduct envio : producto.getShippingProductsCollection()) {
                envioFlow.getChildren().add(new Text("• " + envio.getShippingCarrier() +
                        " (" + envio.getType() + ") — USD " +
                        String.format("%.2f", envio.getShippingCost()) + "\n"));
            }
        } else {
            envioFlow.getChildren().add(new Text("No hay información de envío disponible.\n"));
        }

        lblContentShip.setGraphic(envioFlow);
    }



    // ======== CAMBIO DE IMÁGENES ========
    @FXML
    private void showNext() {
        if (images.isEmpty()) return;
        currentIndex = (currentIndex + 1) % images.size();
        changeImage(images.get(currentIndex));
    }

    @FXML
    private void showPrev() {
        if (images.isEmpty()) return;
        currentIndex = (currentIndex - 1 + images.size()) % images.size();
        changeImage(images.get(currentIndex));
    }

    private void changeImage(Image newImage) {
        ImageView nextImageView = new ImageView(newImage);
        nextImageView.setFitWidth(700);
        nextImageView.setFitHeight(350);
        nextImageView.setPreserveRatio(true);

        FadeTransition fadeOut = new FadeTransition(Duration.millis(250), currentImageView);
        fadeOut.setFromValue(1);
        fadeOut.setToValue(0);

        FadeTransition fadeIn = new FadeTransition(Duration.millis(250), nextImageView);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);

        fadeOut.setOnFinished(e -> {
            imageContainer.getChildren().setAll(nextImageView);
            fadeIn.play();
            currentImageView = nextImageView;
        });
        fadeOut.play();
    }

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    // ======== SECCIONES DESPLEGABLES ========
    @FXML
    private void toggleDetails() {
        toggleSection(lblContentDet, lblSign);
    }

    @FXML
    private void toggleSeller() {
        toggleSection(lblContSeller, lblSign1);
    }

    @FXML
    private void toggleShip() {
        toggleSection(lblContentShip, lblSign11);
    }
    @FXML
    private void onRederict() {
        System.out.println("🔗 onRederict() llamado");

        if (producto == null) {
            System.err.println("❌ ERROR: producto es null en onRederict()");
            NotificationManager.error("Error: No se puede abrir el enlace del producto");
            return;
        }

        if (producto.getUrlProduct() == null || producto.getUrlProduct().isEmpty()) {
            System.err.println("❌ ERROR: producto.getUrlProduct() es null o vacío");
            NotificationManager.error("Error: El producto no tiene URL disponible");
            return;
        }

        try {
            System.out.println("✅ Abriendo URL: " + producto.getUrlProduct());
            Desktop.getDesktop().browse(new URI(producto.getUrlProduct()));
        } catch (Exception e) {
            System.err.println("❌ ERROR abriendo URL:");
            e.printStackTrace();
            NotificationManager.error("Error al abrir el navegador: " + e.getMessage());
        }
    }

    private void toggleSection(Label contentLabel, Label signLabel) {
        boolean visible = contentLabel.isVisible();
        contentLabel.setVisible(!visible);
        contentLabel.setManaged(!visible);
        signLabel.setText(visible ? "+" : "–");
    }

    @FXML
    protected void guardarProducto() {
            if (producto == null) {
                System.err.println("❌ Producto no puede ser nulo");
                NotificationManager.error("No hay producto para guardar");
                return;
            }

            // ✅ EXTRAER DATOS DE COLECCIONES LAZY ANTES DE OPERACIONES DE BD
            List<String> urlsImagenesAPI = new ArrayList<>();
            List<AtributtesProduct> atributosAPI = new ArrayList<>();
            List<ShippingProduct> enviosAPI = new ArrayList<>();

            if (producto.getImagesProductsCollection() != null) {
                for (ImagesProduct img : producto.getImagesProductsCollection()) {
                    urlsImagenesAPI.add(img.getUrlImg());
                }
            }

            if (producto.getAtributtesProductsCollection() != null) {
                for (AtributtesProduct attr : producto.getAtributtesProductsCollection()) {
                    atributosAPI.add(attr);
                }
            }

            if (producto.getShippingProductsCollection() != null) {
                for (ShippingProduct envio : producto.getShippingProductsCollection()) {
                    enviosAPI.add(envio);
                }
            }

            System.out.println("\n========================================");
            System.out.println("💾 INICIANDO GUARDADO DE PRODUCTO");
            // ... resto del código
        System.out.println("========================================");
        System.out.println("📦 Producto: " + producto.getName());
        System.out.println("   ItemId: " + producto.getItemId());

        try {
            // =====================
            // 1️⃣ GUARDAR VENDEDOR
            // =====================
            System.out.println("\n1️⃣ Procesando vendedor...");

            SellerJpaController sellerJPA = new SellerJpaController();
            MarketplacesJpaController marketplaceJPA = new MarketplacesJpaController();

            Marketplace m = marketplaceJPA.findMarketplaces(1);

            String username = producto.getIdSeller().getUsername();
            int feedbackScore = producto.getIdSeller().getFeedbackScore();
            double feedbackPercentage = producto.getIdSeller().getFeedbackPorcentage();

            // Buscar si el vendedor ya existe
            Seller vendedorPersistido = sellerJPA.findSellerByUsername(username);

            if (vendedorPersistido == null) {
                // Si no existe → crear uno nuevo
                cls_browseEBAY ebay = new cls_browseEBAY();
                vendedorPersistido = new Seller();
                vendedorPersistido.setUsername(username);
                vendedorPersistido.setFeedbackScore(feedbackScore);
                vendedorPersistido.setFeedbackPorcentage(feedbackPercentage);
                vendedorPersistido.setIdMarketplace(m);
                vendedorPersistido.setCreatedAt(ebay.calcularAccountAge(Sesion.getTokenAPI(), vendedorPersistido.getUsername()).getOrDefault("antiguedad", "Desconocida"));
                sellerJPA.create(vendedorPersistido);
                System.out.println("Vendedor creado: " + username);
            } else {
                System.out.println("Vendedor ya existe: " + username);
            }

            // Asignar el vendedor persistido al producto
            producto.setIdSeller(vendedorPersistido);


            // =====================
            // 2️⃣ GUARDAR CATEGORÍA
            // =====================
            System.out.println("\nProcesando categoría...");

            CategoryProductsJpaController categoryJPA = new CategoryProductsJpaController();

            Integer idCat = producto.getIdCategory().getIdCategory();
            String nombreCat = producto.getIdCategory().getCategoryPath();

            // Si no existe, se guarda
            if (categoryJPA.findCategoryProducts(idCat) == null) {
                CategoryProduct nuevaCategoria = new CategoryProduct();
                nuevaCategoria.setIdCategory(idCat);
                nuevaCategoria.setCategoryPath(nombreCat);
                categoryJPA.create(nuevaCategoria);
                System.out.println("Categoría guardada: " + nombreCat);
            } else {
                System.out.println("Categoría ya existente: " + nombreCat);
            }

            // Recuperar la categoría persistida y asignarla al producto
            CategoryProduct categoriaPersistida = categoryJPA.findCategoryProducts(idCat);
            producto.setIdCategory(categoriaPersistida);


            // =====================
            // 3️⃣ GUARDAR CONDICIÓN
            // =====================
            System.out.println("\n3️⃣ Procesando condición...");

            ConditionProductsJpaController conditionJPA = new ConditionProductsJpaController();

            Integer idCond = producto.getIdCondition().getIdCondition();
            String nombreCond = producto.getIdCondition().getConditionPath();

            // Verificar por ID
            if (conditionJPA.findConditionByID(idCond) == null) {
                ConditionProduct nuevaCondicion = new ConditionProduct();
                nuevaCondicion.setIdCondition(idCond);
                nuevaCondicion.setConditionPath(nombreCond);
                conditionJPA.create(nuevaCondicion);
                System.out.println("Condición guardada: " + nombreCond);
            } else {
                System.out.println("Condición ya existente: " + nombreCond);
            }

            // Recuperar la condición persistida y asignarla al producto
            ConditionProduct condicionPersistida = conditionJPA.findConditionByID(idCond);
            producto.setIdCondition(condicionPersistida);


            // =====================
            // 4️⃣ GUARDAR CUPÓN (si existe)
            // =====================
            System.out.println("\nProcesando cupón...");

            CouponPro cuponPersistido = null;

            if (producto.getIdCoupon() != null) {
                CouponProJpaController couponJPA = new CouponProJpaController();

                String code = producto.getIdCoupon().getCouponRedemption();
                String itemId = producto.getItemId();
                String expiration = producto.getIdCoupon().getExpirationAt();

                if (couponJPA.findByIdItem(itemId) == null) {
                    CouponPro nuevoCupon = new CouponPro();
                    nuevoCupon.setCouponRedemption(code);
                    nuevoCupon.setItemId(itemId);
                    nuevoCupon.setExpirationAt(expiration);
                    couponJPA.create(nuevoCupon);
                    System.out.println("Cupón guardado: " + code);
                } else {
                    System.out.println("Cupón ya existente: " + code);
                }

                // Recuperar el cupón persistido
                cuponPersistido = couponJPA.findByIdItem(itemId);
                producto.setIdCoupon(cuponPersistido);
            } else {
                System.out.println("No hay cupón para este producto");
            }


            // =====================
            // 5️⃣ GUARDAR PRODUCTO
            // =====================
            System.out.println("\nProcesando producto...");

            ProductosJpaController productJPA = new ProductosJpaController();

            if (productJPA.findProductos(producto.getItemId()) == null) {
                System.out.println("Creando nuevo producto en BD...");

                // Referencias ya persistidas
                Seller vendedor = producto.getIdSeller();
                CategoryProduct categoria = producto.getIdCategory();
                ConditionProduct condicion = producto.getIdCondition();

                // Crear nuevo objeto con TODOS los campos
                Producto nuevoProducto = new Producto();

                // CAMPOS BÁSICOS (CRÍTICOS)
                nuevoProducto.setItemId(producto.getItemId());
                nuevoProducto.setName(producto.getName());
                nuevoProducto.setUrlProduct(producto.getUrlProduct());
                nuevoProducto.setShortDescription(producto.getShortDescription());
                nuevoProducto.setRatedPrduct(producto.getRatedPrduct());
                nuevoProducto.setReturns(producto.getReturns());
                nuevoProducto.setAvailable(producto.getAvailable());
                nuevoProducto.setCreatedAt(producto.getCreatedAt());

                // RELACIONES (ya persistidas anteriormente)
                nuevoProducto.setIdSeller(vendedor);
                nuevoProducto.setIdCategory(categoria);
                nuevoProducto.setIdCondition(condicion);
                nuevoProducto.setIdCoupon(cuponPersistido);

                // INICIALIZAR COLECCIONES VACÍAS
                nuevoProducto.setImagesProductsCollection(new ArrayList<>());
                nuevoProducto.setAtributtesProductsCollection(new ArrayList<>());
                nuevoProducto.setShippingProductsCollection(new ArrayList<>());

                try {
                    productJPA.create(nuevoProducto);
                    System.out.println("Producto guardado: " + nuevoProducto.getName() + " (ID: " + nuevoProducto.getItemId() + ")");

                    // Actualizar la referencia local para las siguientes operaciones
                    producto = nuevoProducto;

                } catch (Exception ex) {
                    System.err.println("Error guardando producto:");
                    ex.printStackTrace();
                    NotificationManager.error("Error al guardar producto");
                    return;
                }

            } else {
                System.out.println("El producto ya existe en BD: " + producto.getItemId());
                // Recuperar el producto existente para usarlo en las siguientes operaciones
                producto = productJPA.findProductos(producto.getItemId());
            }


// =====================
// 6️⃣ Guardar IMÁGENES
// =====================
            System.out.println("\nProcesando imágenes...");

            if (!urlsImagenesAPI.isEmpty()) {

                ImagesProductsJpaController imgJPA = new ImagesProductsJpaController();
                Producto productoPersistido = productJPA.findProductos(producto.getItemId());

                int count = 0;
                for (String url : urlsImagenesAPI) {
                    try {
                        ImagesProduct img = new ImagesProduct();
                        img.setItem(productoPersistido);
                        img.setUrlImg(url);

                        imgJPA.create(img);
                        count++;

                        System.out.println("✅ Imagen guardada: " + url);
                    } catch (Exception ex) {
                        System.out.println("ℹ️ Imagen duplicada: " + url);
                    }
                }

                System.out.println("Total imágenes guardadas: " + count);
            } else {
                System.out.println("⚠️ No hay imágenes del API para guardar");
            }




// =====================
// 7️⃣ GUARDAR ATRIBUTOS
// =====================
            System.out.println("\nProcesando atributos...");

            if (!atributosAPI.isEmpty()) {  // ✅ Usar atributosAPI
                AtributtesProductJpaController attrJPA = new AtributtesProductJpaController();

                // Recuperar el producto persistido
                Producto productoPersistido = productJPA.findProductos(producto.getItemId());

                if (productoPersistido == null) {
                    System.err.println("No se pueden guardar atributos: producto no encontrado en BD");
                } else {
                    int attrCount = 0;
                    for (AtributtesProduct attr : atributosAPI) {  // ✅ Usar atributosAPI
                        attr.setIdItem(productoPersistido);

                        if (attrJPA.findAtributtesProductsByIdItem(producto.getItemId(), attr.getAtributte()) == null) {
                            try {
                                attrJPA.create(attr);
                                attrCount++;
                                System.out.println("Atributo guardado: " + attr.getAtributte());
                            } catch (Exception ex) {
                                System.err.println("Error guardando atributo: " + ex.getMessage());
                            }
                        } else {
                            System.out.println("Atributo ya existente: " + attr.getAtributte());
                        }
                    }
                    System.out.println("Total atributos procesados: " + attrCount);
                }
            } else {
                System.out.println("No hay atributos para guardar");
            }

            // =====================
            // 8️⃣ Guardar OPCIONES DE ENVÍO
            // =====================
            System.out.println("\nProcesando opciones de envío...");

            if (!enviosAPI.isEmpty()) {  // ✅ Usar enviosAPI
                ShippingProductsJpaController shipJPA = new ShippingProductsJpaController();

                // Recuperar el producto persistido
                Producto productoPersistido = productJPA.findProductos(producto.getItemId());

                if (productoPersistido == null) {
                    System.err.println("No se pueden guardar opciones de envío: producto no encontrado en BD");
                } else {
                    int shipCount = 0;
                    for (ShippingProduct envio : enviosAPI) {  // ✅ Usar enviosAPI
                        envio.setItem(productoPersistido);

                        if (shipJPA.findShippingByItemID(producto.getItemId(), envio.getType()) == null) {
                            try {
                                shipJPA.create(envio);
                                shipCount++;
                                System.out.println("Envío guardado: " + envio.getShippingCarrier());
                            } catch (Exception ex) {
                                System.err.println("Error guardando envío: " + ex.getMessage());
                            }
                        } else {
                            System.out.println("Envío ya existente: " + envio.getShippingCarrier());
                        }
                    }
                    System.out.println("Total envíos procesados: " + shipCount);
                }
            } else {
                System.out.println("No hay opciones de envío para guardar");
            }

            // =====================
            // 9️⃣ Guardar HISTORIAL DE PRECIO
            // =====================
            System.out.println("\nProcesando historial de precio...");

            if (producto.getPriceHistory() != null) {
                PriceHistoryJpaController priceJPA = new PriceHistoryJpaController();

                if (priceJPA.findPriceHistoryByItemIDANDDate(producto.getItemId(), producto.getPriceHistory().getRecordedAt()) == null) {
                    try {
                        PriceHistory priceHistory = new PriceHistory();
                        priceHistory.setItemId(producto.getItemId());
                        priceHistory.setPrice(producto.getPriceHistory().getPrice());
                        priceHistory.setCurrency(producto.getPriceHistory().getCurrency());
                        priceHistory.setRecordedAt(producto.getPriceHistory().getRecordedAt());
                        priceJPA.create(priceHistory);
                        System.out.println("Historial de precio guardado");
                    } catch (Exception ex) {
                        System.err.println("Error guardando historial de precio: " + ex.getMessage());
                    }
                } else {
                    System.out.println("El historial de precio ya existe para esta fecha");
                }
            } else {
                System.out.println("No hay historial de precio para guardar");
            }


            // =====================
            // 🔟 GUARDAR EN WISHLIST
            // =====================
            System.out.println("\nProcesando wishlist...");

            try {
                WishlistProductsJpaController wishlistJPA = new WishlistProductsJpaController();
                Auth usuario = Sesion.getUsuario();

                if (usuario == null) {
                    System.err.println("No hay usuario en sesión");
                    NotificationManager.error("Debes iniciar sesión para guardar en tu lista");
                    return;
                }

                // Buscar el producto en BD
                Producto productoBD = productJPA.findProductos(producto.getItemId());

                if (productoBD == null) {
                    System.err.println("No se pudo guardar en wishlist: producto no encontrado en BD");
                    NotificationManager.error("Error: producto no encontrado");
                    return;
                }

                // Validar que no exista ya en wishlist
                if (wishlistJPA.findWishlistProductsByProduct(usuario.getId(), productoBD.getItemId()) == null) {
                    WishlistProduct nuevo = new WishlistProduct();
                    nuevo.setIdUser(usuario);
                    nuevo.setIdItem(productoBD);

                    wishlistJPA.create(nuevo);
                    System.out.println("Producto añadido a wishlist");
                    producto = productJPA.findProductosWithCollections(producto.getItemId());
                    // Actualizar contador en MainController
                    if (mainController != null) {
                        System.out.println("Actualizando contador de wishlist...");
                        mainController.actualizarWishlistCount();
                    }

                    NotificationManager.success("Producto guardado en tu lista");
                } else {
                    System.out.println("Producto ya estaba en wishlist");
                    producto = productJPA.findProductosWithCollections(producto.getItemId());
                    NotificationManager.info("Este producto ya está en tu lista");
                }

            } catch (Exception ex) {
                System.err.println("Error guardando en wishlist: " + ex.getMessage());
                ex.printStackTrace();
                NotificationManager.error("Error al guardar en wishlist");
            }

            System.out.println("\n========================================");
            System.out.println("PROCESO COMPLETADO EXITOSAMENTE");
            System.out.println("========================================\n");

        } catch (Exception e) {
            System.err.println("\n========================================");
            System.err.println("ERROR CRÍTICO EN GUARDADO");
            System.err.println("========================================");
            System.err.println("Mensaje: " + e.getMessage());
            System.err.println("Tipo: " + e.getClass().getName());
            e.printStackTrace();
            System.err.println("========================================\n");

            NotificationManager.error("Error al guardar producto: " + e.getMessage());
        }
    }


}
