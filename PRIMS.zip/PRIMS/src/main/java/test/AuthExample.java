package test;

import controllersJPA.AuthJpaController;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;
import entities.Auth;

/**
 * Ejemplo de uso del AuthJpaController
 */
public class AuthExample {

    public static void main(String[] args) {

        // Crear el controller
        AuthJpaController authController = new AuthJpaController();

        try {
            // ===== CREAR UN USUARIO =====
            System.out.println("=== Creando usuario ===");
            Auth nuevoUsuario = new Auth();
            nuevoUsuario.setUsername("juanperez");
            nuevoUsuario.setEmail("juan@example.com");
            nuevoUsuario.setPasswordHash("$2a$10$hashed_password_here"); // En producción usar BCrypt

            authController.create(nuevoUsuario);
            System.out.println("Usuario creado con ID: " + nuevoUsuario.getId());


            // ===== LISTAR TODOS LOS USUARIOS =====
            System.out.println("\n=== Listando todos los usuarios ===");
            List<Auth> usuarios = authController.findAuthEntities();
            System.out.println("Total de usuarios: " + usuarios.size());
            for (Auth u : usuarios) {
                System.out.println("- " + u.getUsername() + " (" + u.getEmail() + ")");
            }

            // ===== BUSCAR POR ID =====
            System.out.println("\n=== Buscando por ID ===");
            Auth porId = authController.findAuth(nuevoUsuario.getId());
            if (porId != null) {
                System.out.println("Usuario con ID " + porId.getId() + ": " + porId.getUsername());
            }

            // ===== CONTAR USUARIOS =====
            System.out.println("\n=== Contando usuarios ===");
            int total = authController.getAuthCount();
            System.out.println("Total de usuarios en BD: " + total);

            // ===== PAGINACIÓN =====
            System.out.println("\n=== Probando paginación ===");
            List<Auth> pagina1 = authController.findAuthEntities(10, 0); // Primeros 10
            System.out.println("Usuarios en página 1: " + pagina1.size());

            // ===== ELIMINAR USUARIO =====
            System.out.println("\n=== Eliminando usuario ===");
            authController.destroy(nuevoUsuario.getId());
            System.out.println("Usuario eliminado con éxito");

            System.out.println("\n=== Operaciones completadas ===");

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
