package utils;


import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class JPAUtil {

    private static EntityManagerFactory entityManagerFactory;

    // Bloque estático para inicializar UNA SOLA VEZ
    static {
        try {
            entityManagerFactory = Persistence.createEntityManagerFactory("prims");
            System.out.println("✅ EntityManagerFactory inicializado");
        } catch (Exception e) {
            System.err.println("❌ Error inicializando EntityManagerFactory:");
            e.printStackTrace();
            throw new ExceptionInInitializerError(e);
        }
    }

    public static EntityManagerFactory getEntityManagerFactory() {
        return entityManagerFactory;
    }

    public static void close() {
        if (entityManagerFactory != null && entityManagerFactory.isOpen()) {
            entityManagerFactory.close();
            System.out.println("✅ EntityManagerFactory cerrado");
        }
    }
}