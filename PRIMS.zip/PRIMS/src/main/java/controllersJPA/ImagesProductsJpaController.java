package controllersJPA;

import controllersJPA.exceptions.NonexistentEntityException;
import entities.ImagesProduct;
import entities.Producto;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.List;

public class ImagesProductsJpaController implements Serializable {

    public ImagesProductsJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(ImagesProduct imagesProducts) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Producto itemId = imagesProducts.getItem();
            if (itemId != null) {
                itemId = em.getReference(itemId.getClass(), itemId.getItemId());
                imagesProducts.setItem(itemId);
            }
            em.persist(imagesProducts);
            if (itemId != null) {
                itemId.getImagesProductsCollection().add(imagesProducts);
                itemId = em.merge(itemId);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(ImagesProduct imagesProducts) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ImagesProduct persistentImagesProducts = em.find(ImagesProduct.class, imagesProducts.getId());
            Producto itemIdOld = persistentImagesProducts.getItem();
            Producto itemIdNew = imagesProducts.getItem();
            if (itemIdNew != null) {
                itemIdNew = em.getReference(itemIdNew.getClass(), itemIdNew.getItemId());
                imagesProducts.setItem(itemIdNew);
            }
            imagesProducts = em.merge(imagesProducts);
            if (itemIdOld != null && !itemIdOld.equals(itemIdNew)) {
                itemIdOld.getImagesProductsCollection().remove(imagesProducts);
                itemIdOld = em.merge(itemIdOld);
            }
            if (itemIdNew != null && !itemIdNew.equals(itemIdOld)) {
                itemIdNew.getImagesProductsCollection().add(imagesProducts);
                itemIdNew = em.merge(itemIdNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = imagesProducts.getId();
                if (findImagesProducts(id) == null) {
                    throw new NonexistentEntityException("The imagesProducts with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ImagesProduct imagesProducts;
            try {
                imagesProducts = em.getReference(ImagesProduct.class, id);
                imagesProducts.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The imagesProducts with id " + id + " no longer exists.", enfe);
            }
            Producto itemId = imagesProducts.getItem();
            if (itemId != null) {
                itemId.getImagesProductsCollection().remove(imagesProducts);
                itemId = em.merge(itemId);
            }
            em.remove(imagesProducts);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<ImagesProduct> findImagesProductsEntities() {
        return findImagesProductsEntities(true, -1, -1);
    }

    public List<ImagesProduct> findImagesProductsEntities(int maxResults, int firstResult) {
        return findImagesProductsEntities(false, maxResults, firstResult);
    }

    private List<ImagesProduct> findImagesProductsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(ImagesProduct.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public ImagesProduct findImagesProducts(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ImagesProduct.class, id);
        } finally {
            em.close();
        }
    }
    public String findImagesProductsById(String id) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<ImagesProduct> query = em.createNamedQuery("ImagesProducts.findByItemID", ImagesProduct.class);
            query.setParameter("itemId", id);
            ImagesProduct imagesProducts = query.getSingleResult();
            return imagesProducts.getUrlImg();
        }catch(Exception ex){
            return null;
        }finally {
            em.close();
        }
    }

    public int getImagesProductsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<ImagesProduct> rt = cq.from(ImagesProduct.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}

