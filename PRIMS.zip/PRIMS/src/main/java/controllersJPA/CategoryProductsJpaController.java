package controllersJPA;

import controllersJPA.exceptions.IllegalOrphanException;
import controllersJPA.exceptions.NonexistentEntityException;
import entities.CategoryProduct;
import entities.Producto;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CategoryProductsJpaController implements Serializable {

    public CategoryProductsJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }

    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(CategoryProduct categoryProducts) {
        if (categoryProducts.getProductosCollection() == null) {
            categoryProducts.setProductosCollection(new ArrayList<Producto>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Producto> attachedProductosCollection = new ArrayList<Producto>();
            for (Producto productosCollectionProductosToAttach : categoryProducts.getProductosCollection()) {
                productosCollectionProductosToAttach = em.getReference(productosCollectionProductosToAttach.getClass(), productosCollectionProductosToAttach.getItemId());
                attachedProductosCollection.add(productosCollectionProductosToAttach);
            }
            categoryProducts.setProductosCollection(attachedProductosCollection);
            em.persist(categoryProducts);
            for (Producto productosCollectionProductos : categoryProducts.getProductosCollection()) {
                CategoryProduct oldIdCategoryOfProductosCollectionProductos = productosCollectionProductos.getIdCategory();
                productosCollectionProductos.setIdCategory(categoryProducts);
                productosCollectionProductos = em.merge(productosCollectionProductos);
                if (oldIdCategoryOfProductosCollectionProductos != null) {
                    oldIdCategoryOfProductosCollectionProductos.getProductosCollection().remove(productosCollectionProductos);
                    oldIdCategoryOfProductosCollectionProductos = em.merge(oldIdCategoryOfProductosCollectionProductos);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(CategoryProduct categoryProducts) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CategoryProduct persistentCategoryProducts = em.find(CategoryProduct.class, categoryProducts.getId());
            Collection<Producto> productosCollectionOld = persistentCategoryProducts.getProductosCollection();
            Collection<Producto> productosCollectionNew = categoryProducts.getProductosCollection();
            List<String> illegalOrphanMessages = null;
            for (Producto productosCollectionOldProductos : productosCollectionOld) {
                if (!productosCollectionNew.contains(productosCollectionOldProductos)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Productos " + productosCollectionOldProductos + " since its idCategory field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Producto> attachedProductosCollectionNew = new ArrayList<Producto>();
            for (Producto productosCollectionNewProductosToAttach : productosCollectionNew) {
                productosCollectionNewProductosToAttach = em.getReference(productosCollectionNewProductosToAttach.getClass(), productosCollectionNewProductosToAttach.getItemId());
                attachedProductosCollectionNew.add(productosCollectionNewProductosToAttach);
            }
            productosCollectionNew = attachedProductosCollectionNew;
            categoryProducts.setProductosCollection(productosCollectionNew);
            categoryProducts = em.merge(categoryProducts);
            for (Producto productosCollectionNewProductos : productosCollectionNew) {
                if (!productosCollectionOld.contains(productosCollectionNewProductos)) {
                    CategoryProduct oldIdCategoryOfProductosCollectionNewProductos = productosCollectionNewProductos.getIdCategory();
                    productosCollectionNewProductos.setIdCategory(categoryProducts);
                    productosCollectionNewProductos = em.merge(productosCollectionNewProductos);
                    if (oldIdCategoryOfProductosCollectionNewProductos != null && !oldIdCategoryOfProductosCollectionNewProductos.equals(categoryProducts)) {
                        oldIdCategoryOfProductosCollectionNewProductos.getProductosCollection().remove(productosCollectionNewProductos);
                        oldIdCategoryOfProductosCollectionNewProductos = em.merge(oldIdCategoryOfProductosCollectionNewProductos);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = categoryProducts.getId();
                if (findCategoryProducts(id) == null) {
                    throw new NonexistentEntityException("The categoryProducts with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CategoryProduct categoryProducts;
            try {
                categoryProducts = em.getReference(CategoryProduct.class, id);
                categoryProducts.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The categoryProducts with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Producto> productosCollectionOrphanCheck = categoryProducts.getProductosCollection();
            for (Producto productosCollectionOrphanCheckProductos : productosCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This CategoryProducts (" + categoryProducts + ") cannot be destroyed since the Productos " + productosCollectionOrphanCheckProductos + " in its productosCollection field has a non-nullable idCategory field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(categoryProducts);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<CategoryProduct> findCategoryProductsEntities() {
        return findCategoryProductsEntities(true, -1, -1);
    }

    public List<CategoryProduct> findCategoryProductsEntities(int maxResults, int firstResult) {
        return findCategoryProductsEntities(false, maxResults, firstResult);
    }

    private List<CategoryProduct> findCategoryProductsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(CategoryProduct.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public CategoryProduct findCategoryProducts(Integer id) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<CategoryProduct> query = em.createNamedQuery("CategoryProducts.findByIdCategory", CategoryProduct.class);
            query.setParameter("idCategory", id);
            CategoryProduct categoryProducts = query.getSingleResult();
            return categoryProducts;
        }catch(Exception ex){
            System.err.println(ex);
            return null;

        } finally {
            em.close();
        }
    }

    public int getCategoryProductsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<CategoryProduct> rt = cq.from(CategoryProduct.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
}

