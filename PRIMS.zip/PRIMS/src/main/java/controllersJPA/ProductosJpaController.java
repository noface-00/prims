package controllersJPA;

import controllersJPA.exceptions.IllegalOrphanException;
import controllersJPA.exceptions.NonexistentEntityException;
import controllersJPA.exceptions.PreexistingEntityException;
import entities.*;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ProductosJpaController implements Serializable {

    public ProductosJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Producto productos) throws PreexistingEntityException, Exception {
        if (productos.getWishlistProductsCollection() == null) {
            productos.setWishlistProductsCollection(new ArrayList<WishlistProduct>());
        }
        if (productos.getShippingProductsCollection() == null) {
            productos.setShippingProductsCollection(new ArrayList<ShippingProduct>());
        }
        if (productos.getAtributtesProductsCollection() == null) {
            productos.setAtributtesProductsCollection(new ArrayList<AtributtesProduct>());
        }
        if (productos.getImagesProductsCollection() == null) {
            productos.setImagesProductsCollection(new ArrayList<ImagesProduct>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CategoryProduct idCategory = productos.getIdCategory();
            if (idCategory != null) {
                idCategory = em.getReference(idCategory.getClass(), idCategory.getId());
                productos.setIdCategory(idCategory);
            }
            ConditionProduct idCondition = productos.getIdCondition();
            if (idCondition != null) {
                idCondition = em.getReference(idCondition.getClass(), idCondition.getId());
                productos.setIdCondition(idCondition);
            }
            CouponPro idCoupon = productos.getIdCoupon();
            if (idCoupon != null) {
                idCoupon = em.getReference(idCoupon.getClass(), idCoupon.getId());
                productos.setIdCoupon(idCoupon);
            }
            Seller idSeller = productos.getIdSeller();
            if (idSeller != null) {
                idSeller = em.getReference(idSeller.getClass(), idSeller.getId());
                productos.setIdSeller(idSeller);
            }
            Collection<WishlistProduct> attachedWishlistProductsCollection = new ArrayList<WishlistProduct>();
            for (WishlistProduct wishlistProductsCollectionWishlistProductsToAttach : productos.getWishlistProductsCollection()) {
                wishlistProductsCollectionWishlistProductsToAttach = em.getReference(wishlistProductsCollectionWishlistProductsToAttach.getClass(), wishlistProductsCollectionWishlistProductsToAttach.getId());
                attachedWishlistProductsCollection.add(wishlistProductsCollectionWishlistProductsToAttach);
            }
            productos.setWishlistProductsCollection(attachedWishlistProductsCollection);
            Collection<ShippingProduct> attachedShippingProductsCollection = new ArrayList<ShippingProduct>();
            for (ShippingProduct shippingProductsCollectionShippingProductsToAttach : productos.getShippingProductsCollection()) {
                shippingProductsCollectionShippingProductsToAttach = em.getReference(shippingProductsCollectionShippingProductsToAttach.getClass(), shippingProductsCollectionShippingProductsToAttach.getId());
                attachedShippingProductsCollection.add(shippingProductsCollectionShippingProductsToAttach);
            }
            productos.setShippingProductsCollection(attachedShippingProductsCollection);
            Collection<AtributtesProduct> attachedAtributtesProductsCollection = new ArrayList<AtributtesProduct>();
            for (AtributtesProduct atributtesProductsCollectionAtributtesProductsToAttach : productos.getAtributtesProductsCollection()) {
                atributtesProductsCollectionAtributtesProductsToAttach = em.getReference(atributtesProductsCollectionAtributtesProductsToAttach.getClass(), atributtesProductsCollectionAtributtesProductsToAttach.getId());
                attachedAtributtesProductsCollection.add(atributtesProductsCollectionAtributtesProductsToAttach);
            }
            productos.setAtributtesProductsCollection(attachedAtributtesProductsCollection);
            Collection<ImagesProduct> attachedImagesProductsCollection = new ArrayList<ImagesProduct>();
            for (ImagesProduct imagesProductsCollectionImagesProductsToAttach : productos.getImagesProductsCollection()) {
                imagesProductsCollectionImagesProductsToAttach = em.getReference(imagesProductsCollectionImagesProductsToAttach.getClass(), imagesProductsCollectionImagesProductsToAttach.getId());
                attachedImagesProductsCollection.add(imagesProductsCollectionImagesProductsToAttach);
            }
            productos.setImagesProductsCollection(attachedImagesProductsCollection);
            em.persist(productos);
            if (idCategory != null) {
                idCategory.getProductosCollection().add(productos);
                idCategory = em.merge(idCategory);
            }
            if (idCondition != null) {
                idCondition.getProductosCollection().add(productos);
                idCondition = em.merge(idCondition);
            }
            if (idCoupon != null) {
                idCoupon.getProductosCollection().add(productos);
                idCoupon = em.merge(idCoupon);
            }
            if (idSeller != null) {
                idSeller.getProductosCollection().add(productos);
                idSeller = em.merge(idSeller);
            }
            for (WishlistProduct wishlistProductsCollectionWishlistProducts : productos.getWishlistProductsCollection()) {
                Producto oldIdItemOfWishlistProductsCollectionWishlistProducts = wishlistProductsCollectionWishlistProducts.getIdItem();
                wishlistProductsCollectionWishlistProducts.setIdItem(productos);
                wishlistProductsCollectionWishlistProducts = em.merge(wishlistProductsCollectionWishlistProducts);
                if (oldIdItemOfWishlistProductsCollectionWishlistProducts != null) {
                    oldIdItemOfWishlistProductsCollectionWishlistProducts.getWishlistProductsCollection().remove(wishlistProductsCollectionWishlistProducts);
                    oldIdItemOfWishlistProductsCollectionWishlistProducts = em.merge(oldIdItemOfWishlistProductsCollectionWishlistProducts);
                }
            }
            for (ShippingProduct shippingProductsCollectionShippingProducts : productos.getShippingProductsCollection()) {
                Producto oldItemIdOfShippingProductsCollectionShippingProducts = shippingProductsCollectionShippingProducts.getItem();
                shippingProductsCollectionShippingProducts.setItem(productos);
                shippingProductsCollectionShippingProducts = em.merge(shippingProductsCollectionShippingProducts);
                if (oldItemIdOfShippingProductsCollectionShippingProducts != null) {
                    oldItemIdOfShippingProductsCollectionShippingProducts.getShippingProductsCollection().remove(shippingProductsCollectionShippingProducts);
                    oldItemIdOfShippingProductsCollectionShippingProducts = em.merge(oldItemIdOfShippingProductsCollectionShippingProducts);
                }
            }
            for (AtributtesProduct atributtesProductsCollectionAtributtesProducts : productos.getAtributtesProductsCollection()) {
                Producto oldIdItemOfAtributtesProductsCollectionAtributtesProducts = atributtesProductsCollectionAtributtesProducts.getIdItem();
                atributtesProductsCollectionAtributtesProducts.setIdItem(productos);
                atributtesProductsCollectionAtributtesProducts = em.merge(atributtesProductsCollectionAtributtesProducts);
                if (oldIdItemOfAtributtesProductsCollectionAtributtesProducts != null) {
                    oldIdItemOfAtributtesProductsCollectionAtributtesProducts.getAtributtesProductsCollection().remove(atributtesProductsCollectionAtributtesProducts);
                    oldIdItemOfAtributtesProductsCollectionAtributtesProducts = em.merge(oldIdItemOfAtributtesProductsCollectionAtributtesProducts);
                }
            }
            for (ImagesProduct imagesProductsCollectionImagesProducts : productos.getImagesProductsCollection()) {
                Producto oldItemIdOfImagesProductsCollectionImagesProducts = imagesProductsCollectionImagesProducts.getItem();
                imagesProductsCollectionImagesProducts.setItem(productos);
                imagesProductsCollectionImagesProducts = em.merge(imagesProductsCollectionImagesProducts);
                if (oldItemIdOfImagesProductsCollectionImagesProducts != null) {
                    oldItemIdOfImagesProductsCollectionImagesProducts.getImagesProductsCollection().remove(imagesProductsCollectionImagesProducts);
                    oldItemIdOfImagesProductsCollectionImagesProducts = em.merge(oldItemIdOfImagesProductsCollectionImagesProducts);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findProductos(productos.getItemId()) != null) {
                throw new PreexistingEntityException("Productos " + productos + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Producto productos) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Producto persistentProductos = em.find(Producto.class, productos.getItemId());
            CategoryProduct idCategoryOld = persistentProductos.getIdCategory();
            CategoryProduct idCategoryNew = productos.getIdCategory();
            ConditionProduct idConditionOld = persistentProductos.getIdCondition();
            ConditionProduct idConditionNew = productos.getIdCondition();
            CouponPro idCouponOld = persistentProductos.getIdCoupon();
            CouponPro idCouponNew = productos.getIdCoupon();
            Seller idSellerOld = persistentProductos.getIdSeller();
            Seller idSellerNew = productos.getIdSeller();
            Collection<WishlistProduct> wishlistProductsCollectionOld = persistentProductos.getWishlistProductsCollection();
            Collection<WishlistProduct> wishlistProductsCollectionNew = productos.getWishlistProductsCollection();
            Collection<ShippingProduct> shippingProductsCollectionOld = persistentProductos.getShippingProductsCollection();
            Collection<ShippingProduct> shippingProductsCollectionNew = productos.getShippingProductsCollection();
            Collection<AtributtesProduct> atributtesProductsCollectionOld = persistentProductos.getAtributtesProductsCollection();
            Collection<AtributtesProduct> atributtesProductsCollectionNew = productos.getAtributtesProductsCollection();
            Collection<ImagesProduct> imagesProductsCollectionOld = persistentProductos.getImagesProductsCollection();
            Collection<ImagesProduct> imagesProductsCollectionNew = productos.getImagesProductsCollection();
            List<String> illegalOrphanMessages = null;
            for (WishlistProduct wishlistProductsCollectionOldWishlistProducts : wishlistProductsCollectionOld) {
                if (!wishlistProductsCollectionNew.contains(wishlistProductsCollectionOldWishlistProducts)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain WishlistProducts " + wishlistProductsCollectionOldWishlistProducts + " since its idItem field is not nullable.");
                }
            }
            for (ShippingProduct shippingProductsCollectionOldShippingProducts : shippingProductsCollectionOld) {
                if (!shippingProductsCollectionNew.contains(shippingProductsCollectionOldShippingProducts)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain ShippingProducts " + shippingProductsCollectionOldShippingProducts + " since its itemId field is not nullable.");
                }
            }
            for (AtributtesProduct atributtesProductsCollectionOldAtributtesProducts : atributtesProductsCollectionOld) {
                if (!atributtesProductsCollectionNew.contains(atributtesProductsCollectionOldAtributtesProducts)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain AtributtesProducts " + atributtesProductsCollectionOldAtributtesProducts + " since its idItem field is not nullable.");
                }
            }
            for (ImagesProduct imagesProductsCollectionOldImagesProducts : imagesProductsCollectionOld) {
                if (!imagesProductsCollectionNew.contains(imagesProductsCollectionOldImagesProducts)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain ImagesProducts " + imagesProductsCollectionOldImagesProducts + " since its itemId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (idCategoryNew != null) {
                idCategoryNew = em.getReference(idCategoryNew.getClass(), idCategoryNew.getId());
                productos.setIdCategory(idCategoryNew);
            }
            if (idConditionNew != null) {
                idConditionNew = em.getReference(idConditionNew.getClass(), idConditionNew.getId());
                productos.setIdCondition(idConditionNew);
            }
            if (idCouponNew != null) {
                idCouponNew = em.getReference(idCouponNew.getClass(), idCouponNew.getId());
                productos.setIdCoupon(idCouponNew);
            }
            if (idSellerNew != null) {
                idSellerNew = em.getReference(idSellerNew.getClass(), idSellerNew.getId());
                productos.setIdSeller(idSellerNew);
            }
            Collection<WishlistProduct> attachedWishlistProductsCollectionNew = new ArrayList<WishlistProduct>();
            for (WishlistProduct wishlistProductsCollectionNewWishlistProductsToAttach : wishlistProductsCollectionNew) {
                wishlistProductsCollectionNewWishlistProductsToAttach = em.getReference(wishlistProductsCollectionNewWishlistProductsToAttach.getClass(), wishlistProductsCollectionNewWishlistProductsToAttach.getId());
                attachedWishlistProductsCollectionNew.add(wishlistProductsCollectionNewWishlistProductsToAttach);
            }
            wishlistProductsCollectionNew = attachedWishlistProductsCollectionNew;
            productos.setWishlistProductsCollection(wishlistProductsCollectionNew);
            Collection<ShippingProduct> attachedShippingProductsCollectionNew = new ArrayList<ShippingProduct>();
            for (ShippingProduct shippingProductsCollectionNewShippingProductsToAttach : shippingProductsCollectionNew) {
                shippingProductsCollectionNewShippingProductsToAttach = em.getReference(shippingProductsCollectionNewShippingProductsToAttach.getClass(), shippingProductsCollectionNewShippingProductsToAttach.getId());
                attachedShippingProductsCollectionNew.add(shippingProductsCollectionNewShippingProductsToAttach);
            }
            shippingProductsCollectionNew = attachedShippingProductsCollectionNew;
            productos.setShippingProductsCollection(shippingProductsCollectionNew);
            Collection<AtributtesProduct> attachedAtributtesProductsCollectionNew = new ArrayList<AtributtesProduct>();
            for (AtributtesProduct atributtesProductsCollectionNewAtributtesProductsToAttach : atributtesProductsCollectionNew) {
                atributtesProductsCollectionNewAtributtesProductsToAttach = em.getReference(atributtesProductsCollectionNewAtributtesProductsToAttach.getClass(), atributtesProductsCollectionNewAtributtesProductsToAttach.getId());
                attachedAtributtesProductsCollectionNew.add(atributtesProductsCollectionNewAtributtesProductsToAttach);
            }
            atributtesProductsCollectionNew = attachedAtributtesProductsCollectionNew;
            productos.setAtributtesProductsCollection(atributtesProductsCollectionNew);
            Collection<ImagesProduct> attachedImagesProductsCollectionNew = new ArrayList<ImagesProduct>();
            for (ImagesProduct imagesProductsCollectionNewImagesProductsToAttach : imagesProductsCollectionNew) {
                imagesProductsCollectionNewImagesProductsToAttach = em.getReference(imagesProductsCollectionNewImagesProductsToAttach.getClass(), imagesProductsCollectionNewImagesProductsToAttach.getId());
                attachedImagesProductsCollectionNew.add(imagesProductsCollectionNewImagesProductsToAttach);
            }
            imagesProductsCollectionNew = attachedImagesProductsCollectionNew;
            productos.setImagesProductsCollection(imagesProductsCollectionNew);
            productos = em.merge(productos);
            if (idCategoryOld != null && !idCategoryOld.equals(idCategoryNew)) {
                idCategoryOld.getProductosCollection().remove(productos);
                idCategoryOld = em.merge(idCategoryOld);
            }
            if (idCategoryNew != null && !idCategoryNew.equals(idCategoryOld)) {
                idCategoryNew.getProductosCollection().add(productos);
                idCategoryNew = em.merge(idCategoryNew);
            }
            if (idConditionOld != null && !idConditionOld.equals(idConditionNew)) {
                idConditionOld.getProductosCollection().remove(productos);
                idConditionOld = em.merge(idConditionOld);
            }
            if (idConditionNew != null && !idConditionNew.equals(idConditionOld)) {
                idConditionNew.getProductosCollection().add(productos);
                idConditionNew = em.merge(idConditionNew);
            }
            if (idCouponOld != null && !idCouponOld.equals(idCouponNew)) {
                idCouponOld.getProductosCollection().remove(productos);
                idCouponOld = em.merge(idCouponOld);
            }
            if (idCouponNew != null && !idCouponNew.equals(idCouponOld)) {
                idCouponNew.getProductosCollection().add(productos);
                idCouponNew = em.merge(idCouponNew);
            }
            if (idSellerOld != null && !idSellerOld.equals(idSellerNew)) {
                idSellerOld.getProductosCollection().remove(productos);
                idSellerOld = em.merge(idSellerOld);
            }
            if (idSellerNew != null && !idSellerNew.equals(idSellerOld)) {
                idSellerNew.getProductosCollection().add(productos);
                idSellerNew = em.merge(idSellerNew);
            }
            for (WishlistProduct wishlistProductsCollectionNewWishlistProducts : wishlistProductsCollectionNew) {
                if (!wishlistProductsCollectionOld.contains(wishlistProductsCollectionNewWishlistProducts)) {
                    Producto oldIdItemOfWishlistProductsCollectionNewWishlistProducts = wishlistProductsCollectionNewWishlistProducts.getIdItem();
                    wishlistProductsCollectionNewWishlistProducts.setIdItem(productos);
                    wishlistProductsCollectionNewWishlistProducts = em.merge(wishlistProductsCollectionNewWishlistProducts);
                    if (oldIdItemOfWishlistProductsCollectionNewWishlistProducts != null && !oldIdItemOfWishlistProductsCollectionNewWishlistProducts.equals(productos)) {
                        oldIdItemOfWishlistProductsCollectionNewWishlistProducts.getWishlistProductsCollection().remove(wishlistProductsCollectionNewWishlistProducts);
                        oldIdItemOfWishlistProductsCollectionNewWishlistProducts = em.merge(oldIdItemOfWishlistProductsCollectionNewWishlistProducts);
                    }
                }
            }
            for (ShippingProduct shippingProductsCollectionNewShippingProducts : shippingProductsCollectionNew) {
                if (!shippingProductsCollectionOld.contains(shippingProductsCollectionNewShippingProducts)) {
                    Producto oldItemIdOfShippingProductsCollectionNewShippingProducts = shippingProductsCollectionNewShippingProducts.getItem();
                    shippingProductsCollectionNewShippingProducts.setItem(productos);
                    shippingProductsCollectionNewShippingProducts = em.merge(shippingProductsCollectionNewShippingProducts);
                    if (oldItemIdOfShippingProductsCollectionNewShippingProducts != null && !oldItemIdOfShippingProductsCollectionNewShippingProducts.equals(productos)) {
                        oldItemIdOfShippingProductsCollectionNewShippingProducts.getShippingProductsCollection().remove(shippingProductsCollectionNewShippingProducts);
                        oldItemIdOfShippingProductsCollectionNewShippingProducts = em.merge(oldItemIdOfShippingProductsCollectionNewShippingProducts);
                    }
                }
            }
            for (AtributtesProduct atributtesProductsCollectionNewAtributtesProducts : atributtesProductsCollectionNew) {
                if (!atributtesProductsCollectionOld.contains(atributtesProductsCollectionNewAtributtesProducts)) {
                    Producto oldIdItemOfAtributtesProductsCollectionNewAtributtesProducts = atributtesProductsCollectionNewAtributtesProducts.getIdItem();
                    atributtesProductsCollectionNewAtributtesProducts.setIdItem(productos);
                    atributtesProductsCollectionNewAtributtesProducts = em.merge(atributtesProductsCollectionNewAtributtesProducts);
                    if (oldIdItemOfAtributtesProductsCollectionNewAtributtesProducts != null && !oldIdItemOfAtributtesProductsCollectionNewAtributtesProducts.equals(productos)) {
                        oldIdItemOfAtributtesProductsCollectionNewAtributtesProducts.getAtributtesProductsCollection().remove(atributtesProductsCollectionNewAtributtesProducts);
                        oldIdItemOfAtributtesProductsCollectionNewAtributtesProducts = em.merge(oldIdItemOfAtributtesProductsCollectionNewAtributtesProducts);
                    }
                }
            }
            for (ImagesProduct imagesProductsCollectionNewImagesProducts : imagesProductsCollectionNew) {
                if (!imagesProductsCollectionOld.contains(imagesProductsCollectionNewImagesProducts)) {
                    Producto oldItemIdOfImagesProductsCollectionNewImagesProducts = imagesProductsCollectionNewImagesProducts.getItem();
                    imagesProductsCollectionNewImagesProducts.setItem(productos);
                    imagesProductsCollectionNewImagesProducts = em.merge(imagesProductsCollectionNewImagesProducts);
                    if (oldItemIdOfImagesProductsCollectionNewImagesProducts != null && !oldItemIdOfImagesProductsCollectionNewImagesProducts.equals(productos)) {
                        oldItemIdOfImagesProductsCollectionNewImagesProducts.getImagesProductsCollection().remove(imagesProductsCollectionNewImagesProducts);
                        oldItemIdOfImagesProductsCollectionNewImagesProducts = em.merge(oldItemIdOfImagesProductsCollectionNewImagesProducts);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = productos.getItemId();
                if (findProductos(id) == null) {
                    throw new NonexistentEntityException("The productos with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Producto productos;
            try {
                productos = em.getReference(Producto.class, id);
                productos.getItemId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The productos with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<WishlistProduct> wishlistProductsCollectionOrphanCheck = productos.getWishlistProductsCollection();
            for (WishlistProduct wishlistProductsCollectionOrphanCheckWishlistProducts : wishlistProductsCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Productos (" + productos + ") cannot be destroyed since the WishlistProducts " + wishlistProductsCollectionOrphanCheckWishlistProducts + " in its wishlistProductsCollection field has a non-nullable idItem field.");
            }
            Collection<ShippingProduct> shippingProductsCollectionOrphanCheck = productos.getShippingProductsCollection();
            for (ShippingProduct shippingProductsCollectionOrphanCheckShippingProducts : shippingProductsCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Productos (" + productos + ") cannot be destroyed since the ShippingProducts " + shippingProductsCollectionOrphanCheckShippingProducts + " in its shippingProductsCollection field has a non-nullable itemId field.");
            }
            Collection<AtributtesProduct> atributtesProductsCollectionOrphanCheck = productos.getAtributtesProductsCollection();
            for (AtributtesProduct atributtesProductsCollectionOrphanCheckAtributtesProducts : atributtesProductsCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Productos (" + productos + ") cannot be destroyed since the AtributtesProducts " + atributtesProductsCollectionOrphanCheckAtributtesProducts + " in its atributtesProductsCollection field has a non-nullable idItem field.");
            }
            Collection<ImagesProduct> imagesProductsCollectionOrphanCheck = productos.getImagesProductsCollection();
            for (ImagesProduct imagesProductsCollectionOrphanCheckImagesProducts : imagesProductsCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Productos (" + productos + ") cannot be destroyed since the ImagesProducts " + imagesProductsCollectionOrphanCheckImagesProducts + " in its imagesProductsCollection field has a non-nullable itemId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            CategoryProduct idCategory = productos.getIdCategory();
            if (idCategory != null) {
                idCategory.getProductosCollection().remove(productos);
                idCategory = em.merge(idCategory);
            }
            ConditionProduct idCondition = productos.getIdCondition();
            if (idCondition != null) {
                idCondition.getProductosCollection().remove(productos);
                idCondition = em.merge(idCondition);
            }
            CouponPro idCoupon = productos.getIdCoupon();
            if (idCoupon != null) {
                idCoupon.getProductosCollection().remove(productos);
                idCoupon = em.merge(idCoupon);
            }
            Seller idSeller = productos.getIdSeller();
            if (idSeller != null) {
                idSeller.getProductosCollection().remove(productos);
                idSeller = em.merge(idSeller);
            }
            em.remove(productos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Producto> findProductosEntities() {
        return findProductosEntities(true, -1, -1);
    }

    public List<Producto> findProductosEntities(int maxResults, int firstResult) {
        return findProductosEntities(false, maxResults, firstResult);
    }

    private List<Producto> findProductosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Producto.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Producto findProductos(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Producto.class, id);
        } finally {
            em.close();
        }
    }
    public Producto findProductoByID(String id) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Producto> query = em.createNamedQuery("Producto.findByItemId", Producto.class);
            query.setParameter("itemId", id);
            Producto producto = query.getSingleResult();
            return producto;
        }catch(NoResultException nre){
            return null;
        }finally {
            em.close();
        }
    }

    public int getProductosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Producto> rt = cq.from(Producto.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    /**
     * Busca un producto e inicializa sus colecciones lazy
     * Usa múltiples consultas para evitar MultipleBagFetchException
     */
    public Producto findProductosWithCollections(String itemId) {
        EntityManager em = getEntityManager();
        try {
            // 1️⃣ Cargar producto con seller, category y condition
            TypedQuery<Producto> query = em.createQuery(
                    "SELECT DISTINCT p FROM Producto p " +
                            "LEFT JOIN FETCH p.idSeller " +
                            "LEFT JOIN FETCH p.idCategory " +
                            "LEFT JOIN FETCH p.idCondition " +
                            "LEFT JOIN FETCH p.idCoupon " +
                            "WHERE p.itemId = :itemId",
                    Producto.class
            );
            query.setParameter("itemId", itemId);

            Producto producto = query.getSingleResult();

            // 2️⃣ Inicializar colecciones manualmente (fuerza la carga dentro de la sesión)
            if (producto != null) {
                // Forzar inicialización de las colecciones
                producto.getImagesProductsCollection().size();
                producto.getAtributtesProductsCollection().size();
                producto.getShippingProductsCollection().size();
            }

            return producto;

        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }
}
