package controllersJPA;

import controllersJPA.exceptions.NonexistentEntityException;
import entities.CouponPro;
import entities.Producto;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CouponProJpaController implements Serializable {

    public CouponProJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(CouponPro couponPro) {
        if (couponPro.getProductosCollection() == null) {
            couponPro.setProductosCollection(new ArrayList<Producto>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Producto> attachedProductosCollection = new ArrayList<Producto>();
            for (Producto productosCollectionProductosToAttach : couponPro.getProductosCollection()) {
                productosCollectionProductosToAttach = em.getReference(productosCollectionProductosToAttach.getClass(), productosCollectionProductosToAttach.getItemId());
                attachedProductosCollection.add(productosCollectionProductosToAttach);
            }
            couponPro.setProductosCollection(attachedProductosCollection);
            em.persist(couponPro);
            for (Producto productosCollectionProductos : couponPro.getProductosCollection()) {
                CouponPro oldIdCouponOfProductosCollectionProductos = productosCollectionProductos.getIdCoupon();
                productosCollectionProductos.setIdCoupon(couponPro);
                productosCollectionProductos = em.merge(productosCollectionProductos);
                if (oldIdCouponOfProductosCollectionProductos != null) {
                    oldIdCouponOfProductosCollectionProductos.getProductosCollection().remove(productosCollectionProductos);
                    oldIdCouponOfProductosCollectionProductos = em.merge(oldIdCouponOfProductosCollectionProductos);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(CouponPro couponPro) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CouponPro persistentCouponPro = em.find(CouponPro.class, couponPro.getId());
            Collection<Producto> productosCollectionOld = persistentCouponPro.getProductosCollection();
            Collection<Producto> productosCollectionNew = couponPro.getProductosCollection();
            Collection<Producto> attachedProductosCollectionNew = new ArrayList<Producto>();
            for (Producto productosCollectionNewProductosToAttach : productosCollectionNew) {
                productosCollectionNewProductosToAttach = em.getReference(productosCollectionNewProductosToAttach.getClass(), productosCollectionNewProductosToAttach.getItemId());
                attachedProductosCollectionNew.add(productosCollectionNewProductosToAttach);
            }
            productosCollectionNew = attachedProductosCollectionNew;
            couponPro.setProductosCollection(productosCollectionNew);
            couponPro = em.merge(couponPro);
            for (Producto productosCollectionOldProductos : productosCollectionOld) {
                if (!productosCollectionNew.contains(productosCollectionOldProductos)) {
                    productosCollectionOldProductos.setIdCoupon(null);
                    productosCollectionOldProductos = em.merge(productosCollectionOldProductos);
                }
            }
            for (Producto productosCollectionNewProductos : productosCollectionNew) {
                if (!productosCollectionOld.contains(productosCollectionNewProductos)) {
                    CouponPro oldIdCouponOfProductosCollectionNewProductos = productosCollectionNewProductos.getIdCoupon();
                    productosCollectionNewProductos.setIdCoupon(couponPro);
                    productosCollectionNewProductos = em.merge(productosCollectionNewProductos);
                    if (oldIdCouponOfProductosCollectionNewProductos != null && !oldIdCouponOfProductosCollectionNewProductos.equals(couponPro)) {
                        oldIdCouponOfProductosCollectionNewProductos.getProductosCollection().remove(productosCollectionNewProductos);
                        oldIdCouponOfProductosCollectionNewProductos = em.merge(oldIdCouponOfProductosCollectionNewProductos);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = couponPro.getId();
                if (findCouponPro(id) == null) {
                    throw new NonexistentEntityException("The couponPro with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CouponPro couponPro;
            try {
                couponPro = em.getReference(CouponPro.class, id);
                couponPro.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The couponPro with id " + id + " no longer exists.", enfe);
            }
            Collection<Producto> productosCollection = couponPro.getProductosCollection();
            for (Producto productosCollectionProductos : productosCollection) {
                productosCollectionProductos.setIdCoupon(null);
                productosCollectionProductos = em.merge(productosCollectionProductos);
            }
            em.remove(couponPro);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<CouponPro> findCouponProEntities() {
        return findCouponProEntities(true, -1, -1);
    }

    public List<CouponPro> findCouponProEntities(int maxResults, int firstResult) {
        return findCouponProEntities(false, maxResults, firstResult);
    }

    private List<CouponPro> findCouponProEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(CouponPro.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public CouponPro findCouponPro(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(CouponPro.class, id);
        } finally {
            em.close();
        }
    }
    public CouponPro findByIdItem(String idItem) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<CouponPro> query = em.createNamedQuery("CouponPro.findByItemId", CouponPro.class);
            query.setParameter("itemId", idItem);
            CouponPro couponPro = query.getSingleResult();
            return couponPro;
        }catch(Exception ex){
            return null;
        }finally {
            em.close();
        }
    }

    public int getCouponProCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<CouponPro> rt = cq.from(CouponPro.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}

