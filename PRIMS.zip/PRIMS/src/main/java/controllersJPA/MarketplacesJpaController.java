package controllersJPA;

import controllersJPA.exceptions.IllegalOrphanException;
import controllersJPA.exceptions.NonexistentEntityException;
import entities.Marketplace;
import entities.Seller;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MarketplacesJpaController implements Serializable {

    public MarketplacesJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Marketplace marketplaces) {
        if (marketplaces.getSellerCollection() == null) {
            marketplaces.setSellerCollection(new ArrayList<Seller>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Seller> attachedSellerCollection = new ArrayList<Seller>();
            for (Seller sellerCollectionSellerToAttach : marketplaces.getSellerCollection()) {
                sellerCollectionSellerToAttach = em.getReference(sellerCollectionSellerToAttach.getClass(), sellerCollectionSellerToAttach.getId());
                attachedSellerCollection.add(sellerCollectionSellerToAttach);
            }
            marketplaces.setSellerCollection(attachedSellerCollection);
            em.persist(marketplaces);
            for (Seller sellerCollectionSeller : marketplaces.getSellerCollection()) {
                Marketplace oldIdMarketplaceOfSellerCollectionSeller = sellerCollectionSeller.getIdMarketplace();
                sellerCollectionSeller.setIdMarketplace(marketplaces);
                sellerCollectionSeller = em.merge(sellerCollectionSeller);
                if (oldIdMarketplaceOfSellerCollectionSeller != null) {
                    oldIdMarketplaceOfSellerCollectionSeller.getSellerCollection().remove(sellerCollectionSeller);
                    oldIdMarketplaceOfSellerCollectionSeller = em.merge(oldIdMarketplaceOfSellerCollectionSeller);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Marketplace marketplaces) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Marketplace persistentMarketplaces = em.find(Marketplace.class, marketplaces.getId());
            Collection<Seller> sellerCollectionOld = persistentMarketplaces.getSellerCollection();
            Collection<Seller> sellerCollectionNew = marketplaces.getSellerCollection();
            List<String> illegalOrphanMessages = null;
            for (Seller sellerCollectionOldSeller : sellerCollectionOld) {
                if (!sellerCollectionNew.contains(sellerCollectionOldSeller)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Seller " + sellerCollectionOldSeller + " since its idMarketplace field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Seller> attachedSellerCollectionNew = new ArrayList<Seller>();
            for (Seller sellerCollectionNewSellerToAttach : sellerCollectionNew) {
                sellerCollectionNewSellerToAttach = em.getReference(sellerCollectionNewSellerToAttach.getClass(), sellerCollectionNewSellerToAttach.getId());
                attachedSellerCollectionNew.add(sellerCollectionNewSellerToAttach);
            }
            sellerCollectionNew = attachedSellerCollectionNew;
            marketplaces.setSellerCollection(sellerCollectionNew);
            marketplaces = em.merge(marketplaces);
            for (Seller sellerCollectionNewSeller : sellerCollectionNew) {
                if (!sellerCollectionOld.contains(sellerCollectionNewSeller)) {
                    Marketplace oldIdMarketplaceOfSellerCollectionNewSeller = sellerCollectionNewSeller.getIdMarketplace();
                    sellerCollectionNewSeller.setIdMarketplace(marketplaces);
                    sellerCollectionNewSeller = em.merge(sellerCollectionNewSeller);
                    if (oldIdMarketplaceOfSellerCollectionNewSeller != null && !oldIdMarketplaceOfSellerCollectionNewSeller.equals(marketplaces)) {
                        oldIdMarketplaceOfSellerCollectionNewSeller.getSellerCollection().remove(sellerCollectionNewSeller);
                        oldIdMarketplaceOfSellerCollectionNewSeller = em.merge(oldIdMarketplaceOfSellerCollectionNewSeller);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = marketplaces.getId();
                if (findMarketplaces(id) == null) {
                    throw new NonexistentEntityException("The marketplaces with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Marketplace marketplaces;
            try {
                marketplaces = em.getReference(Marketplace.class, id);
                marketplaces.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The marketplaces with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Seller> sellerCollectionOrphanCheck = marketplaces.getSellerCollection();
            for (Seller sellerCollectionOrphanCheckSeller : sellerCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Marketplaces (" + marketplaces + ") cannot be destroyed since the Seller " + sellerCollectionOrphanCheckSeller + " in its sellerCollection field has a non-nullable idMarketplace field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(marketplaces);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Marketplace> findMarketplacesEntities() {
        return findMarketplacesEntities(true, -1, -1);
    }

    public List<Marketplace> findMarketplacesEntities(int maxResults, int firstResult) {
        return findMarketplacesEntities(false, maxResults, firstResult);
    }

    private List<Marketplace> findMarketplacesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Marketplace.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Marketplace findMarketplaces(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Marketplace.class, id);
        } finally {
            em.close();
        }
    }

    public int getMarketplacesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Marketplace> rt = cq.from(Marketplace.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}

