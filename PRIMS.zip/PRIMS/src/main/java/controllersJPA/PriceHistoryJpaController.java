package controllersJPA;

import controllersJPA.exceptions.NonexistentEntityException;
import entities.PriceHistory;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PriceHistoryJpaController implements Serializable {

    public PriceHistoryJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(PriceHistory priceHistory) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(priceHistory);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(PriceHistory priceHistory) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            priceHistory = em.merge(priceHistory);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = priceHistory.getId();
                if (findPriceHistory(id) == null) {
                    throw new NonexistentEntityException("The priceHistory with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            PriceHistory priceHistory;
            try {
                priceHistory = em.getReference(PriceHistory.class, id);
                priceHistory.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The priceHistory with id " + id + " no longer exists.", enfe);
            }
            em.remove(priceHistory);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<PriceHistory> findPriceHistoryEntities() {
        return findPriceHistoryEntities(true, -1, -1);
    }

    public List<PriceHistory> findPriceHistoryEntities(int maxResults, int firstResult) {
        return findPriceHistoryEntities(false, maxResults, firstResult);
    }

    private List<PriceHistory> findPriceHistoryEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(PriceHistory.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public PriceHistory findPriceHistory(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(PriceHistory.class, id);
        } finally {
            em.close();
        }
    }

    public List<PriceHistory> findAllByItemId(String itemId) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<PriceHistory> query = em.createQuery(
                    "SELECT ph FROM PriceHistory ph " +
                            "WHERE ph.itemId = :itemId " +
                            "ORDER BY ph.recordedAt ASC",
                    PriceHistory.class
            );
            query.setParameter("itemId", itemId);
            return query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>(); // Retornar lista vacía en lugar de null
        } finally {
            em.close();
        }
    }
    public PriceHistory findPriceHistoryByItemIDANDDate(String ID, String recordedAt) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<PriceHistory> query = em.createNamedQuery("PriceHistory.findByItemId", PriceHistory.class);
            query.setParameter("itemId", ID);
            query.setParameter("recordedAt", recordedAt);
            return query.getSingleResult();
        }catch(Exception ex){
            return null;
        }finally {
            em.close();
        }
    }

    public PriceHistory findLatestByItemId(String itemId) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<PriceHistory> query = em.createQuery(
                    "SELECT ph FROM PriceHistory ph " +
                            "WHERE ph.itemId = :itemId " +
                            "ORDER BY ph.recordedAt DESC",
                    PriceHistory.class
            );
            query.setParameter("itemId", itemId);
            query.setMaxResults(1);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }
    public int getPriceHistoryCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<PriceHistory> rt = cq.from(PriceHistory.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
