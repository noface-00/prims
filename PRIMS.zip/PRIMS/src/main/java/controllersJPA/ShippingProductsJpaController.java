package controllersJPA;

import controllersJPA.exceptions.NonexistentEntityException;
import entities.Producto;
import entities.ShippingProduct;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.List;

public class ShippingProductsJpaController implements Serializable {

    public ShippingProductsJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(ShippingProduct shippingProducts) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Producto itemId = shippingProducts.getItem();
            if (itemId != null) {
                itemId = em.getReference(itemId.getClass(), itemId.getItemId());
                shippingProducts.setItem(itemId);
            }
            em.persist(shippingProducts);
            if (itemId != null) {
                itemId.getShippingProductsCollection().add(shippingProducts);
                itemId = em.merge(itemId);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(ShippingProduct shippingProducts) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ShippingProduct persistentShippingProducts = em.find(ShippingProduct.class, shippingProducts.getId());
            Producto itemIdOld = persistentShippingProducts.getItem();
            Producto itemIdNew = shippingProducts.getItem();
            if (itemIdNew != null) {
                itemIdNew = em.getReference(itemIdNew.getClass(), itemIdNew.getItemId());
                shippingProducts.setItem(itemIdNew);
            }
            shippingProducts = em.merge(shippingProducts);
            if (itemIdOld != null && !itemIdOld.equals(itemIdNew)) {
                itemIdOld.getShippingProductsCollection().remove(shippingProducts);
                itemIdOld = em.merge(itemIdOld);
            }
            if (itemIdNew != null && !itemIdNew.equals(itemIdOld)) {
                itemIdNew.getShippingProductsCollection().add(shippingProducts);
                itemIdNew = em.merge(itemIdNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = shippingProducts.getId();
                if (findShippingProducts(id) == null) {
                    throw new NonexistentEntityException("The shippingProducts with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ShippingProduct shippingProducts;
            try {
                shippingProducts = em.getReference(ShippingProduct.class, id);
                shippingProducts.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The shippingProducts with id " + id + " no longer exists.", enfe);
            }
            Producto itemId = shippingProducts.getItem();
            if (itemId != null) {
                itemId.getShippingProductsCollection().remove(shippingProducts);
                itemId = em.merge(itemId);
            }
            em.remove(shippingProducts);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<ShippingProduct> findShippingProductsEntities() {
        return findShippingProductsEntities(true, -1, -1);
    }

    public List<ShippingProduct> findShippingProductsEntities(int maxResults, int firstResult) {
        return findShippingProductsEntities(false, maxResults, firstResult);
    }

    private List<ShippingProduct> findShippingProductsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(ShippingProduct.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public ShippingProduct findShippingProducts(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ShippingProduct.class, id);
        } finally {
            em.close();
        }
    }
    public ShippingProduct findShippingByItemID(String itemId, String type) {
        try {
            EntityManager em = getEntityManager();

            TypedQuery<ShippingProduct> query = em.createQuery(
                    "SELECT s FROM ShippingProduct s " +
                            "WHERE s.itemId.itemId = :itemId " +
                            "AND s.type = :type",
                    ShippingProduct.class
            );

            query.setParameter("itemId", itemId);
            query.setParameter("type", type);
            query.setMaxResults(1);

            List<ShippingProduct> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);

        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            return null;
        }
    }

    public int getShippingProductsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<ShippingProduct> rt = cq.from(ShippingProduct.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
