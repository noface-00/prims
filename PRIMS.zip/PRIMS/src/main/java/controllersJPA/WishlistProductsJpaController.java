package controllersJPA;

import controllersJPA.exceptions.NonexistentEntityException;
import entities.Auth;
import entities.Producto;
import entities.WishlistProduct;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class WishlistProductsJpaController implements Serializable {

    public WishlistProductsJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }

    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(WishlistProduct wishlistProducts) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Auth idUser = wishlistProducts.getIdUser();
            if (idUser != null) {
                idUser = em.getReference(idUser.getClass(), idUser.getId());
                wishlistProducts.setIdUser(idUser);
            }
            Producto idItem = wishlistProducts.getIdItem();
            if (idItem != null) {
                idItem = em.getReference(idItem.getClass(), idItem.getItemId());
                wishlistProducts.setIdItem(idItem);
            }
            em.persist(wishlistProducts);
            if (idUser != null) {
                idUser.getWishlistProductsCollection().add(wishlistProducts);
                idUser = em.merge(idUser);
            }
            if (idItem != null) {
                idItem.getWishlistProductsCollection().add(wishlistProducts);
                idItem = em.merge(idItem);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(WishlistProduct wishlistProducts) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            WishlistProduct persistentWishlistProducts = em.find(WishlistProduct.class, wishlistProducts.getId());
            Auth idUserOld = persistentWishlistProducts.getIdUser();
            Auth idUserNew = wishlistProducts.getIdUser();
            Producto idItemOld = persistentWishlistProducts.getIdItem();
            Producto idItemNew = wishlistProducts.getIdItem();
            if (idUserNew != null) {
                idUserNew = em.getReference(idUserNew.getClass(), idUserNew.getId());
                wishlistProducts.setIdUser(idUserNew);
            }
            if (idItemNew != null) {
                idItemNew = em.getReference(idItemNew.getClass(), idItemNew.getItemId());
                wishlistProducts.setIdItem(idItemNew);
            }
            wishlistProducts = em.merge(wishlistProducts);
            if (idUserOld != null && !idUserOld.equals(idUserNew)) {
                idUserOld.getWishlistProductsCollection().remove(wishlistProducts);
                idUserOld = em.merge(idUserOld);
            }
            if (idUserNew != null && !idUserNew.equals(idUserOld)) {
                idUserNew.getWishlistProductsCollection().add(wishlistProducts);
                idUserNew = em.merge(idUserNew);
            }
            if (idItemOld != null && !idItemOld.equals(idItemNew)) {
                idItemOld.getWishlistProductsCollection().remove(wishlistProducts);
                idItemOld = em.merge(idItemOld);
            }
            if (idItemNew != null && !idItemNew.equals(idItemOld)) {
                idItemNew.getWishlistProductsCollection().add(wishlistProducts);
                idItemNew = em.merge(idItemNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = wishlistProducts.getId();
                if (findWishlistProducts(id) == null) {
                    throw new NonexistentEntityException("The wishlistProducts with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        System.out.println("\n🗑️ destroy() - ID: " + id);

        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();

            System.out.println("   ✅ Transacción iniciada");

            WishlistProduct wishlistProducts;
            try {
                // ✅ Usar find() en lugar de getReference()
                wishlistProducts = em.find(WishlistProduct.class, id);

                if (wishlistProducts == null) {
                    throw new NonexistentEntityException("The wishlistProducts with id " + id + " no longer exists.");
                }

                System.out.println("   ✅ WishlistProduct encontrado: " + wishlistProducts.getId());

            } catch (Exception e) {
                throw new NonexistentEntityException("The wishlistProducts with id " + id + " no longer exists.", e);
            }

            // Desvincular de Auth (Usuario)
            Auth idUser = wishlistProducts.getIdUser();
            if (idUser != null) {
                System.out.println("   🔗 Desvinculando de usuario: " + idUser.getId());
                if (idUser.getWishlistProductsCollection() != null) {
                    idUser.getWishlistProductsCollection().remove(wishlistProducts);
                    em.merge(idUser);
                }
            }

            // Desvincular de Producto
            Producto idItem = wishlistProducts.getIdItem();
            if (idItem != null) {
                System.out.println("   🔗 Desvinculando de producto: " + idItem.getItemId());
                if (idItem.getWishlistProductsCollection() != null) {
                    idItem.getWishlistProductsCollection().remove(wishlistProducts);
                    em.merge(idItem);
                }
            }

            // ✅ Asegurar que la entidad esté managed antes de remove
            if (!em.contains(wishlistProducts)) {
                System.out.println("   ⚠️ Entidad no está managed, haciendo merge...");
                wishlistProducts = em.merge(wishlistProducts);
            }

            // Eliminar la entidad
            em.remove(wishlistProducts);
            System.out.println("   ✅ remove() ejecutado");

            // ✅ CRÍTICO: flush() ANTES del commit(), NO después
            em.flush();
            System.out.println("   ✅ flush() ejecutado");

            // Commit
            em.getTransaction().commit();
            System.out.println("   ✅ Transacción confirmada (commit)");

            // ✅ Verificación (DESPUÉS del commit, con EntityManager cerrado)
            // Creamos un nuevo EM para verificar
            EntityManager emVerify = getEntityManager();
            try {
                WishlistProduct verificacion = emVerify.find(WishlistProduct.class, id);

                if (verificacion != null) {
                    System.err.println("   ❌❌❌ ERROR: Entidad SIGUE existiendo después del commit!");
                    throw new Exception("Fallo crítico: La entidad no se eliminó de la BD");
                }

                System.out.println("   ✅✅✅ Verificación exitosa: Entidad eliminada de BD\n");
            } finally {
                emVerify.close();
            }

        } catch (NonexistentEntityException e) {
            throw e;
        } catch (Exception e) {
            System.err.println("   ❌ Error en destroy():");
            e.printStackTrace();

            if (em != null && em.getTransaction().isActive()) {
                System.err.println("   🔄 Rollback...");
                em.getTransaction().rollback();
            }

            throw new NonexistentEntityException("Error eliminando wishlist: " + e.getMessage(), e);

        } finally {
            if (em != null) {
                em.close();
                System.out.println("   ✅ EntityManager cerrado");
            }
        }
    }
    public List<WishlistProduct> findWishlistProductsEntities() {
        return findWishlistProductsEntities(true, -1, -1);
    }

    public List<WishlistProduct> findWishlistProductsEntities(int maxResults, int firstResult) {
        return findWishlistProductsEntities(false, maxResults, firstResult);
    }

    private List<WishlistProduct> findWishlistProductsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(WishlistProduct.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public WishlistProduct findWishlistProducts(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(WishlistProduct.class, id);
        } finally {
            em.close();
        }
    }

    public int getWishlistProductsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<WishlistProduct> rt = cq.from(WishlistProduct.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    public WishlistProduct findWishlistProductsByProduct(Integer idUser, String idItem) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<WishlistProduct> query = em.createNamedQuery("WishlistProducts.findById", WishlistProduct.class);
            query.setParameter("idUser", idUser);
            query.setParameter("idItem", idItem);
            WishlistProduct wishlistProducts = query.getSingleResult();
            return wishlistProducts;
        }catch(Exception ex){
            return null;
        } finally {
            em.close();
        }
    }

    public List<WishlistProduct> findWishlistProductsByUserID(Integer idUser) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<WishlistProduct> query = em.createNamedQuery("WishlistProducts.findByUser", WishlistProduct.class);
            query.setParameter("idUser", idUser);
            List<WishlistProduct> wishlistProducts = query.getResultList(); // ⬅️ getResultList() en lugar de getSingleResult()
            return wishlistProducts;
        } catch (Exception ex) {
            System.err.println("Error obteniendo wishlist del usuario: " + ex.getMessage());
            ex.printStackTrace();
            return new ArrayList<>(); // ⬅️ Devolver lista vacía en caso de error
        } finally {
            em.close();
        }
    }

    public int getWishlistProductsCountByUser(Integer id) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Long> query = em.createNamedQuery("WishlistProduct.countByUser", Long.class);
            query.setParameter("id", id);
            Long count = query.getSingleResult();
            return count != null ? count.intValue() : 0;
        } catch (Exception ex) {
            System.err.println("Error obteniendo count de wishlist: " + ex.getMessage());
            ex.printStackTrace();
            return 0;
        } finally {
            em.close();
        }
    }

}
