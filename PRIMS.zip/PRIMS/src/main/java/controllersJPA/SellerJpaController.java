package controllersJPA;

import controllersJPA.exceptions.IllegalOrphanException;
import controllersJPA.exceptions.NonexistentEntityException;
import entities.Marketplace;
import entities.Producto;
import entities.Seller;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SellerJpaController implements Serializable {

    public SellerJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Seller seller) {
        if (seller.getProductosCollection() == null) {
            seller.setProductosCollection(new ArrayList<Producto>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Marketplace idMarketplace = seller.getIdMarketplace();
            if (idMarketplace != null) {
                idMarketplace = em.getReference(idMarketplace.getClass(), idMarketplace.getId());
                seller.setIdMarketplace(idMarketplace);
            }
            Collection<Producto> attachedProductosCollection = new ArrayList<Producto>();
            for (Producto productosCollectionProductosToAttach : seller.getProductosCollection()) {
                productosCollectionProductosToAttach = em.getReference(productosCollectionProductosToAttach.getClass(), productosCollectionProductosToAttach.getItemId());
                attachedProductosCollection.add(productosCollectionProductosToAttach);
            }
            seller.setProductosCollection(attachedProductosCollection);
            em.persist(seller);
            if (idMarketplace != null) {
                idMarketplace.getSellerCollection().add(seller);
                idMarketplace = em.merge(idMarketplace);
            }
            for (Producto productosCollectionProductos : seller.getProductosCollection()) {
                Seller oldIdSellerOfProductosCollectionProductos = productosCollectionProductos.getIdSeller();
                productosCollectionProductos.setIdSeller(seller);
                productosCollectionProductos = em.merge(productosCollectionProductos);
                if (oldIdSellerOfProductosCollectionProductos != null) {
                    oldIdSellerOfProductosCollectionProductos.getProductosCollection().remove(productosCollectionProductos);
                    oldIdSellerOfProductosCollectionProductos = em.merge(oldIdSellerOfProductosCollectionProductos);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Seller seller) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Seller persistentSeller = em.find(Seller.class, seller.getId());
            Marketplace idMarketplaceOld = persistentSeller.getIdMarketplace();
            Marketplace idMarketplaceNew = seller.getIdMarketplace();
            Collection<Producto> productosCollectionOld = persistentSeller.getProductosCollection();
            Collection<Producto> productosCollectionNew = seller.getProductosCollection();
            List<String> illegalOrphanMessages = null;
            for (Producto productosCollectionOldProductos : productosCollectionOld) {
                if (!productosCollectionNew.contains(productosCollectionOldProductos)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Productos " + productosCollectionOldProductos + " since its idSeller field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (idMarketplaceNew != null) {
                idMarketplaceNew = em.getReference(idMarketplaceNew.getClass(), idMarketplaceNew.getId());
                seller.setIdMarketplace(idMarketplaceNew);
            }
            Collection<Producto> attachedProductosCollectionNew = new ArrayList<Producto>();
            for (Producto productosCollectionNewProductosToAttach : productosCollectionNew) {
                productosCollectionNewProductosToAttach = em.getReference(productosCollectionNewProductosToAttach.getClass(), productosCollectionNewProductosToAttach.getItemId());
                attachedProductosCollectionNew.add(productosCollectionNewProductosToAttach);
            }
            productosCollectionNew = attachedProductosCollectionNew;
            seller.setProductosCollection(productosCollectionNew);
            seller = em.merge(seller);
            if (idMarketplaceOld != null && !idMarketplaceOld.equals(idMarketplaceNew)) {
                idMarketplaceOld.getSellerCollection().remove(seller);
                idMarketplaceOld = em.merge(idMarketplaceOld);
            }
            if (idMarketplaceNew != null && !idMarketplaceNew.equals(idMarketplaceOld)) {
                idMarketplaceNew.getSellerCollection().add(seller);
                idMarketplaceNew = em.merge(idMarketplaceNew);
            }
            for (Producto productosCollectionNewProductos : productosCollectionNew) {
                if (!productosCollectionOld.contains(productosCollectionNewProductos)) {
                    Seller oldIdSellerOfProductosCollectionNewProductos = productosCollectionNewProductos.getIdSeller();
                    productosCollectionNewProductos.setIdSeller(seller);
                    productosCollectionNewProductos = em.merge(productosCollectionNewProductos);
                    if (oldIdSellerOfProductosCollectionNewProductos != null && !oldIdSellerOfProductosCollectionNewProductos.equals(seller)) {
                        oldIdSellerOfProductosCollectionNewProductos.getProductosCollection().remove(productosCollectionNewProductos);
                        oldIdSellerOfProductosCollectionNewProductos = em.merge(oldIdSellerOfProductosCollectionNewProductos);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = seller.getId();
                if (findSeller(id) == null) {
                    throw new NonexistentEntityException("The seller with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Seller seller;
            try {
                seller = em.getReference(Seller.class, id);
                seller.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The seller with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Producto> productosCollectionOrphanCheck = seller.getProductosCollection();
            for (Producto productosCollectionOrphanCheckProductos : productosCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Seller (" + seller + ") cannot be destroyed since the Productos " + productosCollectionOrphanCheckProductos + " in its productosCollection field has a non-nullable idSeller field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Marketplace idMarketplace = seller.getIdMarketplace();
            if (idMarketplace != null) {
                idMarketplace.getSellerCollection().remove(seller);
                idMarketplace = em.merge(idMarketplace);
            }
            em.remove(seller);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Seller> findSellerEntities() {
        return findSellerEntities(true, -1, -1);
    }

    public List<Seller> findSellerEntities(int maxResults, int firstResult) {
        return findSellerEntities(false, maxResults, firstResult);
    }

    private List<Seller> findSellerEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Seller.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Seller findSeller(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Seller.class, id);
        } finally {
            em.close();
        }
    }

    public Seller findSellerByUsername(String username) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Seller> query = em.createNamedQuery("Seller.findByUsername", Seller.class);
            query.setParameter("username", username);
            Seller seller = query.getSingleResult();
            return seller;
        }catch (NoResultException nre){
            return null;
        }finally {
            em.close();
        }
    }

    public int getSellerCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Seller> rt = cq.from(Seller.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}