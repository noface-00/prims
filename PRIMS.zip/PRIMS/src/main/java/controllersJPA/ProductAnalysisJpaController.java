package controllersJPA;

import controllersJPA.exceptions.NonexistentEntityException;
import entities.Marketplace;
import entities.ProductAnalysis;
import entities.Producto;
import entities.PriceHistory;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import utils.JPAUtil;

import java.time.LocalDate;
import java.util.List;

/**
 * Controlador JPA para la entidad ProductAnalysis
 * Incluye operaciones CRUD y consultas especializadas
 */
public class ProductAnalysisJpaController {

    private EntityManagerFactory emf = null;

    public ProductAnalysisJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    // ========================================
    // OPERACIONES CRUD BÁSICAS
    // ========================================

    /**
     * Crea un nuevo análisis de producto
     */
    public void create(ProductAnalysis productAnalysis) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();

            // Obtener referencias a las entidades relacionadas
            Producto item = productAnalysis.getItem();
            if (item != null) {
                item = em.getReference(item.getClass(), item.getItemId());
                productAnalysis.setItem(item);
            }

            Marketplace marketplace = productAnalysis.getIdMarketplace();
            if (marketplace != null) {
                marketplace = em.getReference(marketplace.getClass(), marketplace.getId());
                productAnalysis.setIdMarketplace(marketplace);
            }

            PriceHistory priceHistory = productAnalysis.getIdPrecioHistorico();
            if (priceHistory != null) {
                priceHistory = em.getReference(priceHistory.getClass(), priceHistory.getId());
                productAnalysis.setIdPrecioHistorico(priceHistory);
            }

            em.persist(productAnalysis);
            em.getTransaction().commit();

        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    /**
     * Actualiza un análisis existente
     */
    public void edit(ProductAnalysis productAnalysis) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();

            ProductAnalysis persistentProductAnalysis = em.find(ProductAnalysis.class, productAnalysis.getId());
            if (persistentProductAnalysis == null) {
                throw new NonexistentEntityException("The ProductAnalysis with id " + productAnalysis.getId() + " no longer exists.");
            }

            // Actualizar referencias
            Producto item = productAnalysis.getItem();
            if (item != null) {
                item = em.getReference(item.getClass(), item.getItemId());
                productAnalysis.setItem(item);
            }

            Marketplace marketplace = productAnalysis.getIdMarketplace();
            if (marketplace != null) {
                marketplace = em.getReference(marketplace.getClass(), marketplace.getId());
                productAnalysis.setIdMarketplace(marketplace);
            }

            PriceHistory priceHistory = productAnalysis.getIdPrecioHistorico();
            if (priceHistory != null) {
                priceHistory = em.getReference(priceHistory.getClass(), priceHistory.getId());
                productAnalysis.setIdPrecioHistorico(priceHistory);
            }

            productAnalysis = em.merge(productAnalysis);
            em.getTransaction().commit();

        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = productAnalysis.getId();
                if (findProductAnalysis(id) == null) {
                    throw new NonexistentEntityException("The ProductAnalysis with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    /**
     * Elimina un análisis por ID
     */
    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ProductAnalysis productAnalysis;
            try {
                productAnalysis = em.getReference(ProductAnalysis.class, id);
                productAnalysis.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The ProductAnalysis with id " + id + " no longer exists.", enfe);
            }
            em.remove(productAnalysis);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    /**
     * Busca un análisis por ID
     */
    public ProductAnalysis findProductAnalysis(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ProductAnalysis.class, id);
        } finally {
            em.close();
        }
    }

    /**
     * Obtiene todos los análisis
     */
    public List<ProductAnalysis> findProductAnalysisEntities() {
        return findProductAnalysisEntities(true, -1, -1);
    }

    /**
     * Obtiene análisis con paginación
     */
    public List<ProductAnalysis> findProductAnalysisEntities(int maxResults, int firstResult) {
        return findProductAnalysisEntities(false, maxResults, firstResult);
    }

    /**
     * Método interno para obtener análisis con o sin paginación
     */
    private List<ProductAnalysis> findProductAnalysisEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery<ProductAnalysis> cq = em.getCriteriaBuilder().createQuery(ProductAnalysis.class);
            cq.select(cq.from(ProductAnalysis.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    /**
     * Cuenta el total de análisis
     */
    public int getProductAnalysisCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery<Long> cq = em.getCriteriaBuilder().createQuery(Long.class);
            cq.select(em.getCriteriaBuilder().count(cq.from(ProductAnalysis.class)));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    // ========================================
    // CONSULTAS ESPECIALIZADAS ⭐
    // ========================================

    /**
     * Busca un análisis específico por itemId y fecha
     * Útil para verificar si ya existe un análisis del día
     */
// En ProductAnalysisJpaController.java
    public ProductAnalysis findByItemAndDate(String itemId, LocalDate date) {
        EntityManager em = getEntityManager();
        try {
            System.out.println("🔍 Buscando ProductAnalysis para itemId: " + itemId + ", fecha: " + date);

            TypedQuery<ProductAnalysis> query = em.createQuery(
                    "SELECT DISTINCT a FROM ProductAnalysis a " +
                            "LEFT JOIN FETCH a.item p " +
                            "LEFT JOIN FETCH p.idSeller s " +
                            "LEFT JOIN FETCH s.idMarketplace " +
                            "LEFT JOIN FETCH p.idCategory " +
                            "LEFT JOIN FETCH p.idCondition " +
                            "WHERE a.item.itemId = :itemId " +
                            "AND a.analysisDate = :date",
                    ProductAnalysis.class
            );
            query.setParameter("itemId", itemId);
            query.setParameter("date", date);

            ProductAnalysis analisis = query.getSingleResult();
            System.out.println("✅ Query ejecutada, análisis encontrado");

            if (analisis != null && analisis.getItem() != null) {
                Producto p = analisis.getItem();

                System.out.println("📦 Inicializando colecciones...");
                int imgCount = p.getImagesProductsCollection().size();
                int attrCount = p.getAtributtesProductsCollection().size();
                int shipCount = p.getShippingProductsCollection().size();

                System.out.println("   - Imágenes: " + imgCount);
                System.out.println("   - Atributos: " + attrCount);
                System.out.println("   - Envíos: " + shipCount);
                System.out.println("✅ Colecciones inicializadas");

                // Verificar que el nombre se puede acceder
                String nombre = p.getName();
                System.out.println("✅ Nombre accesible: " + nombre);
            }

            return analisis;

        } catch (NoResultException e) {
            System.out.println("ℹ️ No se encontró análisis para esta fecha");
            return null;
        } catch (Exception e) {
            System.err.println("❌ Error en findByItemAndDate:");
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }
    public ProductAnalysis findLatestByItemId(String itemId) {
        EntityManager em = getEntityManager();
        try {
            // Buscar análisis más reciente
            TypedQuery<ProductAnalysis> analysisQuery = em.createQuery(
                    "SELECT pa FROM ProductAnalysis pa " +
                            "WHERE pa.item.itemId = :itemId " +
                            "ORDER BY pa.analysisDate DESC",
                    ProductAnalysis.class
            );
            analysisQuery.setParameter("itemId", itemId);
            analysisQuery.setMaxResults(1);
            ProductAnalysis result = analysisQuery.getSingleResult();

            // Cargar producto completo
            TypedQuery<Producto> productoQuery = em.createQuery(
                    "SELECT DISTINCT p FROM Producto p " +
                            "LEFT JOIN FETCH p.idSeller s " +
                            "LEFT JOIN FETCH s.idMarketplace " +
                            "LEFT JOIN FETCH p.imagesProductsCollection " +
                            "WHERE p.itemId = :itemId",
                    Producto.class
            );
            productoQuery.setParameter("itemId", itemId);
            Producto productoCompleto = productoQuery.getSingleResult();

            // Reemplazar el proxy
            result.setItem(productoCompleto);

            return result;
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }
    /**
     * Busca todos los análisis de un producto
     * Ordenados por fecha descendente (más reciente primero)
     */
    public List<ProductAnalysis> findByItemId(String itemId) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT pa FROM ProductAnalysis pa " +
                            "WHERE pa.item.itemId = :itemId " +
                            "ORDER BY pa.analysisDate DESC"
            );
            q.setParameter("itemId", itemId);
            return q.getResultList();

        } catch (Exception e) {
            System.err.println("Error en findByItemId: " + e.getMessage());
            return List.of();
        } finally {
            em.close();
        }
    }

    /**
     * Busca análisis de un producto con límite
     */
    public List<ProductAnalysis> findByItemId(String itemId, int maxResults) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT pa FROM ProductAnalysis pa " +
                            "WHERE pa.item.itemId = :itemId " +
                            "ORDER BY pa.analysisDate DESC"
            );
            q.setParameter("itemId", itemId);
            q.setMaxResults(maxResults);
            return q.getResultList();

        } catch (Exception e) {
            System.err.println("Error en findByItemId con límite: " + e.getMessage());
            return List.of();
        } finally {
            em.close();
        }
    }

    /**
     * Busca análisis recientes (últimos N días)
     */
    public List<ProductAnalysis> findRecentAnalysis(int days) {
        EntityManager em = getEntityManager();
        try {
            LocalDate cutoffDate = LocalDate.now().minusDays(days);

            Query q = em.createQuery(
                    "SELECT pa FROM ProductAnalysis pa " +
                            "WHERE pa.analysisDate >= :cutoffDate " +
                            "ORDER BY pa.analysisDate DESC"
            );
            q.setParameter("cutoffDate", cutoffDate);
            return q.getResultList();

        } catch (Exception e) {
            System.err.println("Error en findRecentAnalysis: " + e.getMessage());
            return List.of();
        } finally {
            em.close();
        }
    }

    /**
     * Busca análisis que necesitan actualización (más de X días)
     */
    public List<ProductAnalysis> findOutdatedAnalysis(int daysOld) {
        EntityManager em = getEntityManager();
        try {
            LocalDate cutoffDate = LocalDate.now().minusDays(daysOld);

            Query q = em.createQuery(
                    "SELECT pa FROM ProductAnalysis pa " +
                            "WHERE pa.analysisDate < :cutoffDate " +
                            "ORDER BY pa.analysisDate ASC"
            );
            q.setParameter("cutoffDate", cutoffDate);
            return q.getResultList();

        } catch (Exception e) {
            System.err.println("Error en findOutdatedAnalysis: " + e.getMessage());
            return List.of();
        } finally {
            em.close();
        }
    }

    /**
     * Busca análisis por marketplace
     */
    public List<ProductAnalysis> findByMarketplace(Integer marketplaceId) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT pa FROM ProductAnalysis pa " +
                            "WHERE pa.idMarketplace.id = :marketplaceId " +
                            "ORDER BY pa.analysisDate DESC"
            );
            q.setParameter("marketplaceId", marketplaceId);
            return q.getResultList();

        } catch (Exception e) {
            System.err.println("Error en findByMarketplace: " + e.getMessage());
            return List.of();
        } finally {
            em.close();
        }
    }

    /**
     * Busca análisis en un rango de fechas
     */
    public List<ProductAnalysis> findByDateRange(LocalDate startDate, LocalDate endDate) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT pa FROM ProductAnalysis pa " +
                            "WHERE pa.analysisDate BETWEEN :startDate AND :endDate " +
                            "ORDER BY pa.analysisDate DESC"
            );
            q.setParameter("startDate", startDate);
            q.setParameter("endDate", endDate);
            return q.getResultList();

        } catch (Exception e) {
            System.err.println("Error en findByDateRange: " + e.getMessage());
            return List.of();
        } finally {
            em.close();
        }
    }

    /**
     * Cuenta análisis por producto
     */
    public long countByItemId(String itemId) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT COUNT(pa) FROM ProductAnalysis pa " +
                            "WHERE pa.item.itemId = :itemId"
            );
            q.setParameter("itemId", itemId);
            return (Long) q.getSingleResult();

        } catch (Exception e) {
            System.err.println("Error en countByItemId: " + e.getMessage());
            return 0;
        } finally {
            em.close();
        }
    }

    /**
     * Cuenta análisis por marketplace
     */
    public long countByMarketplace(Integer marketplaceId) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT COUNT(pa) FROM ProductAnalysis pa " +
                            "WHERE pa.idMarketplace.id = :marketplaceId"
            );
            q.setParameter("marketplaceId", marketplaceId);
            return (Long) q.getSingleResult();

        } catch (Exception e) {
            System.err.println("Error en countByMarketplace: " + e.getMessage());
            return 0;
        } finally {
            em.close();
        }
    }

    /**
     * Elimina análisis antiguos de un producto
     * Mantiene solo los últimos N análisis
     *
     * @param itemId ID del producto
     * @param keepLast Cantidad de análisis a mantener
     * @return Cantidad de registros eliminados
     */
    public int deleteOldAnalysis(String itemId, int keepLast) {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();

            // Obtener los IDs de los análisis a mantener
            Query selectQuery = em.createQuery(
                    "SELECT pa.id FROM ProductAnalysis pa " +
                            "WHERE pa.item.itemId = :itemId " +
                            "ORDER BY pa.analysisDate DESC, pa.id DESC"
            );
            selectQuery.setParameter("itemId", itemId);
            selectQuery.setMaxResults(keepLast);
            List<Integer> idsToKeep = selectQuery.getResultList();

            int deleted = 0;

            // Si hay IDs que mantener, eliminar los demás
            if (!idsToKeep.isEmpty()) {
                Query deleteQuery = em.createQuery(
                        "DELETE FROM ProductAnalysis pa " +
                                "WHERE pa.item.itemId = :itemId " +
                                "AND pa.id NOT IN :idsToKeep"
                );
                deleteQuery.setParameter("itemId", itemId);
                deleteQuery.setParameter("idsToKeep", idsToKeep);
                deleted = deleteQuery.executeUpdate();
            }

            em.getTransaction().commit();
            return deleted;

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("Error en deleteOldAnalysis: " + e.getMessage());
            throw new RuntimeException(e);
        } finally {
            em.close();
        }
    }

    /**
     * Elimina todos los análisis de un producto
     */
    public int deleteAllByItemId(String itemId) {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();

            Query deleteQuery = em.createQuery(
                    "DELETE FROM ProductAnalysis pa " +
                            "WHERE pa.item.itemId = :itemId"
            );
            deleteQuery.setParameter("itemId", itemId);
            int deleted = deleteQuery.executeUpdate();

            em.getTransaction().commit();
            return deleted;

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("Error en deleteAllByItemId: " + e.getMessage());
            throw new RuntimeException(e);
        } finally {
            em.close();
        }
    }

    /**
     * Elimina análisis anteriores a una fecha
     */
    public int deleteBeforeDate(LocalDate date) {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();

            Query deleteQuery = em.createQuery(
                    "DELETE FROM ProductAnalysis pa " +
                            "WHERE pa.analysisDate < :date"
            );
            deleteQuery.setParameter("date", date);
            int deleted = deleteQuery.executeUpdate();

            em.getTransaction().commit();
            return deleted;

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("Error en deleteBeforeDate: " + e.getMessage());
            throw new RuntimeException(e);
        } finally {
            em.close();
        }
    }

    // ========================================
    // ESTADÍSTICAS
    // ========================================

    /**
     * Obtiene el promedio general de price_avg
     */
    public Double getAveragePriceDifference() {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT AVG(pa.priceAvg) FROM ProductAnalysis pa"
            );
            return (Double) q.getSingleResult();

        } catch (Exception e) {
            System.err.println("Error en getAveragePriceDifference: " + e.getMessage());
            return 0.0;
        } finally {
            em.close();
        }
    }

    /**
     * Obtiene estadísticas de un producto
     */
    public Object[] getProductStatistics(String itemId) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery(
                    "SELECT " +
                            "  COUNT(pa), " +
                            "  AVG(pa.priceAvg), " +
                            "  MIN(pa.priceMin), " +
                            "  MAX(pa.priceMax), " +
                            "  AVG(pa.sampleAnalysis) " +
                            "FROM ProductAnalysis pa " +
                            "WHERE pa.item.itemId = :itemId"
            );
            q.setParameter("itemId", itemId);
            return (Object[]) q.getSingleResult();

        } catch (Exception e) {
            System.err.println("Error en getProductStatistics: " + e.getMessage());
            return new Object[]{0L, 0.0, 0.0, 0.0, 0.0};
        } finally {
            em.close();
        }
    }

    /**
     * Cierra el EntityManagerFactory
     */
    public void close() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }
}