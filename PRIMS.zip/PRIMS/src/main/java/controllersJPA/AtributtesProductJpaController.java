package controllersJPA;

import controllersJPA.exceptions.NonexistentEntityException;
import controllersJPA.exceptions.PreexistingEntityException;
import entities.AtributtesProduct;
import entities.Producto;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.List;

/**
 * JPA Controller for
 *
 * @author km
 */
public class AtributtesProductJpaController implements Serializable {

    private EntityManagerFactory emf = null;

    public AtributtesProductJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(AtributtesProduct atributtesProducts) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Producto idItem = atributtesProducts.getIdItem();
            if (idItem != null) {
                idItem = em.getReference(idItem.getClass(), idItem.getItemId());
                atributtesProducts.setIdItem(idItem);
            }
            em.persist(atributtesProducts);
            if (idItem != null) {
                idItem.getAtributtesProductsCollection().add(atributtesProducts);
                idItem = em.merge(idItem);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(AtributtesProduct atributtesProducts) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            AtributtesProduct persistentAtributtesProducts = em.find(AtributtesProduct.class, atributtesProducts.getId());
            Producto idItemOld = persistentAtributtesProducts.getIdItem();
            Producto idItemNew = atributtesProducts.getIdItem();
            if (idItemNew != null) {
                idItemNew = em.getReference(idItemNew.getClass(), idItemNew.getItemId());
                atributtesProducts.setIdItem(idItemNew);
            }
            atributtesProducts = em.merge(atributtesProducts);
            if (idItemOld != null && !idItemOld.equals(idItemNew)) {
                idItemOld.getAtributtesProductsCollection().remove(atributtesProducts);
                idItemOld = em.merge(idItemOld);
            }
            if (idItemNew != null && !idItemNew.equals(idItemOld)) {
                idItemNew.getAtributtesProductsCollection().add(atributtesProducts);
                idItemNew = em.merge(idItemNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = atributtesProducts.getId();
                if (findAtributtesProducts(id) == null) {
                    throw new NonexistentEntityException("The atributtesProducts with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            AtributtesProduct atributtesProducts;
            try {
                atributtesProducts = em.getReference(AtributtesProduct.class, id);
                atributtesProducts.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The atributtesProducts with id " + id + " no longer exists.", enfe);
            }
            Producto idItem = atributtesProducts.getIdItem();
            if (idItem != null) {
                idItem.getAtributtesProductsCollection().remove(atributtesProducts);
                idItem = em.merge(idItem);
            }
            em.remove(atributtesProducts);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<AtributtesProduct> findAtributtesProductsEntities() {
        return findAtributtesProductsEntities(true, -1, -1);
    }

    public List<AtributtesProduct> findAtributtesProductsEntities(int maxResults, int firstResult) {
        return findAtributtesProductsEntities(false, maxResults, firstResult);
    }

    private List<AtributtesProduct> findAtributtesProductsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(AtributtesProduct.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public AtributtesProduct findAtributtesProducts(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(AtributtesProduct.class, id);
        } finally {
            em.close();
        }
    }

    public AtributtesProduct findAtributtesProductsByIdItem(String itemId, String attributeName) {
        try {
            EntityManager em = getEntityManager();

            TypedQuery<AtributtesProduct> query = em.createQuery(
                    "SELECT a FROM AtributtesProduct a " +
                            "WHERE a.idItem.itemId = :itemId " +  // ✅ Navegar por la relación
                            "AND a.atributte = :attributeName",
                    AtributtesProduct.class
            );

            query.setParameter("itemId", itemId);
            query.setParameter("attributeName", attributeName);
            query.setMaxResults(1);

            List<AtributtesProduct> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }


    public int getAtributtesProductsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<AtributtesProduct> rt = cq.from(AtributtesProduct.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
