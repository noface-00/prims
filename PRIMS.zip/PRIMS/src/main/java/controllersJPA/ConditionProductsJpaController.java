package controllersJPA;

import controllersJPA.exceptions.IllegalOrphanException;
import controllersJPA.exceptions.NonexistentEntityException;
import entities.ConditionProduct;
import entities.Producto;
import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import utils.JPAUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ConditionProductsJpaController implements Serializable {

    public ConditionProductsJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(ConditionProduct conditionProducts) {
        if (conditionProducts.getProductosCollection() == null) {
            conditionProducts.setProductosCollection(new ArrayList<Producto>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Producto> attachedProductosCollection = new ArrayList<Producto>();
            for (Producto productosCollectionProductosToAttach : conditionProducts.getProductosCollection()) {
                productosCollectionProductosToAttach = em.getReference(productosCollectionProductosToAttach.getClass(), productosCollectionProductosToAttach.getItemId());
                attachedProductosCollection.add(productosCollectionProductosToAttach);
            }
            conditionProducts.setProductosCollection(attachedProductosCollection);
            em.persist(conditionProducts);
            for (Producto productosCollectionProductos : conditionProducts.getProductosCollection()) {
                ConditionProduct oldIdConditionOfProductosCollectionProductos = productosCollectionProductos.getIdCondition();
                productosCollectionProductos.setIdCondition(conditionProducts);
                productosCollectionProductos = em.merge(productosCollectionProductos);
                if (oldIdConditionOfProductosCollectionProductos != null) {
                    oldIdConditionOfProductosCollectionProductos.getProductosCollection().remove(productosCollectionProductos);
                    oldIdConditionOfProductosCollectionProductos = em.merge(oldIdConditionOfProductosCollectionProductos);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(ConditionProduct conditionProducts) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ConditionProduct persistentConditionProducts = em.find(ConditionProduct.class, conditionProducts.getId());
            Collection<Producto> productosCollectionOld = persistentConditionProducts.getProductosCollection();
            Collection<Producto> productosCollectionNew = conditionProducts.getProductosCollection();
            List<String> illegalOrphanMessages = null;
            for (Producto productosCollectionOldProductos : productosCollectionOld) {
                if (!productosCollectionNew.contains(productosCollectionOldProductos)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Productos " + productosCollectionOldProductos + " since its idCondition field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Producto> attachedProductosCollectionNew = new ArrayList<Producto>();
            for (Producto productosCollectionNewProductosToAttach : productosCollectionNew) {
                productosCollectionNewProductosToAttach = em.getReference(productosCollectionNewProductosToAttach.getClass(), productosCollectionNewProductosToAttach.getItemId());
                attachedProductosCollectionNew.add(productosCollectionNewProductosToAttach);
            }
            productosCollectionNew = attachedProductosCollectionNew;
            conditionProducts.setProductosCollection(productosCollectionNew);
            conditionProducts = em.merge(conditionProducts);
            for (Producto productosCollectionNewProductos : productosCollectionNew) {
                if (!productosCollectionOld.contains(productosCollectionNewProductos)) {
                    ConditionProduct oldIdConditionOfProductosCollectionNewProductos = productosCollectionNewProductos.getIdCondition();
                    productosCollectionNewProductos.setIdCondition(conditionProducts);
                    productosCollectionNewProductos = em.merge(productosCollectionNewProductos);
                    if (oldIdConditionOfProductosCollectionNewProductos != null && !oldIdConditionOfProductosCollectionNewProductos.equals(conditionProducts)) {
                        oldIdConditionOfProductosCollectionNewProductos.getProductosCollection().remove(productosCollectionNewProductos);
                        oldIdConditionOfProductosCollectionNewProductos = em.merge(oldIdConditionOfProductosCollectionNewProductos);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = conditionProducts.getId();
                if (findConditionProducts(id) == null) {
                    throw new NonexistentEntityException("The conditionProducts with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ConditionProduct conditionProducts;
            try {
                conditionProducts = em.getReference(ConditionProduct.class, id);
                conditionProducts.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The conditionProducts with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Producto> productosCollectionOrphanCheck = conditionProducts.getProductosCollection();
            for (Producto productosCollectionOrphanCheckProductos : productosCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This ConditionProducts (" + conditionProducts + ") cannot be destroyed since the Productos " + productosCollectionOrphanCheckProductos + " in its productosCollection field has a non-nullable idCondition field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(conditionProducts);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<ConditionProduct> findConditionProductsEntities() {
        return findConditionProductsEntities(true, -1, -1);
    }

    public List<ConditionProduct> findConditionProductsEntities(int maxResults, int firstResult) {
        return findConditionProductsEntities(false, maxResults, firstResult);
    }

    private List<ConditionProduct> findConditionProductsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(ConditionProduct.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public ConditionProduct findConditionProducts(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ConditionProduct.class, id);
        } finally {
            em.close();
        }
    }

    public ConditionProduct findConditionByID(Integer id) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<ConditionProduct> query = em.createNamedQuery("ConditionProducts.findByIdCondition", ConditionProduct.class);
            query.setParameter("idCondition", id);
            ConditionProduct conditionProduct = query.getSingleResult();
            return conditionProduct;
        }catch(Exception ex){
            return null;
        }finally {
            em.close();
        }
    }

    public int getConditionProductsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<ConditionProduct> rt = cq.from(ConditionProduct.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
