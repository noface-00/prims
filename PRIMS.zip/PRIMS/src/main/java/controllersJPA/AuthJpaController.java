package controllersJPA;


import controllersJPA.exceptions.IllegalOrphanException;
import controllersJPA.exceptions.NonexistentEntityException;
import controllersJPA.exceptions.PreexistingEntityException;
import entities.Auth;
import entities.WishlistProduct;
import jakarta.persistence.*;

import java.io.Serializable;

import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.mindrot.jbcrypt.BCrypt;
import utils.JPAUtil;

/**
 *
 * @author Generated
 */
public class AuthJpaController implements Serializable {

    public AuthJpaController() {
        this.emf = JPAUtil.getEntityManagerFactory();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Auth auth) {
        if (auth.getWishlistProductsCollection() == null) {
            auth.setWishlistProductsCollection(new ArrayList<WishlistProduct>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<WishlistProduct> attachedWishlistProductsCollection = new ArrayList<WishlistProduct>();
            for (WishlistProduct wishlistProductsCollectionWishlistProductsToAttach : auth.getWishlistProductsCollection()) {
                wishlistProductsCollectionWishlistProductsToAttach = em.getReference(wishlistProductsCollectionWishlistProductsToAttach.getClass(), wishlistProductsCollectionWishlistProductsToAttach.getId());
                attachedWishlistProductsCollection.add(wishlistProductsCollectionWishlistProductsToAttach);
            }
            auth.setWishlistProductsCollection(attachedWishlistProductsCollection);
            em.persist(auth);
            for (WishlistProduct wishlistProductsCollectionWishlistProducts : auth.getWishlistProductsCollection()) {
                Auth oldIdUserOfWishlistProductsCollectionWishlistProducts = wishlistProductsCollectionWishlistProducts.getIdUser();
                wishlistProductsCollectionWishlistProducts.setIdUser(auth);
                wishlistProductsCollectionWishlistProducts = em.merge(wishlistProductsCollectionWishlistProducts);
                if (oldIdUserOfWishlistProductsCollectionWishlistProducts != null) {
                    oldIdUserOfWishlistProductsCollectionWishlistProducts.getWishlistProductsCollection().remove(wishlistProductsCollectionWishlistProducts);
                    oldIdUserOfWishlistProductsCollectionWishlistProducts = em.merge(oldIdUserOfWishlistProductsCollectionWishlistProducts);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Auth auth) throws PreexistingEntityException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Auth persistentAuth = em.find(Auth.class, auth.getId());
            Collection<WishlistProduct> wishlistProductsCollectionOld = persistentAuth.getWishlistProductsCollection();
            Collection<WishlistProduct> wishlistProductsCollectionNew = auth.getWishlistProductsCollection();
            List<String> illegalOrphanMessages = null;
            for (WishlistProduct wishlistProductsCollectionOldWishlistProducts : wishlistProductsCollectionOld) {
                if (!wishlistProductsCollectionNew.contains(wishlistProductsCollectionOldWishlistProducts)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain WishlistProducts " + wishlistProductsCollectionOldWishlistProducts + " since its idUser field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<WishlistProduct> attachedWishlistProductsCollectionNew = new ArrayList<WishlistProduct>();
            for (WishlistProduct wishlistProductsCollectionNewWishlistProductsToAttach : wishlistProductsCollectionNew) {
                wishlistProductsCollectionNewWishlistProductsToAttach = em.getReference(wishlistProductsCollectionNewWishlistProductsToAttach.getClass(), wishlistProductsCollectionNewWishlistProductsToAttach.getId());
                attachedWishlistProductsCollectionNew.add(wishlistProductsCollectionNewWishlistProductsToAttach);
            }
            wishlistProductsCollectionNew = attachedWishlistProductsCollectionNew;
            auth.setWishlistProductsCollection(wishlistProductsCollectionNew);
            auth = em.merge(auth);
            for (WishlistProduct wishlistProductsCollectionNewWishlistProducts : wishlistProductsCollectionNew) {
                if (!wishlistProductsCollectionOld.contains(wishlistProductsCollectionNewWishlistProducts)) {
                    Auth oldIdUserOfWishlistProductsCollectionNewWishlistProducts = wishlistProductsCollectionNewWishlistProducts.getIdUser();
                    wishlistProductsCollectionNewWishlistProducts.setIdUser(auth);
                    wishlistProductsCollectionNewWishlistProducts = em.merge(wishlistProductsCollectionNewWishlistProducts);
                    if (oldIdUserOfWishlistProductsCollectionNewWishlistProducts != null && !oldIdUserOfWishlistProductsCollectionNewWishlistProducts.equals(auth)) {
                        oldIdUserOfWishlistProductsCollectionNewWishlistProducts.getWishlistProductsCollection().remove(wishlistProductsCollectionNewWishlistProducts);
                        oldIdUserOfWishlistProductsCollectionNewWishlistProducts = em.merge(oldIdUserOfWishlistProductsCollectionNewWishlistProducts);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = auth.getId();
                if (findAuth(id) == null) {
                    throw new NonexistentEntityException("The auth with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Auth auth;
            try {
                auth = em.getReference(Auth.class, id);
                auth.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The auth with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<WishlistProduct> wishlistProductsCollectionOrphanCheck = auth.getWishlistProductsCollection();
            for (WishlistProduct wishlistProductsCollectionOrphanCheckWishlistProducts : wishlistProductsCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Auth (" + auth + ") cannot be destroyed since the WishlistProducts " + wishlistProductsCollectionOrphanCheckWishlistProducts + " in its wishlistProductsCollection field has a non-nullable idUser field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(auth);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Auth> findAuthEntities() {
        return findAuthEntities(true, -1, -1);
    }

    public List<Auth> findAuthEntities(int maxResults, int firstResult) {
        return findAuthEntities(false, maxResults, firstResult);
    }

    private List<Auth> findAuthEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Auth.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Auth findAuth(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Auth.class, id);
        } finally {
            em.close();
        }
    }

    public int getAuthCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Auth> rt = cq.from(Auth.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    /**
     * Login por username
     */
    public Auth loginByUserName(String username, String password) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Auth> query = em.createNamedQuery("Auth.findByUsername", Auth.class);
            query.setParameter("username", username);

            Auth auth;
            try {
                auth = query.getSingleResult();
            } catch (NoResultException nre) {
                return null;
            }

            if (BCrypt.checkpw(password, auth.getPasswordHash())) {
                return auth;
            } else {
                return null;
            }
        }catch (NoResultException nre){
            System.err.println("Error: Username or password is invalid.");
            return null;
        } finally {
            em.close();
        }
    }

    /**
     * Login por email
     */
    public Auth loginByEmail(String email, String password) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Auth> query = em.createNamedQuery("Auth.findByEmail", Auth.class);
            query.setParameter("email", email);

            Auth auth;
            try {
                auth = query.getSingleResult();
            } catch (NoResultException e) {
                return null;
            }

            if (BCrypt.checkpw(password, auth.getPasswordHash())) {
                return auth;
            } else {
                return null;
            }

        } catch (Exception e) {
            System.err.println("Error en login: " + e.getMessage());
            return null;
        } finally {
            em.close();
        }
    }

    /**
     * Registrar un nuevo usuario
     */
    public void register(Auth auth, String plainPassword) throws Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();

            // Hash de la contraseña con BCrypt
            String hashedPassword = BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));
            auth.setPasswordHash(hashedPassword);

            em.persist(auth);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
    /**
     * Resetear contraseña
     */
    public boolean resetPassword(String email, String newPassword) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();

            TypedQuery<Auth> query = em.createNamedQuery("Auth.findByEmail", Auth.class);
            query.setParameter("email", email);

            Auth auth;
            try {
                auth = query.getSingleResult();
            } catch (NoResultException e) {
                em.getTransaction().rollback();
                return false;
            }

            String hashedPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt(12));
            auth.setPasswordHash(hashedPassword);

            em.getTransaction().commit();
            return true;

        } catch (Exception ex) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            ex.printStackTrace();
            return false;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
}