package api;

import com.google.gson.*;
import utils.ErrorHandler;
import utils.NotificationManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class conect_API_eBay {

    private static final String BASE_URL = "https://api.ebay.com/buy/browse/v1/item_summary/search";
    private static final String BASE_URL_PRO = "https://api.ebay.com/buy/browse/v1/item/";
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))  // Timeout de conexión
            .build();
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    // ═══════════════════════════════════════════════════════
    // 🔧 CONFIGURACIÓN Y CONSTANTES
    // ═══════════════════════════════════════════════════════

    private static final int MAX_RETRIES = 3;
    private static final int TIMEOUT_SECONDS = 30;

    public conect_API_eBay() {
    }

    /**
     * 🔑 Obtiene token de acceso con manejo de errores
     */
    public static String getAccesToken(String CLIENT_ID, String CLIENT_SECRET) {
        try {
            return ErrorHandler.retryOperation(() -> {
                return getAccessTokenInternal(CLIENT_ID, CLIENT_SECRET);
            }, MAX_RETRIES, "obtener token de eBay");

        } catch (Exception e) {
            ErrorHandler.handleApiError(e, "obtener token de autenticación");
            return null;
        }
    }

    /**
     * Implementación interna de obtención de token
     */
    private static String getAccessTokenInternal(String CLIENT_ID, String CLIENT_SECRET) throws Exception {
        String tokenUrl = "https://api.ebay.com/identity/v1/oauth2/token";
        String scope = "https://api.ebay.com/oauth/api_scope";

        String body = "grant_type=" + URLEncoder.encode("client_credentials", "UTF-8")
                + "&scope=" + URLEncoder.encode(scope, "UTF-8");

        String credentials = Base64.getEncoder().encodeToString(
                (CLIENT_ID + ":" + CLIENT_SECRET).getBytes(StandardCharsets.UTF_8));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(tokenUrl))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("Authorization", "Basic " + credentials)
                .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200 && response.body().contains("\"access_token\"")) {
            String json = response.body();
            int start = json.indexOf("\"access_token\":\"") + 16;
            int end = json.indexOf("\"", start);
            System.out.println("✅ Conexión exitosa con la API de eBay");
            return json.substring(start, end);
        } else {
            throw new IOException("Error HTTP " + response.statusCode() + ": " + response.body());
        }
    }

    /**
     * 🔍 Busca productos con manejo robusto de errores
     */
    /**
     * 🔍 Busca productos aplicando filtros avanzados.
     */
    public static JsonArray browseProducts(
            String token,
            String palabra,
            int limite,
            Double minPrice,
            Double maxPrice,
            String condition,
            String category
    ) {
        try {
            if (token == null || token.isEmpty()) {
                NotificationManager.error("🔑 Token de autenticación no válido");
                return new JsonArray();
            }

            if (palabra == null || palabra.trim().isEmpty()) {
                NotificationManager.warning("⚠️ Debes ingresar un término de búsqueda");
                return new JsonArray();
            }

            return ErrorHandler.retryOperation(() ->
                            browseProductsInternal(
                                    token, palabra, limite,
                                    minPrice, maxPrice, condition, category
                            ),
                    2,
                    "buscar productos en eBay");

        } catch (Exception e) {
            ErrorHandler.handleSearchError(e);
            return new JsonArray();
        }
    }

    /**
     * Implementación interna de búsqueda de productos
     */
    private static JsonArray browseProductsInternal(
            String token,
            String palabra,
            int limite,
            Double minPrice,
            Double maxPrice,
            String condition,
            String category
    ) throws Exception {
        JsonArray resultados = new JsonArray();

        // ========== CONSTRUIR URL CON PARÁMETROS ==========
        StringBuilder urlBuilder = new StringBuilder("https://api.ebay.com/buy/browse/v1/item_summary/search?");

        // Query de búsqueda
        urlBuilder.append("q=").append(URLEncoder.encode(palabra, StandardCharsets.UTF_8));

        // Límite de resultados
        urlBuilder.append("&limit=").append(limite);

        // Filtro: Rango de precio
        if (minPrice != null || maxPrice != null) {
            urlBuilder.append("&filter=price:");
            if (minPrice != null && maxPrice != null) {
                urlBuilder.append("[").append(minPrice).append("..").append(maxPrice).append("]");
            } else if (minPrice != null) {
                urlBuilder.append("[").append(minPrice).append("..]");
            } else {
                urlBuilder.append("[..").append(maxPrice).append("]");
            }
            urlBuilder.append(",priceCurrency:USD");
        }

        // Filtro: Condición (NEW, USED, etc.)
        if (condition != null && !condition.isEmpty()) {
            urlBuilder.append("&filter=conditions:").append(URLEncoder.encode("{" + condition + "}", StandardCharsets.UTF_8));
        }

        // Filtro: Categoría
        if (category != null && !category.isEmpty()) {
            urlBuilder.append("&filter=categoryIds:").append(URLEncoder.encode("{" + category + "}", StandardCharsets.UTF_8));
        }

        String url = urlBuilder.toString();

        System.err.println("📡 URL completa: " + url);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + token)
                .header("Accept", "application/json")
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY_US")
                .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
                .GET()
                .build();

        HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());

        // Debug
        System.err.println("📊 Status Code: " + response.statusCode());

        if (response.statusCode() != 200) {
            System.err.println("❌ Error response: " + response.body());
            throw new IOException("Error HTTP " + response.statusCode() + ": " + response.body());
        }

        JsonObject json = gson.fromJson(response.body(), JsonObject.class);

        if (json.has("itemSummaries")) {
            JsonArray items = json.getAsJsonArray("itemSummaries");
            System.out.println("✅ Encontrados " + items.size() + " resultados para: " + palabra);

            for (JsonElement itemElem : items) {
                JsonObject item = itemElem.getAsJsonObject();
                JsonObject nuevo = new JsonObject();

                try {
                    // ID y título
                    nuevo.addProperty("itemId",
                            item.has("itemId") ? item.get("itemId").getAsString() : "");
                    nuevo.addProperty("title",
                            item.has("title") ? item.get("title").getAsString() : "Sin título");

                    // Precio
                    if (item.has("price") && item.get("price").isJsonObject()) {
                        JsonObject price = item.getAsJsonObject("price");
                        nuevo.addProperty("price",
                                price.has("value") ? price.get("value").getAsString() : "0");
                        nuevo.addProperty("currency",
                                price.has("currency") ? price.get("currency").getAsString() : "USD");
                    }

                    // ========== VERIFICAR SI REALMENTE ENVÍA A ECUADOR ==========
                    boolean enviaAEcuador = true; // Por defecto asumir que sí (ya filtramos en la búsqueda)

                    // Agregar esta info para debugging
                    if (item.has("itemLocation") && item.get("itemLocation").isJsonObject()) {
                        JsonObject location = item.getAsJsonObject("itemLocation");
                        if (location.has("country")) {
                            nuevo.addProperty("itemLocationCountry", location.get("country").getAsString());
                        }
                    }

                    // Categorías
                    if (item.has("categories") && item.get("categories").isJsonArray()) {
                        JsonArray categorias = new JsonArray();
                        for (JsonElement cat : item.getAsJsonArray("categories")) {
                            if (cat.isJsonObject()) {
                                JsonObject catObj = cat.getAsJsonObject();
                                JsonObject simpleCat = new JsonObject();
                                simpleCat.addProperty("categoryId",
                                        catObj.has("categoryId") ? catObj.get("categoryId").getAsString() : "");
                                simpleCat.addProperty("categoryName",
                                        catObj.has("categoryName") ? catObj.get("categoryName").getAsString() : "");
                                categorias.add(simpleCat);
                            }
                        }
                        nuevo.add("categories", categorias);
                    }

                    // Condición
                    if (item.has("conditionId") && item.has("condition")) {
                        JsonObject condicion = new JsonObject();
                        condicion.addProperty("conditionId", item.get("conditionId").getAsString());
                        condicion.addProperty("condition", item.get("condition").getAsString());
                        nuevo.add("condition", condicion);
                    }

                    // Imágenes
                    JsonArray allImages = new JsonArray();
                    if (item.has("image") && item.get("image").isJsonObject()) {
                        JsonObject img = item.getAsJsonObject("image");
                        if (img.has("imageUrl")) {
                            allImages.add(img.get("imageUrl").getAsString());
                        }
                    }
                    if (item.has("additionalImages") && item.get("additionalImages").isJsonArray()) {
                        JsonArray adicionales = item.getAsJsonArray("additionalImages");
                        for (JsonElement addElem : adicionales) {
                            if (addElem.isJsonObject()) {
                                JsonObject add = addElem.getAsJsonObject();
                                if (add.has("imageUrl")) {
                                    allImages.add(add.get("imageUrl").getAsString());
                                }
                            }
                        }
                    }
                    if (allImages.size() == 0) {
                        allImages.add("Sin imágenes disponibles");
                    }
                    nuevo.add("images", allImages);

                    // Vendedor
                    if (item.has("seller") && item.get("seller").isJsonObject()) {
                        JsonObject seller = item.getAsJsonObject("seller");
                        JsonObject vendedor = new JsonObject();
                        vendedor.addProperty("username",
                                seller.has("username") ? seller.get("username").getAsString() : "Desconocido");
                        vendedor.addProperty("feedbackPercentage",
                                seller.has("feedbackPercentage") ? seller.get("feedbackPercentage").getAsString() : "N/A");
                        vendedor.addProperty("feedbackScore",
                                seller.has("feedbackScore") ? seller.get("feedbackScore").getAsInt() : 0);
                        nuevo.add("seller", vendedor);
                    }

                    // ========== INFO DE ENVÍO (si está disponible en el summary) ==========
                    if (item.has("shippingOptions") && item.get("shippingOptions").isJsonArray()) {
                        JsonArray shippingOpts = item.getAsJsonArray("shippingOptions");
                        if (shippingOpts.size() > 0) {
                            JsonObject firstShipping = shippingOpts.get(0).getAsJsonObject();
                            if (firstShipping.has("shippingCost") && firstShipping.get("shippingCost").isJsonObject()) {
                                JsonObject cost = firstShipping.getAsJsonObject("shippingCost");
                                nuevo.addProperty("shippingCost",
                                        cost.has("value") ? cost.get("value").getAsString() : "0.00");
                            }
                        }
                    }

                    // Otros campos
                    nuevo.addProperty("topRatedBuyingExperience",
                            item.has("topRatedBuyingExperience") && item.get("topRatedBuyingExperience").isJsonPrimitive()
                                    ? item.get("topRatedBuyingExperience").getAsBoolean() : false);

                    if (item.has("itemCreationDate") && item.get("itemCreationDate").isJsonPrimitive()) {
                        nuevo.addProperty("itemCreationDate", item.get("itemCreationDate").getAsString());
                    }

                    nuevo.addProperty("itemWebUrl",
                            item.has("itemWebUrl") ? item.get("itemWebUrl").getAsString() : "");

                    resultados.add(nuevo);

                } catch (Exception e) {
                    ErrorHandler.logWarning("Error procesando item: " + e.getMessage());
                }
            }
        } else {
            System.out.println("⚠️ No se encontraron productos para: " + palabra);
        }

        return resultados;
    }

    /**
     * 📦 Obtiene información adicional del producto
     */
    public static JsonArray aditional_info_pro(String token, String itemId) {
        try {
            if (token == null || token.isEmpty()) {
                NotificationManager.error("🔑 Token no válido");
                return new JsonArray();
            }

            if (itemId == null || itemId.isEmpty()) {
                NotificationManager.warning("⚠️ ID de producto no válido");
                return new JsonArray();
            }

            return ErrorHandler.retryOperation(() -> {
                return getAdditionalInfoInternal(token, itemId);
            }, 2, "obtener información adicional del producto");

        } catch (Exception e) {
            ErrorHandler.handleApiError(e, "cargar detalles del producto");
            return new JsonArray();
        }
    }

    /**
     * Implementación interna de información adicional
     * VERSIÓN SIMPLIFICADA - Un solo método con manejo automático de errores
     */
    private static JsonArray getAdditionalInfoInternal(String token, String itemId) throws Exception {
        JsonArray resultados = new JsonArray();

        // ========== REALIZAR PETICIÓN PRINCIPAL ==========
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.ebay.com/buy/browse/v1/item/" + itemId))
                .header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json")
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY_US")
                .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
                .GET()
                .build();

        HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());

        System.err.println("📊 Status Code: " + response.statusCode());

        // ========== MANEJO DE ERRORES CON RECUPERACIÓN AUTOMÁTICA ==========
        if (response.statusCode() != 200) {
            System.err.println("❌ Error response: " + response.body());
            String errorBody = response.body();

            // 🔧 CASO 1: Es un Item Group → reintentar con endpoint correcto
            if (response.statusCode() == 400 && errorBody.contains("item_group_id")) {
                System.err.println("⚠️ Detectado Item Group, reintentando...");

                if (errorBody.contains("item_group_id=")) {
                    int start = errorBody.indexOf("item_group_id=") + 14;
                    int end = errorBody.indexOf("\"", start);
                    if (end == -1) end = errorBody.indexOf(" ", start);
                    if (end == -1) end = errorBody.length();

                    String groupId = errorBody.substring(start, end).trim();
                    System.err.println("🔍 Item Group ID: " + groupId);

                    // Consultar el item group
                    String urlGroup = "https://api.ebay.com/buy/browse/v1/item/get_items_by_item_group?item_group_id=" + groupId;

                    HttpRequest requestGroup = HttpRequest.newBuilder()
                            .uri(URI.create(urlGroup))
                            .header("Authorization", "Bearer " + token)
                            .header("Content-Type", "application/json")
                            .header("X-EBAY-C-MARKETPLACE-ID", "EBAY_US")
                            .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
                            .GET()
                            .build();

                    HttpResponse<String> responseGroup = CLIENT.send(requestGroup, HttpResponse.BodyHandlers.ofString());

                    if (responseGroup.statusCode() == 200) {
                        JsonObject jsonGroup = gson.fromJson(responseGroup.body(), JsonObject.class);

                        if (jsonGroup.has("items") && jsonGroup.get("items").isJsonArray()) {
                            JsonArray items = jsonGroup.getAsJsonArray("items");
                            System.err.println("✅ Item Group con " + items.size() + " variantes");

                            if (items.size() > 0) {
                                return processItemDetails(items.get(0).getAsJsonObject());
                            }
                        }
                    }
                }
            }

            // 🔧 CASO 2: NO es Item Group, usar ID completo del mensaje de error
            if (response.statusCode() == 400 && errorBody.contains("Item Group Id is invalid") && errorBody.contains("item/")) {
                System.err.println("⚠️ No es Item Group, usando ID del mensaje...");

                int start = errorBody.indexOf("item/") + 5;
                int end = errorBody.indexOf("\"", start);
                if (end == -1) end = errorBody.indexOf(" ", start);

                String correctItemId = errorBody.substring(start, end).trim();
                System.err.println("🔍 ItemID correcto: " + correctItemId);

                // Reintentar con el ID correcto
                String urlCorrect = "https://api.ebay.com/buy/browse/v1/item/" + correctItemId;

                HttpRequest requestCorrect = HttpRequest.newBuilder()
                        .uri(URI.create(urlCorrect))
                        .header("Authorization", "Bearer " + token)
                        .header("Content-Type", "application/json")
                        .header("X-EBAY-C-MARKETPLACE-ID", "EBAY_US")
                        .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
                        .GET()
                        .build();

                HttpResponse<String> responseCorrect = CLIENT.send(requestCorrect, HttpResponse.BodyHandlers.ofString());

                if (responseCorrect.statusCode() == 200) {
                    JsonObject item = gson.fromJson(responseCorrect.body(), JsonObject.class);
                    return processItemDetails(item);
                }
            }

            throw new IOException("Error HTTP " + response.statusCode() + ": " + response.body());
        }

        // ========== PROCESAMIENTO NORMAL ==========
        JsonObject item = gson.fromJson(response.body(), JsonObject.class);
        return processItemDetails(item);
    }

    /**
     * 🔧 Procesa los detalles de un item
     */
    private static JsonArray processItemDetails(JsonObject item) {
        JsonArray resultados = new JsonArray();
        JsonObject nuevo = new JsonObject();

        try {
            // ========== VERIFICAR SI ENVÍA A ECUADOR ==========
            boolean enviaAEcuador = false;

            if (item.has("shipToLocations") && item.get("shipToLocations").isJsonObject()) {
                JsonObject shipTo = item.getAsJsonObject("shipToLocations");

                boolean excluyeEC = false;
                if (shipTo.has("regionExcluded") && shipTo.get("regionExcluded").isJsonArray()) {
                    for (JsonElement region : shipTo.getAsJsonArray("regionExcluded")) {
                        JsonObject r = region.getAsJsonObject();
                        String regionId = r.has("regionId") ? r.get("regionId").getAsString() : "";

                        if (regionId.equals("EC") || regionId.equals("SOUTH_AMERICA")) {
                            excluyeEC = true;
                            break;
                        }
                    }
                }

                if (!excluyeEC && shipTo.has("regionIncluded") && shipTo.get("regionIncluded").isJsonArray()) {
                    for (JsonElement region : shipTo.getAsJsonArray("regionIncluded")) {
                        JsonObject r = region.getAsJsonObject();
                        String regionId = r.has("regionId") ? r.get("regionId").getAsString() : "";

                        if (regionId.equals("EC") || regionId.equals("SOUTH_AMERICA") || regionId.equals("WORLDWIDE")) {
                            enviaAEcuador = true;
                            break;
                        }
                    }
                }
            }

            System.err.println("🌎 ¿Envía a Ecuador? " + enviaAEcuador);
            nuevo.addProperty("shipsToEcuador", enviaAEcuador);

            // ==========================
            // 📝 DESCRIPCIÓN
            // ==========================
            nuevo.addProperty("shortDescription",
                    item.has("shortDescription") && !item.get("shortDescription").isJsonNull()
                            ? item.get("shortDescription").getAsString()
                            : "Sin descripción disponible");

            // ========== OPCIONES DE ENVÍO ==========
            if (enviaAEcuador && item.has("shippingOptions") && item.get("shippingOptions").isJsonArray()) {
                JsonArray shippingArray = new JsonArray();

                for (JsonElement shipElem : item.getAsJsonArray("shippingOptions")) {
                    JsonObject ship = shipElem.getAsJsonObject();
                    JsonObject envio = new JsonObject();

                    envio.addProperty("type",
                            ship.has("type") ? ship.get("type").getAsString() : "N/A");

                    envio.addProperty("shippingCarrierCode",
                            ship.has("shippingCarrierCode") ? ship.get("shippingCarrierCode").getAsString() : "N/A");

                    if (ship.has("shippingCost") && ship.get("shippingCost").isJsonObject()) {
                        JsonObject cost = ship.getAsJsonObject("shippingCost");
                        JsonObject costoEnvio = new JsonObject();
                        costoEnvio.addProperty("value", cost.has("value") ? cost.get("value").getAsString() : "0.00");
                        costoEnvio.addProperty("currency", cost.has("currency") ? cost.get("currency").getAsString() : "USD");
                        envio.add("shippingCost", costoEnvio);
                    }

                    envio.addProperty("quantityUsedForEstimate",
                            ship.has("quantityUsedForEstimate") ? ship.get("quantityUsedForEstimate").getAsInt() : 0);

                    envio.addProperty("minEstimatedDeliveryDate",
                            ship.has("minEstimatedDeliveryDate") ? ship.get("minEstimatedDeliveryDate").getAsString() : "N/A");
                    envio.addProperty("maxEstimatedDeliveryDate",
                            ship.has("maxEstimatedDeliveryDate") ? ship.get("maxEstimatedDeliveryDate").getAsString() : "N/A");

                    if (ship.has("additionalShippingCostPerUnit") && ship.get("additionalShippingCostPerUnit").isJsonObject()) {
                        JsonObject addCost = ship.getAsJsonObject("additionalShippingCostPerUnit");
                        JsonObject costoAdicional = new JsonObject();
                        costoAdicional.addProperty("value", addCost.has("value") ? addCost.get("value").getAsString() : "0.00");
                        costoAdicional.addProperty("currency", addCost.has("currency") ? addCost.get("currency").getAsString() : "USD");
                        envio.add("additionalShippingCostPerUnit", costoAdicional);
                    }

                    envio.addProperty("shippingCostType",
                            ship.has("shippingCostType") ? ship.get("shippingCostType").getAsString() : "N/A");

                    shippingArray.add(envio);
                }

                nuevo.add("shippingOptions", shippingArray);
                System.err.println("✅ " + shippingArray.size() + " opciones de envío");

            } else if (!enviaAEcuador) {
                System.err.println("⚠️ NO envía a Ecuador");
                nuevo.addProperty("shippingAvailable", false);
                nuevo.addProperty("shippingMessage", "Este vendedor no envía a Ecuador");
            }

            // ==========================
            // 🔄 POLÍTICA DE DEVOLUCIONES
            // ==========================
            if (item.has("returnTerms") && item.get("returnTerms").isJsonObject()) {
                JsonObject returnTerms = item.getAsJsonObject("returnTerms");
                boolean returnsAccepted = returnTerms.has("returnsAccepted")
                        && returnTerms.get("returnsAccepted").getAsBoolean();
                nuevo.addProperty("returnsAccepted", returnsAccepted);

                if (returnTerms.has("returnPeriod") && returnTerms.get("returnPeriod").isJsonObject()) {
                    JsonObject period = returnTerms.getAsJsonObject("returnPeriod");
                    if (period.has("value")) {
                        nuevo.addProperty("returnPeriodValue", period.get("value").getAsInt());
                    }
                    if (period.has("unit")) {
                        nuevo.addProperty("returnPeriodUnit", period.get("unit").getAsString());
                    }
                }

                if (returnTerms.has("returnShippingCostPayer")) {
                    nuevo.addProperty("returnShippingCostPayer",
                            returnTerms.get("returnShippingCostPayer").getAsString());
                }
            } else {
                nuevo.addProperty("returnsAccepted", false);
            }

            // ==========================
            // 🎟 CUPONES DISPONIBLES
            // ==========================
            if (item.has("availableCoupons") && item.get("availableCoupons").isJsonArray()) {
                JsonArray couponsArray = new JsonArray();

                for (JsonElement couponElem : item.getAsJsonArray("availableCoupons")) {
                    if (!couponElem.isJsonObject()) continue;

                    JsonObject coupon = couponElem.getAsJsonObject();
                    JsonObject nuevoCupon = new JsonObject();

                    if (coupon.has("redemptionCode"))
                        nuevoCupon.addProperty("redemptionCode", coupon.get("redemptionCode").getAsString());

                    if (coupon.has("discountAmount") && coupon.get("discountAmount").isJsonObject()) {
                        JsonObject discount = coupon.getAsJsonObject("discountAmount");
                        nuevoCupon.addProperty("discountAmount",
                                discount.has("value") ? discount.get("value").getAsString() : "0.00");
                        nuevoCupon.addProperty("discountCurrency",
                                discount.has("currency") ? discount.get("currency").getAsString() : "USD");
                    }

                    if (coupon.has("discountType")) {
                        nuevoCupon.addProperty("discountType", coupon.get("discountType").getAsString());
                    }

                    if (coupon.has("message")) {
                        nuevoCupon.addProperty("message", coupon.get("message").getAsString());
                    }

                    if (coupon.has("constraint") && coupon.get("constraint").isJsonObject()) {
                        JsonObject constraint = coupon.getAsJsonObject("constraint");

                        if (constraint.has("expirationDate"))
                            nuevoCupon.addProperty("expirationDate", constraint.get("expirationDate").getAsString());

                        if (constraint.has("minimumQuantity"))
                            nuevoCupon.addProperty("minimumQuantity", constraint.get("minimumQuantity").getAsInt());
                    }

                    couponsArray.add(nuevoCupon);
                }

                nuevo.add("availableCoupons", couponsArray);
                System.err.println("🎟 " + couponsArray.size() + " cupones");
            }

            // ==========================
            // 📦 DISPONIBILIDAD ESTIMADA
            // ==========================
            if (item.has("estimatedAvailabilities") && item.get("estimatedAvailabilities").isJsonArray()) {
                JsonArray availArray = item.getAsJsonArray("estimatedAvailabilities");

                if (!availArray.isEmpty()) {
                    JsonObject first = availArray.get(0).getAsJsonObject();
                    JsonObject disponibilidad = new JsonObject();

                    if (first.has("estimatedAvailabilityStatus")) {
                        disponibilidad.addProperty("status", first.get("estimatedAvailabilityStatus").getAsString());
                    }

                    if (first.has("estimatedAvailableQuantity")) {
                        disponibilidad.addProperty("availableQuantity", first.get("estimatedAvailableQuantity").getAsInt());
                    }

                    if (first.has("estimatedSoldQuantity")) {
                        disponibilidad.addProperty("soldQuantity", first.get("estimatedSoldQuantity").getAsInt());
                    }

                    if (first.has("deliveryOptions")) {
                        disponibilidad.addProperty("deliveryOptions", first.get("deliveryOptions").getAsString());
                    }

                    nuevo.add("availability", disponibilidad);
                    System.err.println("📦 Disponibilidad: " + disponibilidad.get("status").getAsString());
                }
            } else {
                JsonObject disponibilidad = new JsonObject();
                disponibilidad.addProperty("status", "UNKNOWN");
                nuevo.add("availability", disponibilidad);
            }

            // ==========================
            // 🔧 ATRIBUTOS DEL PRODUCTO
            // ==========================
            if (item.has("localizedAspects") && item.get("localizedAspects").isJsonArray()) {
                JsonArray aspectosLimpios = new JsonArray();

                for (JsonElement aspectElem : item.getAsJsonArray("localizedAspects")) {
                    if (!aspectElem.isJsonObject()) continue;

                    JsonObject aspect = aspectElem.getAsJsonObject();
                    JsonObject atributo = new JsonObject();

                    if (aspect.has("name"))
                        atributo.addProperty("name", aspect.get("name").getAsString());

                    if (aspect.has("value")) {
                        JsonElement valor = aspect.get("value");

                        if (valor.isJsonPrimitive()) {
                            atributo.addProperty("value", valor.getAsString());
                        } else if (valor.isJsonArray()) {
                            JsonArray valArray = valor.getAsJsonArray();
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < valArray.size(); i++) {
                                if (i > 0) sb.append(", ");
                                sb.append(valArray.get(i).getAsString());
                            }
                            atributo.addProperty("value", sb.toString());
                        } else {
                            atributo.addProperty("value", valor.toString());
                        }
                    }

                    if (atributo.has("name"))
                        aspectosLimpios.add(atributo);
                }

                nuevo.add("localizedAspects", aspectosLimpios);
                System.err.println("🔧 " + aspectosLimpios.size() + " atributos");

            } else {
                nuevo.add("localizedAspects", new JsonArray());
            }

            // ==========================
            // 📌 INFORMACIÓN ADICIONAL
            // ==========================

            if (item.has("quantityLimitPerBuyer")) {
                nuevo.addProperty("quantityLimitPerBuyer", item.get("quantityLimitPerBuyer").getAsInt());
            }

            if (item.has("product") && item.get("product").isJsonObject()) {
                JsonObject product = item.getAsJsonObject("product");
                JsonObject productInfo = new JsonObject();

                if (product.has("title")) {
                    productInfo.addProperty("title", product.get("title").getAsString());
                }

                if (product.has("description")) {
                    productInfo.addProperty("description", product.get("description").getAsString());
                }

                if (product.has("brand")) {
                    productInfo.addProperty("brand", product.get("brand").getAsString());
                }

                if (product.has("mpn")) {
                    productInfo.addProperty("mpn", product.get("mpn").getAsString());
                }

                if (product.has("gtin")) {
                    productInfo.addProperty("gtin", product.get("gtin").getAsString());
                }

                nuevo.add("productInfo", productInfo);
            }

            if (item.has("conditionDescription")) {
                nuevo.addProperty("conditionDescription", item.get("conditionDescription").getAsString());
            }

            if (item.has("itemAffiliateWebUrl")) {
                nuevo.addProperty("itemAffiliateWebUrl", item.get("itemAffiliateWebUrl").getAsString());
            }

            if (item.has("marketingPrice") && item.get("marketingPrice").isJsonObject()) {
                JsonObject marketingPrice = item.getAsJsonObject("marketingPrice");
                JsonObject marketing = new JsonObject();

                if (marketingPrice.has("originalPrice") && marketingPrice.get("originalPrice").isJsonObject()) {
                    JsonObject originalPrice = marketingPrice.getAsJsonObject("originalPrice");
                    marketing.addProperty("originalPrice",
                            originalPrice.has("value") ? originalPrice.get("value").getAsString() : "0.00");
                }

                if (marketingPrice.has("discountPercentage")) {
                    marketing.addProperty("discountPercentage",
                            marketingPrice.get("discountPercentage").getAsString());
                }

                if (marketingPrice.has("discountAmount") && marketingPrice.get("discountAmount").isJsonObject()) {
                    JsonObject discountAmount = marketingPrice.getAsJsonObject("discountAmount");
                    marketing.addProperty("discountAmount",
                            discountAmount.has("value") ? discountAmount.get("value").getAsString() : "0.00");
                }

                nuevo.add("marketingPrice", marketing);
            }

            resultados.add(nuevo);

        } catch (Exception e) {
            ErrorHandler.logWarning("Error procesando detalles del producto: " + e.getMessage());
            e.printStackTrace();
        }

        return resultados;
    }
    /**
     * 🏷️ Busca productos por vendedor con manejo de errores
     */
    public JsonArray buscarProductosPorVendedor(String token, String sellerUsername, int limit) {
        try {
            if (token == null || sellerUsername == null || sellerUsername.isEmpty()) {
                NotificationManager.warning("⚠️ Datos de búsqueda inválidos");
                return new JsonArray();
            }

            return ErrorHandler.retryOperation(() -> {
                return searchBySellerInternal(token, sellerUsername, limit);
            }, 2, "buscar productos del vendedor");

        } catch (Exception e) {
            ErrorHandler.handleApiError(e, "buscar productos del vendedor");
            return new JsonArray();
        }
    }

    private JsonArray searchBySellerInternal(String token, String sellerUsername, int limit) throws Exception {
        JsonArray resultados = new JsonArray();

        String endpoint = "https://api.ebay.com/buy/browse/v1/item_summary/search";
        String url = endpoint + "?q=" + URLEncoder.encode(sellerUsername, StandardCharsets.UTF_8)
                + "&limit=" + limit;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + token)
                .header("Accept", "application/json")
                .header("X-EBAY-C-MARKETPLACE-ID", "EBAY_US")
                .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
                .GET()
                .build();

        HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            JsonObject json = gson.fromJson(response.body(), JsonObject.class);
            if (json.has("itemSummaries")) {
                resultados = json.getAsJsonArray("itemSummaries");
            }
        } else {
            throw new IOException("Error HTTP " + response.statusCode());
        }

        return resultados;
    }

    /**
     * 💰 Obtiene precios del mercado con manejo de errores
     */
    public static List<Double> obtenerPreciosDelMercado(String query, String token) {
        List<Double> precios = new ArrayList<>();

        try {
            JsonArray items = browseProducts(token, query, 50,null,null,null,null);

            for (JsonElement elem : items) {
                try {
                    JsonObject obj = elem.getAsJsonObject();
                    if (obj.has("price")) {
                        String priceStr = obj.get("price").getAsString();
                        double price = Double.parseDouble(priceStr);
                        if (price > 0) {
                            precios.add(price);
                        }
                    }
                } catch (Exception e) {
                    // Ignorar items con precio inválido
                    ErrorHandler.logWarning("Precio inválido en item: " + e.getMessage());
                }
            }

            if (precios.isEmpty()) {
                NotificationManager.info("ℹ️ No se encontraron precios válidos para análisis");
            }

        } catch (Exception e) {
            ErrorHandler.handleApiError(e, "obtener precios del mercado");
        }

        return precios;
    }

    public Double obtenerPrecioActual(String itemId, String token) {
        try {
            if (itemId == null || token == null) return null;


            // ✅ IMPORTANTE: Usar solo el número, NO el formato completo
            String url =
                    "https://api.ebay.com/buy/browse/v1/item/" + itemId;  // ❌ NO usar URLEncoder aquí

            System.err.println("📡 Consultando precio con LEGACY ID: " + itemId);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Authorization", "Bearer " + token)
                    .header("Accept", "application/json")
                    .header("X-EBAY-C-MARKETPLACE-ID", "EBAY_US")
                    .timeout(Duration.ofSeconds(30))
                    .GET()
                    .build();

            HttpResponse<String> response =
                    CLIENT.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                System.err.println("❌ Error eBay (" + response.statusCode() + "): " + response.body());
                return null;
            }

            JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();

            if (json.has("price") && json.get("price").isJsonObject()) {
                JsonObject price = json.getAsJsonObject("price");
                if (price.has("value")) {
                    double precioActual = price.get("value").getAsDouble();
                    System.err.println("✅ Precio obtenido: $" + precioActual);
                    return precioActual;
                }
            }

            System.err.println("⚠️ Item sin precio disponible");
            return null;

        } catch (Exception e) {
            System.err.println("❌ Error obteniendo precio: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    public List<JsonObject> buscarProductosSimilares(String query, String token) {
        List<JsonObject> resultados = new ArrayList<>();

        try {
            String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);
            String url = "https://api.ebay.com/buy/browse/v1/item_summary/search?q=" + encodedQuery;

            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + token);
            con.setRequestProperty("Content-Type", "application/json");

            int status = con.getResponseCode();
            if (status != 200) {
                System.err.println("❌ Error al buscar productos similares (" + status + ")");
                return resultados;
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = in.readLine()) != null) {
                response.append(line);
            }

            JsonObject json = JsonParser.parseString(response.toString()).getAsJsonObject();

            if (!json.has("itemSummaries")) {
                return resultados;
            }

            json.getAsJsonArray("itemSummaries").forEach(elem -> resultados.add(elem.getAsJsonObject()));

        } catch (Exception e) {
            System.err.println("⚠️ Error buscando productos similares: " + e.getMessage());
        }

        return resultados;
    }


}