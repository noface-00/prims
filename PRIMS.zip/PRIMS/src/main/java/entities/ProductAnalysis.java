package entities;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "product_analysis", schema = "PRIMS",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_item_date",              // Nombre del constraint
                        columnNames = {"itemId", "analysis_date"}  // Campos que forman la clave única
                )
        }
)
public class ProductAnalysis {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "itemId", nullable = false)
    private Producto item;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_precio_historico", nullable = false)
    private PriceHistory idPrecioHistorico;

    @Column(name = "price_avg", nullable = false)
    private Double priceAvg;

    @Column(name = "price_min", nullable = false)
    private Double priceMin;

    @Column(name = "price_max", nullable = false)
    private Double priceMax;

    @Column(name = "sample_analysis", nullable = false)
    private Integer sampleAnalysis;

    @Column(name = "analysis_date", nullable = false)
    private LocalDate analysisDate;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_marketplace", nullable = false)
    private Marketplace idMarketplace;

    @Column(name = "price_std", nullable = false)
    private Double priceStd;

    @Lob
    @Column(name = "notes")
    private String notes;

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Double getPriceStd() {
        return priceStd;
    }

    public void setPriceStd(Double priceStd) {
        this.priceStd = priceStd;
    }

    public Marketplace getIdMarketplace() {
        return idMarketplace;
    }

    public void setIdMarketplace(Marketplace idMarketplace) {
        this.idMarketplace = idMarketplace;
    }

    public LocalDate getAnalysisDate() {
        return analysisDate;
    }

    public void setAnalysisDate(LocalDate analysisDate) {
        this.analysisDate = analysisDate;
    }

    public Integer getSampleAnalysis() {
        return sampleAnalysis;
    }

    public void setSampleAnalysis(Integer sampleAnalysis) {
        this.sampleAnalysis = sampleAnalysis;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Producto getItem() {
        return item;
    }

    public void setItem(Producto item) {
        this.item = item;
    }

    public PriceHistory getIdPrecioHistorico() {
        return idPrecioHistorico;
    }

    public void setIdPrecioHistorico(PriceHistory idPrecioHistorico) {
        this.idPrecioHistorico = idPrecioHistorico;
    }

    public Double getPriceAvg() {
        return priceAvg;
    }

    public void setPriceAvg(Double priceAvg) {
        this.priceAvg = priceAvg;
    }

    public Double getPriceMin() {
        return priceMin;
    }

    public void setPriceMin(Double priceMin) {
        this.priceMin = priceMin;
    }

    public Double getPriceMax() {
        return priceMax;
    }

    public void setPriceMax(Double priceMax) {
        this.priceMax = priceMax;
    }

}