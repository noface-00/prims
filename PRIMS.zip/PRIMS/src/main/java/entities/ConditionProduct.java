package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "condition_products", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "ConditionProducts.findAll", query = "SELECT c FROM ConditionProduct c"),
        @NamedQuery(name = "ConditionProducts.findById", query = "SELECT c FROM ConditionProduct c WHERE c.id = :id"),
        @NamedQuery(name = "ConditionProducts.findByIdCondition", query = "SELECT c FROM ConditionProduct c WHERE c.idCondition = :idCondition"),
        @NamedQuery(name = "ConditionProducts.findByConditionPath", query = "SELECT c FROM ConditionProduct c WHERE c.conditionPath = :conditionPath")})
public class ConditionProduct implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "id_condition", nullable = false)
    private Integer idCondition;

    @Column(name = "condition_path", nullable = false, length = 100)
    private String conditionPath;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idCondition")
    private Collection<Producto> productos;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdCondition() {
        return idCondition;
    }

    public void setIdCondition(Integer idCondition) {
        this.idCondition = idCondition;
    }

    public String getConditionPath() {
        return conditionPath;
    }

    public void setConditionPath(String conditionPath) {
        this.conditionPath = conditionPath;
    }

    @XmlTransient
    public Collection<Producto> getProductosCollection() {
        return productos;
    }

    public void setProductosCollection(Collection<Producto> productosCollection) {
        this.productos = productosCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ConditionProduct)) {
            return false;
        }
        ConditionProduct other = (ConditionProduct) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.ConditionProducts[ id=" + id + " ]";
    }

}