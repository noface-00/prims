package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.io.Serializable;
import java.util.Collection;

@Entity
@Table(name = "productos", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "Producto.findAll", query = "SELECT p FROM Producto p"),
        @NamedQuery(name = "Producto.findByItemId",
                query = "SELECT p FROM Producto p " +
                        "LEFT JOIN FETCH p.imagesProductsCollection " +
                        "LEFT JOIN FETCH p.atributtesProductsCollection " +
                        "LEFT JOIN FETCH p.shippingProductsCollection " +
                        "LEFT JOIN FETCH p.idSeller " +
                        "LEFT JOIN FETCH p.idCategory " +
                        "LEFT JOIN FETCH p.idCondition " +
                        "WHERE p.itemId = :itemId"),
        @NamedQuery(name = "Producto.findByName", query = "SELECT p FROM Producto p WHERE p.name = :name"),
        @NamedQuery(name = "Producto.findByAvailable", query = "SELECT p FROM Producto p WHERE p.available = :available"),
        @NamedQuery(name = "Producto.findByReturns", query = "SELECT p FROM Producto p WHERE p.returns = :returns"),
        @NamedQuery(name = "Producto.findByRatedPrduct", query = "SELECT p FROM Producto p WHERE p.ratedPrduct = :ratedPrduct"),
        @NamedQuery(name = "Producto.findByShortDescription", query = "SELECT p FROM Producto p WHERE p.shortDescription = :shortDescription"),
        @NamedQuery(name = "Producto.findByURLproduct", query = "SELECT p FROM Producto p WHERE p.urlProduct = :uRLproduct"),
        @NamedQuery(name = "Producto.findByCreatedAt", query = "SELECT p FROM Producto p WHERE p.createdAt = :createdAt")})
public class Producto implements Serializable {
    @Id
    @Column(name = "itemId", nullable = false, length = 200)
    private String itemId;

    @Column(name = "name", nullable = false, length = 200)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_category", nullable = false)
    private CategoryProduct idCategory;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_condition", nullable = false)
    private ConditionProduct idCondition;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_coupon")
    private CouponPro idCoupon;

    @Column(name = "available")
    private Byte available;

    @Column(name = "returns")
    private Byte returns;

    @Column(name = "rated_prduct", nullable = false)
    private Byte ratedPrduct;

    @Column(name = "short_description", length = 1000)
    private String shortDescription;

    @Column(name = "URL_product", nullable = false, length = 1000)
    private String urlProduct;

    @Column(name = "created_at", nullable = false, length = 45)
    private String createdAt;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_seller", nullable = false)
    private Seller idSeller;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idItem")
    private Collection<WishlistProduct> wishlistProductsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "itemId")
    private Collection<ShippingProduct> shippingProductsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idItem")
    private Collection<AtributtesProduct> atributtesProductsCollection;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "itemId")
    private Collection<ImagesProduct> imagesProductsCollection;

    @Transient
    private PriceHistory priceHistory; // No se guarda en la BD, solo en memoria

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public Byte getAvailable() {
        return available;
    }

    public void setAvailable(Byte available) {
        this.available = available;
    }

    public Byte getReturns() {
        return returns;
    }

    public void setReturns(Byte returns) {
        this.returns = returns;
    }

    public Byte getRatedPrduct() {
        return ratedPrduct;
    }

    public void setRatedPrduct(Byte ratedPrduct) {
        this.ratedPrduct = ratedPrduct;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getUrlProduct() {
        return urlProduct;
    }

    public void setUrlProduct(String urlProduct) {
        this.urlProduct = urlProduct;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
    @XmlTransient
    public Collection<WishlistProduct> getWishlistProductsCollection() {
        return wishlistProductsCollection;
    }

    public void setWishlistProductsCollection(Collection<WishlistProduct> wishlistProductsCollection) {
        this.wishlistProductsCollection = wishlistProductsCollection;
    }

    @XmlTransient
    public Collection<ShippingProduct> getShippingProductsCollection() {
        return shippingProductsCollection;
    }

    public void setShippingProductsCollection(Collection<ShippingProduct> shippingProductsCollection) {
        this.shippingProductsCollection = shippingProductsCollection;
    }

    @XmlTransient
    public Collection<AtributtesProduct> getAtributtesProductsCollection() {
        return atributtesProductsCollection;
    }

    public void setAtributtesProductsCollection(Collection<AtributtesProduct> atributtesProductsCollection) {
        this.atributtesProductsCollection = atributtesProductsCollection;
    }

    public CategoryProduct getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(CategoryProduct idCategory) {
        this.idCategory = idCategory;
    }

    public ConditionProduct getIdCondition() {
        return idCondition;
    }

    public void setIdCondition(ConditionProduct idCondition) {
        this.idCondition = idCondition;
    }

    public CouponPro getIdCoupon() {
        return idCoupon;
    }

    public void setIdCoupon(CouponPro idCoupon) {
        this.idCoupon = idCoupon;
    }

    public Seller getIdSeller() {
        return idSeller;
    }

    public void setIdSeller(Seller idSeller) {
        this.idSeller = idSeller;
    }

    @XmlTransient
    public Collection<ImagesProduct> getImagesProductsCollection() {
        return imagesProductsCollection;
    }

    public void setImagesProductsCollection(Collection<ImagesProduct> imagesProductsCollection) {
        this.imagesProductsCollection = imagesProductsCollection;
    }

    public PriceHistory getPriceHistory() {
        return priceHistory;
    }

    public void setPriceHistory(PriceHistory priceHistory) {
        this.priceHistory = priceHistory;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (itemId != null ? itemId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Producto)) {
            return false;
        }
        Producto other = (Producto) object;
        if ((this.itemId == null && other.itemId != null) || (this.itemId != null && !this.itemId.equals(other.itemId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Productos[ itemId=" + itemId + " ]";
    }
}