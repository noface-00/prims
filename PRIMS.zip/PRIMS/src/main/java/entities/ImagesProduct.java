package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.io.Serializable;

@Entity
@Table(name = "images_products", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "ImagesProducts.findAll", query = "SELECT i FROM ImagesProduct i"),
        @NamedQuery(name = "ImagesProducts.findById", query = "SELECT i FROM ImagesProduct i WHERE i.id = :id"),
        @NamedQuery(name = "ImagesProducts.findByItemID", query = "SELECT i FROM ImagesProduct i WHERE i.itemId = :itemId"),
        @NamedQuery(name = "ImagesProducts.findByUrlImg", query = "SELECT i FROM ImagesProduct i WHERE i.urlImg = :urlImg")})
public class ImagesProduct implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "itemId", nullable = false)
    private Producto itemId;

    @Column(name = "url_img", nullable = false, length = 500)
    private String urlImg;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Producto getItem() {
        return itemId;
    }

    public void setItem(Producto item) {
        this.itemId = item;
    }

    public String getUrlImg() {
        return urlImg;
    }

    public void setUrlImg(String urlImg) {
        this.urlImg = urlImg;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ImagesProduct)) {
            return false;
        }
        ImagesProduct other = (ImagesProduct) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.ImagesProducts[ id=" + id + " ]";
    }
}