package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "marketplaces", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "Marketplaces.findAll", query = "SELECT m FROM Marketplace m"),
        @NamedQuery(name = "Marketplaces.findById", query = "SELECT m FROM Marketplace m WHERE m.id = :id"),
        @NamedQuery(name = "Marketplaces.findByNameMarketplace", query = "SELECT m FROM Marketplace m WHERE m.nameMarketplace = :nameMarketplace"),
        @NamedQuery(name = "Marketplaces.findByCountryCode", query = "SELECT m FROM Marketplace m WHERE m.countryCode = :countryCode")})
public class Marketplace implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "name_marketplace", nullable = false, length = 45)
    private String nameMarketplace;

    @Column(name = "country_code", nullable = false, length = 45)
    private String countryCode;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idMarketplace")
    private Collection<Seller> sellers;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNameMarketplace() {
        return nameMarketplace;
    }

    public void setNameMarketplace(String nameMarketplace) {
        this.nameMarketplace = nameMarketplace;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @XmlTransient
    public Collection<Seller> getSellerCollection() {
        return sellers;
    }

    public void setSellerCollection(Collection<Seller> sellerCollection) {
        this.sellers = sellerCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Marketplace)) {
            return false;
        }
        Marketplace other = (Marketplace) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Marketplaces[ id=" + id + " ]";
    }
}