package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.util.Collection;


@Entity
@Table(name = "category_products", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "CategoryProducts.findAll", query = "SELECT c FROM CategoryProduct c"),
        @NamedQuery(name = "CategoryProducts.findById", query = "SELECT c FROM CategoryProduct c WHERE c.id = :id"),
        @NamedQuery(name = "CategoryProducts.findByIdCategory", query = "SELECT c FROM CategoryProduct c WHERE c.idCategory = :idCategory"),
        @NamedQuery(name = "CategoryProducts.findByCategoryPath", query = "SELECT c FROM CategoryProduct c WHERE c.categoryPath = :categoryPath")})
public class CategoryProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "id_category", nullable = false)
    private Integer idCategory;

    @Column(name = "category_path", nullable = false)
    private String categoryPath;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idCategory")
    private Collection<Producto> productos;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(Integer idCategory) {
        this.idCategory = idCategory;
    }

    public String getCategoryPath() {
        return categoryPath;
    }

    public void setCategoryPath(String categoryPath) {
        this.categoryPath = categoryPath;
    }

    @XmlTransient
    public Collection<Producto> getProductosCollection() {
        return productos;
    }

    public void setProductosCollection(Collection<Producto> productosCollection) {
        this.productos = productosCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CategoryProduct)) {
            return false;
        }
        CategoryProduct other = (CategoryProduct) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.CategoryProducts[ id=" + id + " ]";
    }
}