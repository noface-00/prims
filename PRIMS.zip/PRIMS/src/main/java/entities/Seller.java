package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.io.Serializable;
import java.util.Collection;

@Entity
@Table(name = "seller", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "Seller.findAll", query = "SELECT s FROM Seller s"),
        @NamedQuery(name = "Seller.findById", query = "SELECT s FROM Seller s WHERE s.id = :id"),
        @NamedQuery(name = "Seller.findByUsername", query = "SELECT s FROM Seller s WHERE s.username = :username"),
        @NamedQuery(name = "Seller.findByFeedbackScore", query = "SELECT s FROM Seller s WHERE s.feedbackScore = :feedbackScore"),
        @NamedQuery(name = "Seller.findByFeedbackPorcentage", query = "SELECT s FROM Seller s WHERE s.feedbackPorcentage = :feedbackPorcentage"),
        @NamedQuery(name = "Seller.findByCreatedAt", query = "SELECT s FROM Seller s WHERE s.createdAt = :createdAt")})
public class Seller implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "username", nullable = false, length = 100)
    private String username;

    @Column(name = "feedback_score", nullable = false)
    private Integer feedbackScore;

    @Column(name = "feedback_porcentage", nullable = false)
    private Double feedbackPorcentage;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_marketplace", nullable = false)
    private Marketplace idMarketplace;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idSeller")
    private Collection<Producto> productosCollection;

    @Column(name = "created_at", length = 45)
    private String createdAt;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getFeedbackScore() {
        return feedbackScore;
    }

    public void setFeedbackScore(Integer feedbackScore) {
        this.feedbackScore = feedbackScore;
    }

    public Double getFeedbackPorcentage() {
        return feedbackPorcentage;
    }

    public void setFeedbackPorcentage(Double feedbackPorcentage) {
        this.feedbackPorcentage = feedbackPorcentage;
    }

    public Marketplace getIdMarketplace() {
        return idMarketplace;
    }

    public void setIdMarketplace(Marketplace idMarketplace) {
        this.idMarketplace = idMarketplace;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @XmlTransient
    public Collection<Producto> getProductosCollection() {
        return productosCollection;
    }

    public void setProductosCollection(Collection<Producto> productosCollection) {
        this.productosCollection = productosCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Seller)) {
            return false;
        }
        Seller other = (Seller) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Seller[ id=" + id + " ]";
    }
}