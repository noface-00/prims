package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "atributtes_products", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "AtributtesProducts.findAll", query = "SELECT a FROM AtributtesProduct a"),
        @NamedQuery(name = "AtributtesProducts.findById", query = "SELECT a FROM AtributtesProduct a WHERE a.id = :id"),
        @NamedQuery(name = "AtributtesProducts.findByAtributte", query = "SELECT a FROM AtributtesProduct a WHERE a.idItem = idItem and a.atributte = :atributte"),
        @NamedQuery(name = "AtributtesProducts.findByValue", query = "SELECT a FROM AtributtesProduct a WHERE a.value = :value")})
public class AtributtesProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_item", nullable = false, referencedColumnName = "itemId")
    private Producto idItem;

    @Column(name = "atributte", nullable = false, length = 100)
    private String atributte;

    @Column(name = "value", nullable = false, length = 500)
    private String value;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Producto getIdItem() {
        return idItem;
    }

    public void setIdItem(Producto idItem) {
        this.idItem = idItem;
    }

    public String getAtributte() {
        return atributte;
    }

    public void setAtributte(String atributte) {
        this.atributte = atributte;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AtributtesProduct)) {
            return false;
        }
        AtributtesProduct other = (AtributtesProduct) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.AtributtesProducts[ id=" + id + " ]";
    }
}