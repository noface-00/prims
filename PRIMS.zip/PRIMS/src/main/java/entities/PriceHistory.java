package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.io.Serializable;

@Entity
@Table(name = "price_history", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "PriceHistory.findAll", query = "SELECT p FROM PriceHistory p"),
        @NamedQuery(name = "PriceHistory.findById", query = "SELECT p FROM PriceHistory p WHERE p.id = :id"),
        @NamedQuery(name = "PriceHistory.findByItemId", query = "SELECT p FROM PriceHistory p WHERE p.itemId = :itemId and p.recordedAt = :recordedAt"),
        @NamedQuery(name = "PriceHistory.findByPrice", query = "SELECT p FROM PriceHistory p WHERE p.price = :price"),
        @NamedQuery(name = "PriceHistory.findByCurrency", query = "SELECT p FROM PriceHistory p WHERE p.currency = :currency")})
public class PriceHistory implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "itemId", nullable = false, length = 45)
    private String itemId;

    @Column(name = "price", nullable = false)
    private Double price;

    @Column(name = "currency", nullable = false, length = 45)
    private String currency;

    @Column(name = "recorded_at", nullable = false, length = 45)
    private String recordedAt;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getRecordedAt() {
        return recordedAt;
    }

    public void setRecordedAt(String recordedAt) {
        this.recordedAt = recordedAt;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PriceHistory)) {
            return false;
        }
        PriceHistory other = (PriceHistory) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.PriceHistory[ id=" + id + " ]";
    }
}