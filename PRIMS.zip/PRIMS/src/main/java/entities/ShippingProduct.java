package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "shipping_products", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "ShippingProducts.findAll", query = "SELECT s FROM ShippingProduct s"),
        @NamedQuery(name = "ShippingProducts.findById", query = "SELECT s FROM ShippingProduct s WHERE s.id = :id"),
        @NamedQuery(name = "ShippingProducts.findByShip", query ="SELECT s FROM ShippingProduct s WHERE s.itemId = :itemId and s.type = :type"),
        @NamedQuery(name = "ShippingProducts.findByType", query = "SELECT s FROM ShippingProduct s WHERE s.type = :type"),
        @NamedQuery(name = "ShippingProducts.findByShippingCarrier", query = "SELECT s FROM ShippingProduct s WHERE s.shippingCarrier = :shippingCarrier"),
        @NamedQuery(name = "ShippingProducts.findByShippingCost", query = "SELECT s FROM ShippingProduct s WHERE s.shippingCost = :shippingCost")})
public class ShippingProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "itemId", nullable = false)
    private Producto itemId;

    @Column(name = "type", nullable = false, length = 45)
    private String type;

    @Column(name = "shipping_carrier", nullable = false, length = 45)
    private String shippingCarrier;

    @Column(name = "shipping_cost", nullable = false)
    private Double shippingCost;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Producto getItem() {
        return itemId;
    }

    public void setItem(Producto item) {
        this.itemId = item;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getShippingCarrier() {
        return shippingCarrier;
    }

    public void setShippingCarrier(String shippingCarrier) {
        this.shippingCarrier = shippingCarrier;
    }

    public Double getShippingCost() {
        return shippingCost;
    }

    public void setShippingCost(Double shippingCost) {
        this.shippingCost = shippingCost;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ShippingProduct)) {
            return false;
        }
        ShippingProduct other = (ShippingProduct) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.ShippingProducts[ id=" + id + " ]";
    }

}