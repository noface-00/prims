package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "auth", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "Auth.findAll", query = "SELECT a FROM Auth a"),
        @NamedQuery(name = "Auth.findById", query = "SELECT a FROM Auth a WHERE a.id = :id"),
        @NamedQuery(name = "Auth.findByUsername", query = "SELECT a FROM Auth a WHERE a.username = :username"),
        @NamedQuery(name = "Auth.findByEmail", query = "SELECT a FROM Auth a WHERE a.email = :email"),
        @NamedQuery(name = "Auth.login", query = "SELECT a FROM Auth a where a.username = :u AND a.passwordHash = :p ")})
public class Auth {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "username", nullable = false, length = 100)
    private String username;

    @Column(name = "email", nullable = false, length = 150)
    private String email;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @OneToMany(mappedBy = "idUser", cascade = CascadeType.ALL, orphanRemoval = true)
    private Collection<WishlistProduct> wishlistProducts = new ArrayList<>();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    @XmlTransient
    public Collection<WishlistProduct> getWishlistProductsCollection() {
        return wishlistProducts;
    }

    public void setWishlistProductsCollection(Collection<WishlistProduct> wishlistProductsCollection) {
        this.wishlistProducts = wishlistProductsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Auth)) {
            return false;
        }
        Auth other = (Auth) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Auth[ id=" + id + " ]";
    }

}