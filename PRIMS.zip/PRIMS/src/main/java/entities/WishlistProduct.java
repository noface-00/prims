package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "wishlist_products", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "WishlistProducts.findAll", query = "SELECT w FROM WishlistProduct w"),
        @NamedQuery(
                name = "WishlistProducts.findById",
                query = "SELECT w FROM WishlistProduct w WHERE w.idUser.id = :idUser AND w.idItem.itemId = :idItem"
        ),
        @NamedQuery(name = "WishlistProducts.findByUser", query = "SELECT w FROM WishlistProduct w WHERE w.idUser.id = :idUser"),
        @NamedQuery(name = "WishlistProduct.countByUser", query = "SELECT COUNT(w) FROM WishlistProduct w WHERE w.idUser.id = :id")})
public class WishlistProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_user", nullable = false)
    private Auth idUser;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_item", nullable = false)
    private Producto idItem;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Auth getIdUser() {
        return idUser;
    }

    public void setIdUser(Auth idUser) {
        this.idUser = idUser;
    }

    public Producto getIdItem() {
        return idItem;
    }

    public void setIdItem(Producto idItem) {
        this.idItem = idItem;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof WishlistProduct)) {
            return false;
        }
        WishlistProduct other = (WishlistProduct) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.WishlistProducts[ id=" + id + " ]";
    }
}