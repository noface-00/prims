package entities;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "coupon_pro", schema = "PRIMS")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "CouponPro.findAll", query = "SELECT c FROM CouponPro c"),
        @NamedQuery(name = "CouponPro.findById", query = "SELECT c FROM CouponPro c WHERE c.id = :id"),
        @NamedQuery(name = "CouponPro.findByItemId", query = "SELECT c FROM CouponPro c WHERE c.itemId = :itemId"),
        @NamedQuery(name = "CouponPro.findByCouponRedemption", query = "SELECT c FROM CouponPro c WHERE c.couponRedemption = :couponRedemption"),
        @NamedQuery(name = "CouponPro.findByExpirationAt", query = "SELECT c FROM CouponPro c WHERE c.expirationAt = :expirationAt")})
public class CouponPro implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Column(name = "itemId", nullable = false, length = 100)
    private String itemId;

    @Column(name = "coupon_redemption", nullable = false, length = 150)
    private String couponRedemption;

    @Column(name = "expiration_at", nullable = false, length = 100)
    private String expirationAt;

    @OneToMany(mappedBy = "idCoupon")
    private Collection<Producto> productos;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getCouponRedemption() {
        return couponRedemption;
    }

    public void setCouponRedemption(String couponRedemption) {
        this.couponRedemption = couponRedemption;
    }

    public String getExpirationAt() {
        return expirationAt;
    }

    public void setExpirationAt(String expirationAt) {
        this.expirationAt = expirationAt;
    }

    @XmlTransient
    public Collection<Producto> getProductosCollection() {
        return productos;
    }

    public void setProductosCollection(Collection<Producto> productosCollection) {
        this.productos = productosCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CouponPro)) {
            return false;
        }
        CouponPro other = (CouponPro) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.CouponPro[ id=" + id + " ]";
    }
}