package service;

import api.conect_API_eBay;
import controllersJPA.*;
import entities.*;
import utils.Sesion;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class ProductAnalysisService {

    private final ProductAnalysisJpaController analysisController;
    private final ProductosJpaController productoController;
    private final PriceHistoryJpaController priceHistoryController;
    private final conect_API_eBay api_eBay = new conect_API_eBay();

    public ProductAnalysisService() {
        this.analysisController = new ProductAnalysisJpaController();
        this.productoController = new ProductosJpaController();
        this.priceHistoryController = new PriceHistoryJpaController();
    }

    private String getToken() {
        String token = Sesion.getTokenAPI();
        if (token == null || token.isBlank()) {
            System.err.println("❌ Token eBay no disponible");
        }
        return token;
    }


    // =====================================================
    // MÉTODO PRINCIPAL (EL QUE USA EL CONTROLLER)
    // =====================================================
    public ProductAnalysis obtenerOGenerarAnalisis(String itemId) {

        ProductAnalysis analisis =
                analysisController.findByItemAndDate(itemId, LocalDate.now());

        if (analisis != null) {
            inicializarTodo(analisis); // 🔥 AQUÍ
            return analisis;
        }

        ProductAnalysis nuevo = generarAnalisis(itemId, 30);
        if (nuevo != null) {
            inicializarTodo(nuevo); // 🔥 AQUÍ
        }
        return nuevo;
    }

    // =====================================================
    // GENERA ANÁLISIS (USA API Y GUARDA EN BD)
    // =====================================================
    public ProductAnalysis generarAnalisis(String itemId, int limit) {

        try {
            // 1️⃣ Producto - ✅ USAR findProductosWithCollections
            Producto producto = productoController.findProductosWithCollections(itemId);
            if (producto == null) {
                System.err.println("❌ Producto no encontrado: " + itemId);
                return null;
            }

            // 2️⃣ Seller y Marketplace
            Seller seller = producto.getIdSeller();
            if (seller == null || seller.getIdMarketplace() == null) {
                System.err.println("❌ Seller o Marketplace es null");
                return null;
            }

            // ✅ Obtener el Marketplace REAL de la BD (no el proxy)
            MarketplacesJpaController marketplaceJPA = new MarketplacesJpaController();
            Marketplace marketplace = marketplaceJPA.findMarketplaces(seller.getIdMarketplace().getId());

            if (marketplace == null) {
                System.err.println("❌ Marketplace no encontrado");
                return null;
            }

            // 3️⃣ Keyword
            String keyword = construirKeyword(producto.getName());
            if (keyword.isBlank()) {
                System.err.println("❌ No se pudo construir keyword");
                return null;
            }

            // 4️⃣ Precio REAL del ítem (API eBay)
            Double precioActual = api_eBay.obtenerPrecioActual(itemId, getToken());

            if (precioActual == null || precioActual <= 0) {
                System.err.println("❌ No se pudo obtener precio actual del item");
                return null;
            }

            // 5️⃣ Precios del mercado
            List<Double> preciosMercado = api_eBay.obtenerPreciosDelMercado(keyword, getToken());

            if (preciosMercado.isEmpty()) {
                System.err.println("❌ No se obtuvieron precios del mercado");
                return null;
            }

            // 6️⃣ Estadísticas
            double avg = preciosMercado.stream().mapToDouble(Double::doubleValue).average().orElse(0);
            double min = preciosMercado.stream().mapToDouble(Double::doubleValue).min().orElse(0);
            double max = preciosMercado.stream().mapToDouble(Double::doubleValue).max().orElse(0);

            double std = Math.sqrt(
                    preciosMercado.stream()
                            .mapToDouble(p -> Math.pow(p - avg, 2))
                            .average()
                            .orElse(0)
            );

            System.out.println("📊 Estadísticas calculadas:");
            System.out.println("   Promedio: $" + String.format("%.2f", avg));
            System.out.println("   Rango: $" + String.format("%.2f", min) + " - $" + String.format("%.2f", max));
            System.out.println("   Desv. Std: $" + String.format("%.2f", std));

            // 7️⃣ Guardar historial de precio REAL
            PriceHistory history = new PriceHistory();
            history.setItemId(itemId);
            history.setRecordedAt(LocalDateTime.now().toString());
            history.setPrice(precioActual);
            history.setCurrency("USD");
            priceHistoryController.create(history);

            // 8️⃣ Guardar análisis de mercado
            ProductAnalysis analysis = new ProductAnalysis();
            analysis.setItem(producto);
            analysis.setIdMarketplace(marketplace);
            analysis.setAnalysisDate(LocalDate.now());
            analysis.setPriceAvg(avg);
            analysis.setPriceMin(min);
            analysis.setPriceMax(max);
            analysis.setPriceStd(std);
            analysis.setSampleAnalysis(preciosMercado.size());
            analysis.setIdPrecioHistorico(history);

            analysisController.create(analysis);
            System.out.println("✅ Análisis guardado en BD");

            // ✅ RECARGAR EL ANÁLISIS COMPLETO DESDE LA BD
            ProductAnalysis analisisCompleto = analysisController.findByItemAndDate(itemId, LocalDate.now());

            if (analisisCompleto != null) {
                // Asignar el priceHistory al producto (campo @Transient)
                analisisCompleto.getItem().setPriceHistory(history);
                System.out.println("✅ Análisis recargado con producto completo");
                return analisisCompleto;
            } else {
                System.err.println("⚠️ No se pudo recargar el análisis, devolviendo el original");
                producto.setPriceHistory(history);
                return analysis;
            }

        } catch (Exception e) {
            System.err.println("❌ Error generando análisis:");
            e.printStackTrace();
            return null;
        }
    }
    // =====================================================
    // CONSULTA SIMPLE
    // =====================================================
    private void inicializarTodo(ProductAnalysis analisis) {
        if (analisis == null) {
            System.err.println("❌ ProductAnalysis es null");
            return;
        }

        if (analisis.getItem() == null) {
            System.err.println("❌ Item del análisis es null");
            return;
        }

        Producto p = analisis.getItem();

        try {
            // Solo verificar que todo esté cargado
            String nombre = p.getName();
            System.out.println("✅ Producto inicializado: " + nombre);

            // Asignar el último precio histórico
            PriceHistory ultimo = priceHistoryController.findLatestByItemId(p.getItemId());
            if (ultimo != null) {
                p.setPriceHistory(ultimo);
                System.out.println("✅ PriceHistory asignado: $" + ultimo.getPrice());
            } else {
                System.out.println("⚠️ No se encontró PriceHistory para: " + p.getItemId());
            }

        } catch (Exception e) {
            System.err.println("❌ Error en inicializarTodo:");
            e.printStackTrace();
        }
    }
    public ProductAnalysis obtenerUltimoAnalisis(String itemId) {
        ProductAnalysis analisis = analysisController.findLatestByItemId(itemId);

        if (analisis != null) {
            // ✅ Cargar el último precio y asignarlo al producto
            PriceHistory ultimoPrecio = priceHistoryController.findLatestByItemId(itemId);
            if (analisis.getItem() != null && ultimoPrecio != null) {
                analisis.getItem().setPriceHistory(ultimoPrecio);
            }
        }

        return analisis;
    }

    // =====================================================
    // UTILIDAD
    // =====================================================
    private String construirKeyword(String titulo) {
        if (titulo == null) return "";

        return titulo.toLowerCase()
                // eliminar texto entre paréntesis
                .replaceAll("\\(.*?\\)", "")
                // eliminar guiones y SKU
                .replaceAll("-\\w+", "")
                // eliminar porcentajes y símbolos
                .replaceAll("\\d+%|&", "")
                // eliminar palabras basura
                .replaceAll(
                        "\\b(new|used|very|good|condition|locked|unlocked|original|" +
                                "envío|gratis|free|shipping|b-h|sku|model)\\b",
                        ""
                )
                // dejar solo letras y números
                .replaceAll("[^a-z0-9 ]", "")
                .replaceAll("\\s+", " ")
                .trim();
    }

}
